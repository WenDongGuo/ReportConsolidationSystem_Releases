"""
数据清洗层（Cleanse Layer）— 前置数据质量保障

职责:
  1. 拦截非法数值 (inf/nan/None) → 替换为 0 并记录警告
  2. 校验必须列是否存在 → 标记无效记录
  3. 统一类型 (金额转 float, 编码转 str)
  4. 空记录过滤

调用时机: mapper.py 的 process() 输出后立即调用
"""

from typing import Dict, List, Any, Tuple
import math
import logging

logger = logging.getLogger(__name__)

# 每条记录必须包含的字段
REQUIRED_FIELDS = ['公司', '科目编码', '金额', '期间类型', '报表']
REQUIRED_FIELDS_ALT = ['company', 'code', '金额', '期间类型', '报表']  # 兼容英文别名

# 金额字段名 (可能的中英文变体)
AMOUNT_FIELDS = ['金额', 'amount', '期末余额', '年初余额', '本期金额', '本年累计']

# 公司名字段 (可能的变体)
COMPANY_FIELDS = ['公司', 'company', '母公司', '子公司']


def sanitize(records: List[Dict]) -> List[Dict]:
    """
    主入口: 清洗并校验一批记录

    Args:
        records: 原始记录列表

    Returns:
        清洗后的记录列表（无效记录已过滤）
    """
    if not records:
        return []

    cleaned = []
    warnings: List[str] = []

    for i, rec in enumerate(records):
        if not isinstance(rec, dict):
            warnings.append(f"第{i}条记录不是 dict 类型，已跳过 (type={type(rec).__name__})")
            continue

        # Step 1: Schema 校验 — 必须字段存在
        valid, schema_errs = _check_required_fields(rec)
        if not valid:
            for err in schema_errs:
                warnings.append(f"第{i}条: {err}")
            continue

        # Step 2: 深拷贝，避免污染原始数据
        clean = dict(rec)

        # Step 3: 清洗金额字段
        amount_cleaned = False
        for af in AMOUNT_FIELDS:
            if af in clean:
                val = clean[af]
                cleaned_val = _clean_amount(val, i, af, warnings)
                if cleaned_val is not None:
                    clean[af] = cleaned_val
                    amount_cleaned = True
                else:
                    clean[af] = 0.0

        # 如果没有标准金额字段，尝试找任何数值字段
        if not amount_cleaned:
            for key, val in clean.items():
                if isinstance(val, (int, float)):
                    cval = _clean_amount(val, i, key, warnings)
                    clean[key] = cval if cval is not None else 0.0
                    break

        # Step 4: 统一科目编码为字符串
        for code_field in ['科目编码', '编码', 'code']:
            if code_field in clean and not isinstance(clean.get(code_field), str):
                clean[code_field] = str(clean[code_field])

        cleaned.append(clean)

    if warnings:
        logger.warning(f"数据清洗: {len(warnings)} 条警告")
        for w in warnings:
            logger.warning(f"  {w}")

    return cleaned


def sanitize_one(record: Dict) -> Dict:
    """
    清洗单条记录（轻量版，给内部调用用）
    """
    result = dict(record)
    for af in AMOUNT_FIELDS:
        if af in result:
            val = result[af]
            cval = _clean_amount(val, 0, af, [])
            result[af] = cval if cval is not None else 0.0

    for code_field in ['科目编码', '编码', 'code']:
        if code_field in result and not isinstance(result.get(code_field), str):
            result[code_field] = str(result[code_field])

    return result


def _clean_amount(value: Any, idx: int, field_name: str, warnings: List[str]) -> float:
    """
    清洗单个金额值

    Returns:
        float 或 None（不可恢复时）
    """
    if value is None:
        return 0.0

    if isinstance(value, str):
        # 去除逗号和货币符号
        try:
            cleaned_str = value.replace(',', '').replace('¥', '').replace('$', '').replace('€', '')
            return float(cleaned_str)
        except (ValueError, TypeError):
            warnings.append(f"金额无法解析: field={field_name}, value={value!r} → 置为0")
            return 0.0

    if isinstance(value, bool):
        warnings.append(f"金额为布尔值: field={field_name}, value={value} → 置为0")
        return 0.0

    if isinstance(value, (int, float)):
        if math.isinf(value):
            warnings.append(f"金额为无穷大(inf): field={field_name}, 第{idx}条 → 置为0")
            return 0.0
        if math.isnan(value):
            warnings.append(f"金额为无效数字(nan): field={field_name}, 第{idx}条 → 置为0")
            return 0.0
        return float(value)

    # 其他不可处理的类型
    warnings.append(f"金额类型不支持: field={field_name}, type={type(value).__name__}, value={value!r} → 置为0")
    return 0.0


def _check_required_fields(record: Dict) -> Tuple[bool, List[str]]:
    """
    校验必须字段是否存在

    Returns:
        (是否通过, 错误列表)
    """
    errors = []

    # 检查公司字段
    has_company = any(f in record for f in COMPANY_FIELDS)
    if not has_company:
        errors.append("缺少公司字段 (需含 公司/company 之一)")

    # 检查编码字段
    has_code = any(f in record for f in ['科目编码', '编码', 'code'])
    if not has_code:
        errors.append("缺少科目编码字段 (需含 科目编码/编码/code 之一)")

    # 检查金额字段
    has_amount = any(f in record for f in AMOUNT_FIELDS)
    if not has_amount:
        errors.append("缺少金额字段 (需含 金额/amount 之一)")

    # 检查期间和报表字段（弱校验 — 有更好，没有不阻断）
    has_period = any(f in record for f in ['期间类型', 'period'])
    has_report = any(f in record for f in ['报表', 'report', '报表类型', 'statement'])

    if not has_period:
        errors.append("⚠ 缺少期间字段 (期间类型/period)")

    if not has_report:
        errors.append("⚠ 缺少报表字段 (报表/report/报表类型)")

    return len(errors) == 0 or all('⚠' in e for e in errors), errors


def quick_check(records: List[Dict]) -> Dict:
    """
    快速数据质量报告（不下游清洗，只报告问题）

    Returns:
        {total, valid, invalid, warnings: [...], summary: str}
    """
    if not records:
        return {'total': 0, 'valid': 0, 'invalid': 0, 'warnings': [], 'summary': '空数据'}

    valid = 0
    invalid = 0
    warnings = []

    for i, rec in enumerate(records):
        ok, errs = _check_required_fields(rec)
        if ok:
            valid += 1
        else:
            invalid += 1
            warnings.append(f"第{i}条: {'; '.join(errs)}")

        for af in AMOUNT_FIELDS:
            if af in rec:
                val = rec[af]
                if isinstance(val, (int, float)):
                    if math.isinf(val) or math.isnan(val):
                        warnings.append(f"第{i}条 {af}=inf/nan")

    return {
        'total': len(records),
        'valid': valid,
        'invalid': invalid,
        'warnings': warnings[:20],  # 最多取前20条
        'summary': f"{len(records)}条中 {valid}条有效, {invalid}条有问题"
    }
