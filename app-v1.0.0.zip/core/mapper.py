"""
导入引擎 — 将Excel原始数据 → 标准CAS科目数据

核心流程:
  Excel原始行 → 识别科目名称 → 匹配标准科目 → 提取金额 → 输出标准格式
"""
from typing import Dict, List, Any, Optional
from .standards import SubjectMatcher
from .cleanse import sanitize_one
import os
import yaml

# 共享归一化工具 — 委托给 SubjectMatcher，避免逻辑重复
_normalize_name = SubjectMatcher._normalize
_extract_keywords = SubjectMatcher._extract_keywords


class StandardRecord:
    """统一的标准数据记录"""
    
    def __init__(self, company: str, period: str = ""):
        self.company = company
        self.period = period
        self.records = []  # [{科目编码, 科目名称, 金额, 期间类型, 报表类型, 方向}]
        self.total_checks = []  # 合计行校验记录 [{报表, 合计行名称, 计算值, 报告值, 差异}]

    def add(self, account_code: str, account_name: str, amount: float, 
            period_type: str = "期末余额", statement: str = "资产负债表"):
        # 清洗: 拦截 inf/nan/None
        cleaned = sanitize_one({
            'company': self.company,
            '科目编码': account_code,
            '科目名称': account_name,
            '金额': amount,
            '期间类型': period_type,
            '报表': statement,
        })
        self.records.append(cleaned)

    def add_total_check(self, total_name: str, computed: float, reported: float,
                        period_type: str, statement: str):
        """记录一条合计校验"""
        check = {
            '公司': self.company,
            '合计项目': total_name,
            '计算值': round(computed, 2),
            '报告值': round(reported, 2),
            '差异': round(computed - reported, 2),
            '是否一致': abs(computed - reported) < 0.01,
            '期间类型': period_type,
            '报表': statement,
        }
        self.total_checks.append(check)

    def get_validation_summary(self) -> dict:
        """返回校验摘要"""
        total = len(self.total_checks)
        passed = sum(1 for c in self.total_checks if c['是否一致'])
        failed = total - passed
        return {
            '公司': self.company,
            '合计校验总数': total,
            '通过': passed,
            '未通过': failed,
            '校验详情': self.total_checks,
        }


class MappingEngine:
    """
    映射引擎 — 将 ExcelReader 输出的原始结构化数据转为标准科目数据
    
    这是一个「管道」，不涉及具体格式细节
    """

    TOTAL_KEYWORDS = ['合计', '总计', '小计', '净额']

    def __init__(self, subject_matcher: SubjectMatcher):
        self.matcher = subject_matcher
        self._unmatched_names = []  # 未匹配的科目名列表（别名自学习用）
        self._sub_parent_map = None  # 懒加载子母科目映射

    def transform(self, raw_data: Dict) -> StandardRecord:
        """
        转换原始数据为标准数据
        raw_data: ExcelReader 的输出
        """
        company = raw_data.get('company_name', '未知')
        record = StandardRecord(company)

        # 处理资产负债表
        if 'balance_sheet' in raw_data:
            self._transform_balance_sheet(raw_data['balance_sheet'], record)

        # 处理利润表
        if 'income_statement' in raw_data:
            self._transform_income_statement(raw_data['income_statement'], record)

        # 处理现金流量表
        if 'cash_flow_statement' in raw_data:
            self._transform_cash_flow(raw_data['cash_flow_statement'], record)

        return record

    @staticmethod
    def _clean_name(name: str) -> str:
        """清理科目名称 — 委托 SubjectMatcher 归一化"""
        return _normalize_name(name)

    def _get_sub_parent_map(self) -> dict:
        """懒加载子母科目映射（子科目编码 → 母科目编码）"""
        if self._sub_parent_map is not None:
            return self._sub_parent_map
        _config_dir = os.path.join(os.path.dirname(__file__), '..', 'config')
        _cas_config_path = os.path.join(_config_dir, 'standards', 'cas.yaml')
        try:
            if os.path.isfile(_cas_config_path):
                with open(_cas_config_path, 'r', encoding='utf-8') as _f:
                    _cfg = yaml.safe_load(_f) or {}
                self._sub_parent_map = _cfg.get('子母科目映射', {}) or {}
            else:
                self._sub_parent_map = {'1406': '1401'}
        except Exception:
            self._sub_parent_map = {'1406': '1401'}
        return self._sub_parent_map

    def _is_total(self, name: str) -> bool:
        """判断行名是否为合计行"""
        if not name:
            return False
        for kw in self.TOTAL_KEYWORDS:
            if kw in name:
                return True
        return False

    def _is_section_header(self, name: str) -> bool:
        """判断是否为段标题行"""
        if not name:
            return False
        name = name.strip()
        
        # 合计行不是段标题（即使冒号结尾）
        if self._is_total(name):
            return False
        
        # 方式1: 以冒号结尾（"流动资产："、"流动负债："等）
        if name.endswith('：') or name.endswith(':'):
            return True
        
        # 方式2: 以序号开头（"一、营业收入"等）
        section_patterns = ['一、', '二、', '三、', '四、', '五、', '六、', '七、', '八、',
                           '1、', '2、', '3、', '4、', '5、', '6、']
        for p in section_patterns:
            if name.startswith(p):
                # 检查是否匹配 known 具体科目（不是段标题）
                specific = ['货币资金', '应收账款', '应收票据', '存货', '固定资产', '无形资产',
                           '实收资本', '营业收入', '营业成本', '管理费用', '销售费用', '财务费用',
                           '短期借款', '应付账款', '应付票据', '应交税费', '长期借款',
                           '现金及现金等价物净增加额', '净利润', '利润总额', '营业利润',
                           '现金净增加额', '综合收益总额', '其他综合收益',
                           '归属于母公司所有者的净利润', '少数股东损益']
                if not any(s in name for s in specific):
                    return True
                # 即使含有关键词，但如果括号内容非常长也可能是标题
                # 例："一、营业收入（亏损以"－"号填列）" — 括号有含义，但此处仍为小节标题
        
        return False

    def _extract_items_and_totals(self, rows: List[Dict], side_key: str,
                                  record: StandardRecord, stmt: str, 
                                  period_field: str, period_label: str):
        """
        从一侧的行中提取明细科目和合计行（分段+层级处理）
        
        关键逻辑：
        - 段标题（如"流动负债："）→ 重置当前段明细
        - 合计行（如"流动负债合计"）→ 校验当前段 + 加入累计
        - 总计行（如"负债合计"）→ 校验累计的段合计值
        - 明细科目 → 映射标准科目 + 加入当前段
        """
        section_items = []   # 当前段内的明细
        section_totals = []  # 已结算的段合计值（用于层级总计校验）
        
        for row in rows:
            side = row.get(side_key, {})
            name = side.get('item_name', '')
            if not isinstance(name, str) or not name.strip():
                continue

            name_clean = name.strip()
            original_name = name_clean  # 保存归一化前的原始名称
            name_clean = self._clean_name(name_clean)
            amount = side.get(period_field, 0)
            if not isinstance(amount, (int, float)):
                continue
            amount_val = float(amount)

            if self._is_section_header(name_clean):
                # 段标题 → 重置段明细
                section_items = []
                
            elif self._is_total(name_clean):
                # 合计/总计行
                # 判断逻辑:
                #   - "资产总计" → 层级总计 (grand_total=True)
                #   - "负债合计" → 层级总计 (无前缀)
                #   - "流动资产合计" → 段合计 (有前缀)
                #   - "所有者权益（或股东权益）合计" → 段合计 (有前缀)
                #   - "负债和所有者权益（或股东权益）合计" → 最终总计 (特殊)
                is_final_total = '负债和所有者权益' in name_clean or '负债及所有者权益' in name_clean
                is_grand_total = '总计' in name_clean or is_final_total
                has_section_prefix = any(kw in name_clean for kw in ['流动', '非流动', 
                                                                     '流动资产', '非流动资产', 
                                                                     '所有者权益', '权益合计'])

                if is_final_total:
                    # 最终总计: 校验累计的段合计值
                    if amount_val != 0 and section_totals:
                        computed = sum(section_totals)
                        record.add_total_check(name_clean, computed, amount_val,
                                              period_label, stmt)
                elif is_grand_total:
                    # 层级总计: 资产总计 / 负债合计（无前缀的合计）
                    if amount_val != 0 and section_totals:
                        computed = sum(section_totals)
                        record.add_total_check(name_clean, computed, amount_val,
                                              period_label, stmt)
                elif has_section_prefix:
                    # 段级别合计: 流动资产合计 / 流动负债合计 / 非流动资产合计 / 所有者权益合计
                    if amount_val != 0 and section_items:
                        computed = sum(item['amount'] for item in section_items)
                        record.add_total_check(name_clean, computed, amount_val,
                                              period_label, stmt)
                    # 段合计值加入累计（用于层级总计校验）
                    section_totals.append(amount_val)
                    section_items = []  # 重置段明细为当前合计行
 
            else:
                # 明细科目 — 映射到标准科目
                # 跳过"其中："子明细行（明细拆分行，如"其中：原材料"）
                if '其中：' in original_name or '其中:' in original_name or original_name.startswith('其中'):
                    continue

                # 先匹配标准科目（只需一次）
                matched = self.matcher.match(name_clean)

                # 跳过存货的子科目明细拆分行（动态从子母科目映射读取）
                # 三层兜底:
                #   1. 匹配到的标准编码是子科目（如 1406 是 1401 的子科目）
                #   2. 父科目(1401)已在 section_items 中有相同金额
                #   3. 金额完全一致（<0.01 容差），避免误伤子项各有金额的情况
                if matched:
                    _sub_map = self._get_sub_parent_map()
                    if matched['编码'] in _sub_map:
                        _parent_code = _sub_map[matched['编码']]
                        if any(item.get('code') == _parent_code and abs(item['amount'] - amount_val) < 0.01
                               for item in section_items):
                            continue  # 是母科目的明细拆分行，跳过 section_items

                # 跳过"固定资产原价"和"减：累计折旧"——已含在固定资产账面价值中
                if '固定资产原价' in original_name or original_name == '固定资产原价':
                    continue
                if '减：累计折旧' in original_name or '减:累计折旧' in original_name:
                    continue

                # "减："前缀行（抵减项，如"减：累计折旧"），金额取负数
                is_deduct = original_name.startswith('减：') or original_name.startswith('减:')
                if is_deduct:
                    amount_val = -abs(amount_val)

                if matched:
                    record.add(matched['编码'], matched['名称'], amount_val, 
                              period_label, stmt)
                    section_items.append({'code': matched['编码'], 'amount': amount_val})
                elif amount_val != 0:
                    # 有金额但未匹配 → 记录供别名学习
                    self._unmatched_names.append({
                        'company': record.company,
                        '原始名称': name_clean,
                        '完整名称': name.strip(),
                        '金额': amount_val,
                        '期间类型': period_label,
                        '报表': stmt,
                        '建议': self.matcher.suggest_matches(name_clean)[:3],
                    })

    def _transform_balance_sheet(self, bs_data: Dict, record: StandardRecord):
        """转换资产负债表"""
        config = bs_data.get('config', {})
        structure = config.get('structure', 'single')

        for row in bs_data.get('rows', []):
            if structure == 'dual_column_side_by_side':
                # 左侧（资产）+ 右侧（负债+权益）一并处理
                pass  # 在下面统一处理

        if structure == 'dual_column_side_by_side':
            self._extract_items_and_totals(bs_data['rows'], 'left',
                                          record, '资产负债表', 'period_end', '期末余额')
            self._extract_items_and_totals(bs_data['rows'], 'left',
                                          record, '资产负债表', 'period_begin', '年初余额')
            self._extract_items_and_totals(bs_data['rows'], 'right',
                                          record, '资产负债表', 'period_end', '期末余额')
            self._extract_items_and_totals(bs_data['rows'], 'right',
                                          record, '资产负债表', 'period_begin', '年初余额')

            # 双栏并列格式，左右两边相同科目保留第一个（金额一致时去重）
            seen = set()
            deduped = []
            for r in record.records:
                key = (r['科目编码'], r['期间类型'])
                if key not in seen:
                    seen.add(key)
                    deduped.append(r)
                else:
                    # 同一(编码,期间)存在第二条：来自不同的科目名映射到同码（如其他应付款+其他流动负债→2241）
                    # 只有在金额不同时才合并（不同源科目），否则跳过（左右重复）
                    existing = next(x for x in deduped if x['科目编码']==r['科目编码'] and x['期间类型']==r['期间类型'])
                    if abs(existing['金额'] - r['金额']) > 0.01:
                        existing['金额'] += r['金额']

            # 子科目去重：如果母科目已存在且有相同金额，移除子科目
            # 如 1406(库存商品) 与 1401(存货) 金额一致，属于明细拆分行
            # 从 YAML 配置读取子母科目映射
            _config_dir = os.path.join(os.path.dirname(__file__), '..', 'config')
            _cas_config_path = os.path.join(_config_dir, 'standards', 'cas.yaml')
            _sub_parent_map = {}
            if os.path.isfile(_cas_config_path):
                try:
                    with open(_cas_config_path, 'r', encoding='utf-8') as _f:
                        _cfg = yaml.safe_load(_f) or {}
                    _sub_parent_map = _cfg.get('子母科目映射', {}) or {}
                except Exception:
                    _sub_parent_map = {'1406': '1401'}
            # 子科目编码 → 母科目编码
            sub_parent_map = _sub_parent_map
            filtered = []
            for r in deduped:
                code = r['科目编码']
                if code in sub_parent_map:
                    parent = sub_parent_map[code]
                    # 查找母科目在同一个期间有没有相同金额
                    parent_match = next(
                        (p for p in deduped if p['科目编码'] == parent and p['期间类型'] == r['期间类型'] and abs(p['金额'] - r['金额']) < 0.01),
                        None
                    )
                    if parent_match:
                        continue  # 子科目与母科目金额一致，跳过
                filtered.append(r)
            record.records = filtered

    def _transform_income_statement(self, is_data: Dict, record: StandardRecord):
        """转换利润表"""
        config = is_data.get('config', {})
        columns = config.get('columns', [])

        for row in is_data.get('rows', []):
            data = row.get('data', {})
            item_name = data.get('item_name', '')
            if not isinstance(item_name, str) or not item_name.strip():
                continue

            name_clean = item_name.strip()
            name_clean = self._clean_name(name_clean)

            if self._is_total(name_clean):
                continue
            if self._is_section_header(name_clean):
                continue

            matched = self.matcher.match(name_clean)
            if matched:
                for col in columns:
                    field = col.get('field', '')
                    if field.startswith('period_'):
                        val = data.get(field, 0)
                        if isinstance(val, (int, float)) and abs(val) > 0.001:
                            label = {'period_month': '本期金额', 'period_year': '本年累计',
                                     'period_last': '上期金额'}.get(field, field)
                            record.add(matched['编码'], matched['名称'], float(val), label, '利润表')
            elif any(data.get(f, 0) for f in ['period_month', 'period_year', 'period_last']):
                # 有金额但未匹配 → 记录供别名学习
                self._unmatched_names.append({
                    'company': record.company,
                    '原始名称': name_clean,
                    '完整名称': item_name.strip(),
                    '金额': next((data.get(f, 0) for f in ['period_year', 'period_month', 'period_last'] if data.get(f, 0)), 0),
                    '报表': '利润表',
                    '建议': self.matcher.suggest_matches(name_clean)[:3],
                })

    def _transform_cash_flow(self, cf_data: Dict, record: StandardRecord):
        """转换现金流量表"""
        columns = cf_data.get('config', {}).get('columns', [])

        for row in cf_data.get('rows', []):
            data = row.get('data', {})
            item_name = data.get('item_name', '')
            if not isinstance(item_name, str) or not item_name.strip():
                continue

            name_clean = item_name.strip()
            name_clean = self._clean_name(name_clean)

            if self._is_total(name_clean):
                continue
            if self._is_section_header(name_clean):
                continue

            # 现金流量表附表行（期初/期末余额行），非实际现金流项目
            if any(kw in name_clean for kw in ('期初余额', '期末余额', '期初现金', '期末现金')):
                continue

            matched = self.matcher.match(name_clean)
            if matched:
                for col in columns:
                    field = col.get('field', '')
                    if field.startswith('period_'):
                        val = data.get(field, 0)
                        if isinstance(val, (int, float)) and abs(val) > 0.001:
                            label = {'period_month': '本期金额', 'period_year': '本年累计',
                                     'period_last': '上期金额'}.get(field, field)
                            record.add(matched['编码'], matched['名称'], float(val), label, '现金流量表')
            elif any(data.get(f, 0) for f in ['period_month', 'period_year', 'period_last']):
                # 有金额但未匹配 → 记录供别名学习
                self._unmatched_names.append({
                    'company': record.company,
                    '原始名称': name_clean,
                    '完整名称': item_name.strip(),
                    '金额': next((data.get(f, 0) for f in ['period_year', 'period_month', 'period_last'] if data.get(f, 0)), 0),
                    '报表': '现金流量表',
                    '建议': self.matcher.suggest_matches(name_clean)[:3],
                })
