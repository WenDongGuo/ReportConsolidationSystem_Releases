"""
格式配置向导 — 上传样本 Excel 自动生成 YAML 映射配置

流程:
  1. 打开 Excel → 遍历所有 Sheet
  2. 扫描表头行 → 识别报表类型 (BS/IS/CF)
  3. 识别列位置 → 项目列/金额列/行次列
  4. 识别布局 → 单列 vs 左右对照
  5. 识别公司名位置
  6. 生成完整 YAML 草案

输出: 可直接保存为 config/mappings/<id>.yaml 的配置字典
"""
import os
import re
import openpyxl
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime


# ──────────────────────────────────────────────
# 表头关键词签名（用于识别报表类型）
# ──────────────────────────────────────────────

SHEET_SIGNATURES = {
    'balance_sheet': {
        'required': ['资产', '负债', '所有者权益', '股东权益'],
        'optional': ['期末余额', '年初余额', '期初余额', '流动资产', '非流动资产'],
        'sheet_name_kw': ['资产负债表', '资产', 'balance'],
    },
    'income_statement': {
        'required': ['营业收入', '营业成本', '净利润', '利润总额'],
        'optional': ['本期金额', '本年累计', '上期金额', '营业利润'],
        'sheet_name_kw': ['利润表', '利润', 'income', '损益'],
    },
    'cash_flow_statement': {
        'required': ['经营活动', '投资活动', '筹资活动', '现金流量', '现金'],
        'optional': ['流入', '流出', '净额'],
        'sheet_name_kw': ['现金流量表', '现金流', '现金', 'cash flow'],
    },
}

# 金额列关键词（按优先序）
AMOUNT_KEYWORDS = {
    'period_end': ['期末余额', '期末', '期未余额', '期末数'],
    'period_begin': ['年初余额', '期初余额', '上年年末余额', '上年余额', '期初数'],
    'period_month': ['本月金额', '本期金额', '本月数', '本月'],
    'period_year': ['本年累计金额', '本年累计', '本年金额', '本年数', '累计'],
    'period_last': ['上期金额', '上期', '上年金额'],
}

ITEM_NAME_KEYWORDS = ['项目', '项目名称', '资产', '负债', '权益', '科目', '科目名称']
LINE_NUMBER_KEYWORDS = ['行次', '行号', '序号']


class FormatWizard:
    """格式配置向导 — 从样本 Excel 自动推断映射配置"""

    def __init__(self, filepath: str):
        self.filepath = filepath
        self.wb = openpyxl.load_workbook(filepath, data_only=True)
        self.sheet_analyses = {}  # sheet_name → analysis result

    def analyze(self) -> Dict[str, Any]:
        """
        全自动分析 Excel，返回完整的格式配置字典
        
        返回: 可直接 yaml.dump 的格式配置
        """
        result = {
            'format': {
                'id': '',
                'name': '',
                'type': 'combined_file',  # 默认推断为合并多Sheet
                'detection': {
                    'file_patterns': {},
                },
                'company_name_source': 'excel_content',
                'company_name_row': 2,
            }
        }

        # 1. 分析每个 Sheet
        for sn in self.wb.sheetnames:
            analysis = self._analyze_sheet(sn)
            self.sheet_analyses[sn] = analysis

        # 2. 判断文件类型：多Sheet合并 vs 单Sheet
        sheet_count = len(self.wb.sheetnames)
        identified_types = set()
        for sn, analysis in self.sheet_analyses.items():
            if analysis.get('type'):
                identified_types.add(analysis['type'])

        if sheet_count >= 2 and len(identified_types) >= 2:
            result['format']['type'] = 'combined_file'
        elif sheet_count == 1:
            result['format']['type'] = 'single_file_single_sheet'

        # 3. 为每种识别出的报表类型生成配置
        for sn, analysis in self.sheet_analyses.items():
            stmt_type = analysis.get('type')
            if not stmt_type:
                continue

            config = self._build_stmt_config(sn, analysis)
            result['format'][stmt_type] = config

        # 4. 生成文件匹配规则
        basename = os.path.basename(self.filepath)
        result['format']['detection']['file_patterns'] = self._guess_file_patterns(
            basename, result['format']['type']
        )

        # 5. 生成ID和名称
        result['format']['id'] = self._generate_id(basename)
        result['format']['name'] = self._generate_name(basename)

        # 6. 定位公司名行
        result['format']['company_name_row'] = self._detect_company_row()

        return result

    def _analyze_sheet(self, sheet_name: str) -> Dict[str, Any]:
        """分析一个Sheet的内容和结构"""
        ws = self.wb[sheet_name]
        analysis = {
            'name': sheet_name,
            'type': None,       # balance_sheet / income_statement / cash_flow_statement
            'header_row': None,
            'data_start_row': None,
            'structure': 'single',  # single / dual_column_side_by_side
            'columns': {},
            'dual_columns': {'left': {}, 'right': {}},
        }

        # 读取前15行
        rows_data = []
        for row_idx in range(1, min(16, ws.max_row + 1)):
            cells = []
            for cell in ws[row_idx]:
                cells.append(str(cell.value).strip() if cell.value is not None else '')
            rows_data.append((row_idx, cells))

        # 1. 按Sheet名初步判断类型
        analysis['type'] = self._identify_sheet_type(sheet_name, rows_data)

        # 2. 找表头行（行内容含最多的金额关键词）
        analysis['header_row'] = self._find_header_row(rows_data)

        # 3. 判断结构：左右对照 vs 单列
        analysis['structure'] = self._detect_structure(rows_data, analysis['header_row'])

        # 4. 推断列位置
        if analysis['header_row']:
            header_cells = []
            for rn, cells in rows_data:
                if rn == analysis['header_row']:
                    header_cells = cells
                    break

            if analysis['structure'] == 'dual_column_side_by_side':
                analysis['dual_columns'] = self._detect_dual_columns(header_cells)
            else:
                analysis['columns'] = self._detect_single_columns(header_cells)

        # 5. 估算数据起始行
        analysis['data_start_row'] = (analysis['header_row'] or 1) + 1

        return analysis

    def _identify_sheet_type(self, sheet_name: str,
                             rows_data: List[Tuple[int, List[str]]]) -> Optional[str]:
        """通过 Sheet 名 + 前几行内容判断报表类型"""
        scores = {}

        for stmt_type, sig in SHEET_SIGNATURES.items():
            score = 0

            # Sheet名匹配
            for kw in sig['sheet_name_kw']:
                if kw.lower() in sheet_name.lower():
                    score += 3

            # 内容匹配：前5行
            for rn, cells in rows_data[:5]:
                for cell in cells:
                    for kw in sig['required']:
                        if kw in cell:
                            score += 2
                    for kw in sig['optional']:
                        if kw in cell:
                            score += 1

            if score > 0:
                scores[stmt_type] = score

        if scores:
            return max(scores, key=scores.get)
        return None

    def _find_header_row(self, rows_data: List[Tuple[int, List[str]]]) -> Optional[int]:
        """找最像表头行的行（含最多金额关键词的行）"""
        best_row = None
        best_score = 0

        # 所有金额关键词
        all_amount_kws = []
        for kws in AMOUNT_KEYWORDS.values():
            all_amount_kws.extend(kws)
        all_amount_kws = set(all_amount_kws)

        for rn, cells in rows_data:
            score = 0
            for cell in cells:
                for kw in all_amount_kws:
                    if kw in cell:
                        score += 1
                for kw in ITEM_NAME_KEYWORDS:
                    if kw in cell:
                        score += 1
                for kw in LINE_NUMBER_KEYWORDS:
                    if kw in cell:
                        score += 0.5
            if score > best_score:
                best_score = score
                best_row = rn

        return best_row if best_score >= 2 else 2  # 默认第2行

    def _detect_structure(self, rows_data: List[Tuple[int, List[str]]],
                          header_row: Optional[int]) -> str:
        """判断是左右对照还是单列布局"""
        if not header_row:
            return 'single'

        # 读表头行，数非空列数
        header_cells = []
        for rn, cells in rows_data:
            if rn == header_row:
                header_cells = [c for c in cells if c and c not in ('', 'None')]
                break

        # 左右对照的典型特征：6~8列，含"资产"+"负债"+"所有者权益"
        if len(header_cells) >= 6:
            has_asset = any('资产' in c for c in header_cells)
            has_liability = any('负债' in c for c in header_cells)
            has_amount_end = any(any(kw in c for kw in AMOUNT_KEYWORDS['period_end'])
                                 for c in header_cells)
            if has_asset and has_liability and has_amount_end:
                return 'dual_column_side_by_side'

        return 'single'

    def _detect_single_columns(self, header_cells: List[str]) -> Dict[str, int]:
        """在单列布局中找到各列的索引位置"""
        cols = {}

        for idx, cell in enumerate(header_cells):
            if not cell or cell in ('None', ''):
                continue
            cell = cell.strip()

            # 项目名列
            if cols.get('item_name') is None:
                for kw in ITEM_NAME_KEYWORDS:
                    if kw in cell:
                        cols['item_name'] = idx
                        break

            # 金额列
            for field, kws in AMOUNT_KEYWORDS.items():
                if cols.get(field) is not None:
                    continue
                for kw in kws:
                    if kw in cell or cell in kw:
                        cols[field] = idx
                        break

            # 行次列
            if cols.get('line_number') is None:
                for kw in LINE_NUMBER_KEYWORDS:
                    if kw in cell:
                        cols['line_number'] = idx
                        break

        return cols

    def _detect_dual_columns(self, header_cells: List[str]) -> Dict[str, Dict]:
        """在左右对照布局中识别左右两侧的各列"""
        n = len(header_cells)
        mid = n // 2  # 左右分界点（约中间）

        left_cells = header_cells[:mid]
        right_cells = header_cells[mid:]

        return {
            'left': self._detect_single_columns(left_cells),
            'right': self._detect_single_columns(right_cells),
        }

    def _build_stmt_config(self, sheet_name: str, analysis: Dict) -> Dict:
        """根据分析结果生成一个报表类型的完整配置"""
        stmt_type = analysis['type']
        config = {}

        if analysis['structure'] == 'dual_column_side_by_side':
            config['structure'] = 'dual_column_side_by_side'
            dual = analysis['dual_columns']

            # 构建 columns 定义（左右各一组）
            config['columns'] = {
                'left': self._build_column_defs(dual.get('left', {})),
                'right': self._build_column_defs(dual.get('right', {})),
            }

            # 表头
            config['header'] = {
                'row': analysis['header_row'] or 3,
            }
        else:
            config['structure'] = 'single'
            config['columns'] = self._build_column_defs(analysis.get('columns', {}))
            config['header'] = {
                'row': analysis['header_row'] or 3,
            }

        config['data_start_row'] = analysis['data_start_row']

        if self.fmt.get('type') == 'combined_file':
            config['sheet'] = sheet_name
        elif self.fmt.get('type') == 'single_file_single_sheet':
            config['sheet_name_pattern'] = sheet_name

        return config

    def _build_column_defs(self, cols: Dict[str, int]) -> List[Dict]:
        """将列位置字典转为 YAML 列定义列表"""
        defs = []
        for field, idx in sorted(cols.items(), key=lambda x: x[1]):
            if field == 'line_number':
                defs.append({
                    'field': field,
                    'index': idx,
                    'ignore': True,
                })
            else:
                defs.append({
                    'field': field,
                    'index': idx,
                })
        return defs

    def _guess_file_patterns(self, basename: str, fmt_type: str) -> Dict:
        """根据文件名猜测匹配规则"""
        patterns = {}

        if fmt_type == 'combined_file':
            # 合并文件：提取文件名的关键部分做模式
            name_no_ext = os.path.splitext(basename)[0]
            # 去掉常见后缀
            for suffix in ['资产负债表', '利润表', '现金流量表', '三大报表']:
                name_no_ext = name_no_ext.replace(suffix, '')
            if len(name_no_ext) > 8:
                # 保留开头部分作为通配模式
                prefix = name_no_ext[:8]
                patterns['combined'] = f"{prefix}*"
            else:
                patterns['combined'] = f"*{name_no_ext}*"

        elif fmt_type == 'single_file_single_sheet':
            name_no_ext = os.path.splitext(basename)[0]
            patterns['single'] = f"*{name_no_ext}*"

        return patterns

    def _generate_id(self, basename: str) -> str:
        """生成格式ID"""
        name_no_ext = os.path.splitext(basename)[0]
        # 去特殊字符，取前20字符
        clean = re.sub(r'[^a-zA-Z0-9\u4e00-\u9fff_-]', '', name_no_ext)[:20]
        return f"format_{clean}"

    def _generate_name(self, basename: str) -> str:
        """生成格式名称"""
        name_no_ext = os.path.splitext(basename)[0][:40]
        return f"自动识别-{name_no_ext}"

    def _detect_company_row(self) -> int:
        """找公司名在哪一行"""
        for sn in self.wb.sheetnames:
            ws = self.wb[sn]
            for row_idx in range(1, min(10, ws.max_row + 1)):
                for cell in ws[row_idx]:
                    if cell.value and isinstance(cell.value, str) and '编制单位' in cell.value:
                        return row_idx
        return 3  # 默认

    @property
    def fmt(self):
        return {'type': 'combined_file'}

    def close(self):
        self.wb.close()


def analyze_excel(filepath: str) -> Dict:
    """对外接口：分析 Excel 并返回格式配置"""
    wizard = FormatWizard(filepath)
    try:
        result = wizard.analyze()
        return result
    finally:
        wizard.close()


def save_format_config(config: Dict, output_path: str) -> str:
    """保存格式配置到 YAML 文件"""
    import yaml
    with open(output_path, 'w', encoding='utf-8') as f:
        yaml.dump(config, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
    return output_path


def test_on_sample(filepath: str):
    """测试分析结果"""
    wizard = FormatWizard(filepath)
    try:
        result = wizard.analyze()
        print(f"📄 {os.path.basename(filepath)}")
        print(f"   格式类型: {result['format']['type']}")
        print(f"   公司名行: {result['format']['company_name_row']}")
        for sn, analysis in wizard.sheet_analyses.items():
            print(f"\n   📑 Sheet: {sn}")
            print(f"      识别类型: {analysis.get('type', '未知')}")
            print(f"      布局: {analysis.get('structure', '未知')}")
            print(f"      表头行: {analysis.get('header_row', '未知')}")
            print(f"      列映射: {analysis.get('columns', 'N/A')}")
            if analysis.get('structure') == 'dual_column_side_by_side':
                dual = analysis.get('dual_columns', {})
                print(f"      左列: {dual.get('left', {})}")
                print(f"      右列: {dual.get('right', {})}")
        print()
        import yaml
        print(yaml.dump(result, allow_unicode=True, default_flow_style=False, sort_keys=False)[:2000])
    finally:
        wizard.close()


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        test_on_sample(sys.argv[1])
    else:
        print("Usage: python format_wizard.py <sample.xlsx>")
