"""
数据加载器 — 泛化设计，零硬编码

读取 Excel 文件 → 检测格式 → 按 YAML 映射配置解析 → 返回结构化数据

v2 改进：
  1. 内容级格式检测（不依赖文件名）
  2. 表头匹配列映射（不依赖固定列序号）
  3. 智能公司名提取（搜全表，多模式）
  4. TryAll 回退（所有格式逐一试）
"""
import os
import re
import yaml
import openpyxl
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from difflib import SequenceMatcher


# ──────────────────────────────────────────────
# 模块级：字段映射配置加载（供 FormatDetector 和 ExcelReader 共享）
# ──────────────────────────────────────────────
_FIELD_MAPPINGS_CACHE = None

def _load_field_mappings_from_yaml(path=None):
    """从 YAML 加载字段映射配置（缓存），返回 {header_keywords, bilingual_sheets, content_english_map}"""
    global _FIELD_MAPPINGS_CACHE
    if path is None:
        path = 'config/field_mappings.yaml'
    if _FIELD_MAPPINGS_CACHE is not None and path == 'config/field_mappings.yaml':
        return _FIELD_MAPPINGS_CACHE
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            data = yaml.safe_load(f) or {}
        if path == 'config/field_mappings.yaml':
            _FIELD_MAPPINGS_CACHE = data
        return data
    return {}


class FormatDetector:
    """根据文件名 **和** 内容自动检测 Excel 格式"""

    # 英文表头等价映射（类属性，可被 YAML 覆盖）
    EN_HEADER_MAP = {
        '资产': 'ASSETS', '负债': 'LIABILITIES',
        '所有者权益': "OWNER'S EQUITY", '股东权益': "SHAREHOLDERS' EQUITY",
        '期末余额': 'Ending Balance', '年初余额': 'Beginning Balance',
        '期初余额': 'Opening Balance', '上年年末余额': 'Beginning Balance',
        '项目名称': 'Item', '营业收入': 'Revenue',
        '净利润': 'Net profit', '现金流量表': 'Cash Flow',
        '经营活动': 'Operating', '投资活动': 'Investing',
        '筹资活动': 'Financing',
    }

    def __init__(self, mappings_dir: str):
        self.mappings_dir = mappings_dir
        self._formats = {}  # format_id → config
        self._load_mappings()
        # 从 YAML 加载字段映射，覆盖 EN_HEADER_MAP
        fm = _load_field_mappings_from_yaml()
        en_cfg = fm.get('content_english_map', {})
        if en_cfg:
            self.EN_HEADER_MAP.update(en_cfg)

    def _load_mappings(self):
        """加载所有映射配置，同时构建内容签名"""
        for f in sorted(os.listdir(self.mappings_dir)):
            if f.endswith(('.yaml', '.yml')):
                path = os.path.join(self.mappings_dir, f)
                with open(path, encoding='utf-8') as fp:
                    config = yaml.safe_load(fp)
                    fmt = config.get('format', {})
                    self._formats[fmt.get('id')] = config

    # ──────────────────────────────────────────────
    # 核心入口：文件名 → 内容级逐级回退
    # ──────────────────────────────────────────────

    def detect(self, filepath: str) -> Optional[Dict]:
        """
        检测文件属于哪种格式（三级回退）

        1. 文件名 fnmatch 匹配（精确路径）
        2. 内容表头匹配（看 Excel 的前几行）
        3. TryAll — 所有格式逐一尝试，取数据最丰富的
        """
        config = self._detect_by_filename(filepath)
        if config:
            return config

        config = self._detect_by_content(filepath)
        if config:
            return config

        return self._detect_by_tryall(filepath)

    # ──────────────────────────────────────────────
    # 第一级：文件名 fnmatch
    # ──────────────────────────────────────────────

    def _detect_by_filename(self, filepath: str) -> Optional[Dict]:
        filename = os.path.basename(filepath)
        for fmt_id, config in self._formats.items():
            fmt = config['format']
            rules = fmt.get('detection', {})
            import fnmatch
            for pattern in rules.get('file_patterns', {}).values():
                if fnmatch.fnmatch(filename, pattern):
                    return config
        return None

    # ──────────────────────────────────────────────
    # 第二级：内容表头匹配（核心增强）
    # ──────────────────────────────────────────────

    def _detect_by_content(self, filepath: str) -> Optional[Dict]:
        """
        读取 Excel 前几行，与各格式配置的 header signature 比对
        返回匹配度最高的格式（>60% 阈值）
        """
        try:
            wb = openpyxl.load_workbook(filepath, data_only=True)
            scores = {}
            sheet_count = len(wb.sheetnames)

            for fmt_id, config in self._formats.items():
                score = self._score_content_match(wb, config)
                if score > 0:
                    scores[fmt_id] = score

            wb.close()

            if not scores:
                return None

            # 对多Sheet文件，给 combined_file 类型加权
            multi_sheet_bonus = 0
            if sheet_count >= 3:
                multi_sheet_bonus = 0.15

            best_id = max(scores, key=lambda k: scores[k] + (
                multi_sheet_bonus if self._formats[k].get('format', {}).get('type') == 'combined_file' else 0
            ))
            raw_score = scores[best_id]
            bonus = multi_sheet_bonus if self._formats[best_id].get('format', {}).get('type') == 'combined_file' else 0
            best_score = raw_score + bonus
            return self._formats[best_id] if best_score >= 0.6 else None

        except Exception:
            return None

    def _score_content_match(self, wb, config: Dict) -> float:
        """
        用格式配置中的 header headers[] 遍历所有工作表，
        计算命中率 = 命中的表头数 / 期望的表头总数

        每张表单独评分，取最高分
        支持中英文表头匹配
        """
        fmt = config.get('format', {})
        stmt_keys = ['balance_sheet', 'income_statement', 'cash_flow_statement']
        sheet_scores = []

        # 英文表头等价映射（从类属性加载，支持 YAML 扩展）
        en_header_map = getattr(self, 'EN_HEADER_MAP', {})

        for stmt_key in stmt_keys:
            stmt_cfg = fmt.get(stmt_key, {})
            expected_headers = stmt_cfg.get('header', {}).get('headers', [])
            if not expected_headers:
                continue

            # 过滤掉"行次"这种无区分度的列
            meaningful = [h for h in expected_headers
                          if h not in ('行次', '') and not h.startswith('Unnamed')]

            if not meaningful:
                continue

            header_row = stmt_cfg.get('header', {}).get('row', 1)
            sheet_name = stmt_cfg.get('sheet') or stmt_cfg.get('sheet_name_pattern')

            # 遍历所有 Sheet，找最佳匹配
            best_hit = 0
            for sn in wb.sheetnames:
                ws = wb[sn]
                # 检查 header_row 附近 ±2 行
                for rr in range(max(1, header_row - 2), header_row + 3):
                    row_vals = []
                    for cell in ws[rr]:
                        if cell.value is not None:
                            row_vals.append(str(cell.value).strip())
                    if not row_vals:
                        continue

                    # 计算有多少期望表头出现在这一行中（中英文双语）
                    hits = 0
                    for h in meaningful:
                        if any(h in v for v in row_vals):
                            hits += 1
                            continue
                        en_key = en_header_map.get(h)
                        if en_key:
                            if any(en_key in v for v in row_vals):
                                hits += 1
                    ratio = hits / len(meaningful) if meaningful else 0
                    best_hit = max(best_hit, ratio)

            sheet_scores.append(best_hit)

        return max(sheet_scores) if sheet_scores else 0

    # ──────────────────────────────────────────────
    # 第三级：TryAll — 全部格式逐一试读
    # ──────────────────────────────────────────────

    def _detect_by_tryall(self, filepath: str) -> Optional[Dict]:
        """
        文件名和表头都匹配不到时，逐一尝试所有格式
        返回能读出最多数据行的格式
        """
        best_config = None
        best_rows = 0

        for fmt_id, config in self._formats.items():
            try:
                reader = ExcelReader(config)
                raw = reader.read_workbook(filepath)
                total = sum(
                    1 for key in ['balance_sheet', 'income_statement', 'cash_flow_statement']
                    if key in raw and raw[key].get('rows')
                )
                if total > best_rows:
                    best_rows = total
                    best_config = config
            except Exception:
                continue

        return best_config

    # ──────────────────────────────────────────────
    # 辅助工具
    # ──────────────────────────────────────────────

    def list_formats(self) -> List[Dict]:
        """列出所有支持的格式"""
        result = []
        for fid, config in self._formats.items():
            fmt = config['format']
            result.append({
                'id': fid,
                'name': fmt.get('name'),
                'type': fmt.get('type'),
            })
        return result

    def get_format(self, fmt_id: str) -> Optional[Dict]:
        """按 ID 获取格式配置"""
        return self._formats.get(fmt_id)

    def try_detect_all(self, filepath: str) -> List[Dict]:
        """
        返回所有格式的匹配信息，供 UI 让用户手动选择
        返回: [{format_id, format_name, score, sheet_names}, ...]
        """
        results = []
        try:
            wb = openpyxl.load_workbook(filepath, data_only=True)
            for fmt_id, config in self._formats.items():
                score = self._score_content_match(wb, config)
                fmt = config['format']
                results.append({
                    'format_id': fmt_id,
                    'format_name': fmt.get('name', fmt_id),
                    'score': round(score, 2),
                    'sheet_names': wb.sheetnames,
                })
            wb.close()
        except Exception:
            pass
        results.sort(key=lambda x: x['score'], reverse=True)
        return results


class FileNameParser:
    """从文件名解析公司名和报表类型"""

    @staticmethod
    def parse(filename: str, config: Dict) -> Optional[Dict]:
        fmt = config.get('format', {})
        parser_cfg = fmt.get('filename_parser', {})
        pattern = parser_cfg.get('pattern')
        if not pattern:
            return None
        match = re.match(pattern, filename)
        if match:
            return match.groupdict()
        return None


class ExcelReader:
    """通用的 Excel 读取器，按 YAML 配置解析（v2：支持表头列检测）"""

    # 常见表头字段 → 搜索关键词映射（中英文双语）
    HEADER_KEYWORDS = {
        'item_name': ['项目', '项目名称', '项目名', '资产', '负债', '权益',
                      '科目', '科目名称', 'Item', 'Items', 'Description',
                      'Particulars', 'Account', '项目名称'],
        'period_end': ['期末余额', '期末', '期未余额', '期末数',
                       'Ending Balance', 'Closing Balance', 'End Balance',
                       '期末余额'],
        'period_begin': ['年初余额', '期初余额', '上年年末余额', '年初', '期初',
                         'Beginning Balance', 'Opening Balance',
                         '上年年末余额'],
        'period_month': ['本月金额', '本期金额', '本月',
                         'Current Period', 'Current Month', 'Month',
                         '本期金额'],
        'period_year': ['本年累计金额', '本年金额', '本年累计', '本年',
                        'Year to Date', 'YTD', 'Annual', 'Current Year',
                        '本年累计金额'],
        'period_last': ['上期金额', '上年金额', '上期',
                        'Prior Period', 'Previous Period', 'Last Year',
                        '上期金额'],
        'line_number': ['行次', '行号', '序号', 'Line', 'No.', 'Seq',
                        '行次'],
    }

    # Sheet名中英文对照（类属性，可被 YAML 覆盖）
    BILINGUAL_SHEETS = {
        '资产负债表': ['Balance Sheet', 'balance sheet', 'BALANCE SHEET'],
        '利润表': ['Income Statement', 'income statement', 'INCOME STATEMENT',
                  'Profit and Loss', 'P&L', '损益表'],
        '现金流量表': ['Cash Flow Statement', 'cash flow statement', 'CASH FLOW',
                      'Cash Flow', '现金流'],
    }

    # 英文表头等价映射（类属性，可被 YAML 覆盖）
    EN_HEADER_MAP = {
        '资产': 'ASSETS', '负债': 'LIABILITIES',
        '所有者权益': "OWNER'S EQUITY", '股东权益': "SHAREHOLDERS' EQUITY",
        '期末余额': 'Ending Balance', '年初余额': 'Beginning Balance',
        '期初余额': 'Opening Balance', '上年年末余额': 'Beginning Balance',
        '项目名称': 'Item', '营业收入': 'Revenue',
        '净利润': 'Net profit', '现金流量表': 'Cash Flow',
        '经营活动': 'Operating', '投资活动': 'Investing',
        '筹资活动': 'Financing',
    }

    FIELD_MAPPINGS_PATH = 'config/field_mappings.yaml'

    def __init__(self, config: Dict):
        self.config = config
        self.fmt = config.get('format', {})
        # 从 YAML 加载字段映射，覆盖类默认值
        self._load_field_mappings()

    def _load_field_mappings(self):
        """从 YAML 加载字段映射配置，覆盖类默认值"""
        data = _load_field_mappings_from_yaml(
            os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         '..', self.FIELD_MAPPINGS_PATH)
        )
        if data.get('header_keywords'):
            self.HEADER_KEYWORDS = {k: v if isinstance(v, list) else [v]
                                    for k, v in data['header_keywords'].items()}
        if data.get('bilingual_sheets'):
            self.BILINGUAL_SHEETS = {k: v if isinstance(v, list) else [v]
                                     for k, v in data['bilingual_sheets'].items()}
        if data.get('content_english_map'):
            self.EN_HEADER_MAP.update(data['content_english_map'])

    def read_workbook(self, filepath: str) -> Dict[str, Any]:
        try:
            wb = openpyxl.load_workbook(filepath, data_only=True)
        except openpyxl.utils.exceptions.InvalidFileException:
            raise ValueError(f"文件可能已加密或格式不兼容: {filepath}")
        except Exception as e:
            raise ValueError(f"文件损坏或无法读取: {filepath}") from e
        result = {'company_name': None, 'period': None}

        fmt_type = self.fmt.get('type')

        if fmt_type == 'separate_files':
            result.update(self._read_separate(wb, filepath))
        elif fmt_type == 'combined_file':
            result.update(self._read_combined(wb))
        elif fmt_type == 'single_file_single_sheet':
            result.update(self._read_single(wb))
        else:
            raise ValueError(f"未知的格式类型: {fmt_type}")

        # 智能公司名提取（多模式搜索）
        result['company_name'] = self._extract_company_name(wb)
        # 文件名中也尝试提取
        if not result['company_name']:
            result['company_name'] = self._extract_company_from_filename(filepath)

        wb.close()
        return result

    # ──────────────────────────────────────────────
    # 智能公司名提取（核心改进）
    # ──────────────────────────────────────────────

    COMPANY_PATTERNS = [
        '编制单位', '单位名称', '企业名称', '公司名称',
        '公司', '单位', 'ReportUnit', 'Company',
        'Reporting Entity', 'Entity Name', 'Company Name',
        'Enterprise', 'Corporation',
    ]

    def _extract_company_name(self, wb) -> str:
        """
        智能提取公司名（v2 改进）

        1. 先尝试配置中指定的行（快速路径）
        2. 搜所有 Sheet 的前 10 行（全面回退）
        """
        # 阶段 1: 配置指定行
        source = self.fmt.get('company_name_source', 'filename')
        if source == 'excel_content':
            row_num = self.fmt.get('company_name_row', 3)
            found = self._search_company_in_row(wb, row_num)
            if found:
                return found

        # 阶段 2: 搜所有 Sheet 前10行
        for rr in range(1, 11):
            found = self._search_company_in_row(wb, rr)
            if found:
                return found

        return ''

    def _search_company_in_row(self, wb, row_num: int) -> str:
        """在指定行号中按模式搜索公司名"""
        for sn in wb.sheetnames:
            ws = wb[sn]
            for row in ws.iter_rows(min_row=row_num, max_row=row_num, values_only=True):
                for cell in row:
                    if cell and isinstance(cell, str):
                        for pat in self.COMPANY_PATTERNS:
                            if pat in cell:
                                # 提取公司名：去掉前缀
                                cleaned = cell
                                for prefix in [f'{pat}：', f'{pat}:', f'{pat}']:
                                    if cleaned.startswith(prefix):
                                        cleaned = cleaned[len(prefix):]
                                return cleaned.strip()
        return ''

    def _extract_company_from_filename(self, filepath: str) -> str:
        """从文件名猜测公司名（作为最后手段）"""
        fname = os.path.basename(filepath)
        # 去掉扩展名
        fname = os.path.splitext(fname)[0]
        # 去掉明显不是公司名的部分
        skip_words = ['资产负债表', '利润表', '现金流量表', '三大报表',
                      '月报', '年报', '202', '2026', '2025']
        for word in skip_words:
            fname = fname.replace(word, '')
        # 取第一段包含"公司"或"有限"的部分
        parts = re.split(r'[_-]', fname)
        for p in parts:
            if '公司' in p or '有限' in p or '企业' in p:
                return p.strip()
        # 如果都没有，返回去掉杂质的名字
        return fname.strip('-').strip('_').strip()

    # ──────────────────────────────────────────────
    # 动态列映射（核心改进）
    # ──────────────────────────────────────────────

    def _resolve_columns_by_headers(self, ws, stmt_cfg: Dict,
                                    raw_cols: Any) -> Tuple[Any, bool]:
        """
        根据实际表头行，动态解析列位置

        返回: (resolved_cols, success)
          - resolved_cols: 与 raw_cols 结构一致，但 index 已更新
          - success: True 如果成功匹配
        """
        header_row = stmt_cfg.get('header', {}).get('row', 1)
        expected_headers = stmt_cfg.get('header', {}).get('headers', [])

        # 读取实际表头行
        actual_headers = []
        for cell in ws[header_row]:
            actual_headers.append(str(cell.value).strip() if cell.value else '')

        # 只有有意义时才使用表头匹配
        meaningful_actual = [h for h in actual_headers if h and h not in ('', 'None')]
        if len(meaningful_actual) < 2:
            return raw_cols, False

        # 构建：期望表头 → 实际列位置 映射（支持重复表头）
        header_to_index = {}
        expect_counts = {}  # 跟踪每个期望表头出现的次数
        for expect in expected_headers:
            if not expect or expect in ('行次', 'Unnamed'):
                continue
            expect_counts[expect] = expect_counts.get(expect, 0) + 1
            target_occ = expect_counts[expect]
            # 找到实际表头中第 target_occ 次出现的位置
            found_idx = None
            occ_count = 0
            for i, actual in enumerate(actual_headers):
                if actual == expect:
                    occ_count += 1
                    if occ_count == target_occ:
                        found_idx = i
                        break
            if found_idx is None:
                # 精确匹配第 N 次失败，尝试模糊匹配
                occ_count = 0
                for i, actual in enumerate(actual_headers):
                    if expect in actual or actual in expect:
                        occ_count += 1
                        if occ_count == target_occ:
                            found_idx = i
                            break
            if found_idx is not None:
                header_to_index.setdefault(expect, []).append(found_idx)

        # 检查是否足够匹配（至少匹配到 item_name + 一个金额列）
        matched_keys = set(header_to_index.keys())
        has_item = any('资产' in k or '项目' in k or '负债' in k
                       for k in matched_keys)
        has_amount = any('余额' in k or '金额' in k or '累计' in k
                         for k in matched_keys)
        if not (has_item and has_amount):
            return raw_cols, False

        # 生成 resolved 列配置
        def _resolve_col_group(col_group):
            resolved = []
            for col_def in col_group:
                field = col_def.get('field', '')
                default_idx = col_def.get('index', 0)

                # 尝试通过 HEADER_KEYWORDS 反向匹配
                keywords = self.HEADER_KEYWORDS.get(field, [field])
                new_idx = None
                # 优先从 default_idx 附近的预期表头开始匹配（左右侧区分）
                search_range = range(len(expected_headers))
                # 如果 default_idx > 0，优先搜索对应的预期表头范围
                if default_idx > 0:
                    search_range = list(range(default_idx, min(default_idx + 4, len(expected_headers)))) + \
                                   list(range(max(0, default_idx - 2), default_idx))
                for expect_idx in search_range:
                    expect_h = expected_headers[expect_idx]
                    for kw in keywords:
                        if kw in expect_h:
                            # 找到了匹配的期望表头，取对应 occurrence 的实际列位置
                            if expect_h in header_to_index:
                                positions = header_to_index[expect_h]
                                # 计算 expect_h 在 expected_headers 中到 expect_idx 为止出现次数
                                occ = sum(1 for h in expected_headers[:expect_idx+1] if h == expect_h)
                                if occ <= len(positions):
                                    new_idx = positions[occ - 1]
                                else:
                                    new_idx = positions[-1]
                                break
                    if new_idx is not None:
                        break

                resolved.append({
                    **col_def,
                    'index': new_idx if new_idx is not None else default_idx,
                    '_matched': new_idx is not None,
                })
            return resolved

        if isinstance(raw_cols, dict):
            return {
                'left': _resolve_col_group(raw_cols.get('left', [])),
                'right': _resolve_col_group(raw_cols.get('right', [])),
            }, True
        else:
            return _resolve_col_group(raw_cols), True

    # ──────────────────────────────────────────────
    # 读取一页 Sheet
    # ──────────────────────────────────────────────

    def _read_sheet_by_config(self, ws, stmt_cfg: Dict) -> Dict:
        header_cfg = stmt_cfg.get('header', {})
        data_start = stmt_cfg.get('data_start_row', 1)
        raw_cols = stmt_cfg.get('columns', [])
        structure = stmt_cfg.get('structure', 'single')

        # 尝试动态列映射
        resolved_cols, use_dynamic = self._resolve_columns_by_headers(
            ws, stmt_cfg, raw_cols
        )

        cols = resolved_cols if use_dynamic else raw_cols

        # 解析列配置
        if isinstance(cols, dict):
            left_cols = cols.get('left', [])
            right_cols = cols.get('right', [])
            all_cols = left_cols + right_cols
        else:
            left_cols = []
            right_cols = []
            all_cols = cols

        def _extract_val(v):
            if v is None:
                return 0
            try:
                return float(v) if '.' in str(v) else int(v)
            except (ValueError, TypeError):
                return v

        def _build_row_dict(cols_def, row_cells):
            d = {}
            for col_def in cols_def:
                field = col_def.get('field', '')
                idx = col_def.get('index', 0)
                ignore = col_def.get('ignore', False)
                if not ignore and idx < len(row_cells):
                    d[field] = _extract_val(row_cells[idx])
                elif field not in d:
                    d[field] = 0 if not ignore else None
            return d

        rows = []
        for row_idx, row_cells in enumerate(
            ws.iter_rows(min_row=data_start, values_only=True), start=data_start
        ):
            if structure == 'dual_column_side_by_side':
                left_data = _build_row_dict(left_cols, row_cells)
                right_data = _build_row_dict(right_cols, row_cells)
                if left_data.get('item_name') or right_data.get('item_name'):
                    rows.append({
                        'row': row_idx,
                        'left': left_data,
                        'right': right_data,
                    })
            else:
                row_data = _build_row_dict(all_cols, row_cells)
                if row_data.get('item_name'):
                    rows.append({
                        'row': row_idx,
                        'data': row_data,
                    })

        return {
            'config': stmt_cfg,
            'rows': rows,
            '_dynamic_mapping': use_dynamic,
        }

    # ──────────────────────────────────────────────
    # 三种文件组织模式
    # ──────────────────────────────────────────────

    def _read_separate(self, wb, filepath: str) -> Dict:
        """分开文件模式（每文件一报表）"""
        result = {}
        sn = wb.sheetnames[0]
        ws = wb[sn]

        filename = os.path.basename(filepath)
        parsed = FileNameParser.parse(filename, self.config)

        if parsed:
            stmt_type = parsed.get('statement_type', '')
            if '资产负债表' in stmt_type:
                result['balance_sheet'] = self._read_sheet_by_config(ws, self.fmt.get('balance_sheet', {}))
            elif '利润表' in stmt_type:
                result['income_statement'] = self._read_sheet_by_config(ws, self.fmt.get('income_statement', {}))
            elif '现金流量表' in stmt_type:
                result['cash_flow_statement'] = self._read_sheet_by_config(ws, self.fmt.get('cash_flow_statement', {}))

        return result

    def _read_combined(self, wb) -> Dict:
        """合并文件模式（多 Sheet）— 支持中英文Sheet名"""
        result = {}
        sheets = {
            'balance_sheet': self.fmt.get('balance_sheet', {}),
            'income_statement': self.fmt.get('income_statement', {}),
            'cash_flow_statement': self.fmt.get('cash_flow_statement', {}),
        }

        # Sheet名中英文对照表（从 YAML 类属性加载）
        bilingual_sheets = self.BILINGUAL_SHEETS

        for key, stmt_cfg in sheets.items():
            sheet_name = stmt_cfg.get('sheet')
            if not sheet_name:
                continue

            ws = None
            # 1. 精确匹配
            if sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
            else:
                # 2. 中英文对照匹配
                cn_name = sheet_name
                en_alternatives = bilingual_sheets.get(cn_name, [])
                for alt in en_alternatives:
                    if alt in wb.sheetnames:
                        ws = wb[alt]
                        break

                # 3. 部分匹配（Sheet名包含关键词）
                if ws is None:
                    for sn in wb.sheetnames:
                        cn_kw = cn_name
                        en_kws = bilingual_sheets.get(cn_name, [])
                        all_kws = [cn_kw] + en_kws
                        for kw in all_kws:
                            if kw.lower() in sn.lower():
                                ws = wb[sn]
                                break
                        if ws:
                            break

            if ws:
                result[key] = self._read_sheet_by_config(ws, stmt_cfg)

        return result

    def _read_single(self, wb) -> Dict:
        """单 Sheet 格式（一个 Sheet 包含所有报表）"""
        result = {}
        if wb.sheetnames:
            ws = wb[wb.sheetnames[0]]
            # 尝试所有三种报表配置
            for stmt_key in ['balance_sheet', 'income_statement', 'cash_flow_statement']:
                stmt_cfg = self.fmt.get(stmt_key, {})
                if stmt_cfg:
                    parsed = self._read_sheet_by_config(ws, stmt_cfg)
                    if parsed['rows']:
                        result[stmt_key] = parsed
        return result
