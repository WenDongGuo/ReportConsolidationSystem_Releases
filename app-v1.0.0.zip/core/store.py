"""
项目持久化存储 — SQLite 关系存储 + SQL 计算

v4 架构升级:
  新增 companies 表，所有关联表通过 company_id 外键引用
  equity_structures.parent_company → parent_company_id (FK)
  
核心表:
  companies                        — 公司注册表（导入时自动注册）
  imported_records                 — 导入科目明细（含 company_id）
  import_checks                    — 合计行校验（含 company_id）
  equity_structures                — 股权结构（含 company_id, parent_company_id）
  journal_entries + lines          — 分录（含 company_id）
  consolidation_results            — 合并结果
  其余表保持不变
"""
import json
import os
import sqlite3
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

SCHEMA_VERSION = 7

# 优先使用 RCS_DATA_DIR 环境变量（Launcher 设置），否则用项目下的 output/
_RCS_DATA_DIR = os.environ.get('RCS_DATA_DIR')
if _RCS_DATA_DIR:
    DB_DIR = _RCS_DATA_DIR
else:
    DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'output')
DB_PATH = os.path.join(DB_DIR, 'projects.db')
os.makedirs(DB_DIR, exist_ok=True)


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


# ===================================================================
# Schema 版本管理
# ===================================================================

def _get_schema_version(conn) -> int:
    try:
        row = conn.execute(
            "SELECT value FROM schema_info WHERE key='version'"
        ).fetchone()
        return int(row['value']) if row else 0
    except (sqlite3.OperationalError, TypeError, ValueError):
        return 0


def _set_schema_version(conn, version: int):
    conn.execute("""
        INSERT INTO schema_info (key, value) VALUES ('version', ?)
        ON CONFLICT(key) DO UPDATE SET value=excluded.value
    """, (str(version),))
    conn.commit()


# ===================================================================
# 公司注册（核心基础）
# ===================================================================

def register_company(project_id: int, company_name: str) -> int:
    """注册公司，存在则返回已有 ID，不存在则新建"""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id FROM companies WHERE project_id=? AND name=?",
            (project_id, company_name)
        ).fetchone()
        if row:
            return row['id']
        cur = conn.execute(
            "INSERT INTO companies (project_id, name) VALUES (?, ?)",
            (project_id, company_name)
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def register_companies(project_id: int, company_names: List[str]) -> Dict[str, int]:
    """批量注册公司，返回 {公司名: id} 映射"""
    mapping = {}
    for name in company_names:
        if name and name not in mapping:
            mapping[name] = register_company(project_id, name)
    return mapping


def get_company_mapping(project_id: int) -> Dict[str, int]:
    """获取项目内 {公司名: id} 映射"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT id, name FROM companies WHERE project_id=?", (project_id,)
        ).fetchall()
        return {r['name']: r['id'] for r in rows}
    finally:
        conn.close()


def get_company_name(company_id: int) -> str:
    """根据 ID 获取公司名"""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT name FROM companies WHERE id=?", (company_id,)
        ).fetchone()
        return row['name'] if row else ''
    finally:
        conn.close()


def get_companies(project_id: int) -> List[Dict]:
    """获取项目内公司列表"""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT id, name, created_at FROM companies WHERE project_id=? ORDER BY id",
            (project_id,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ===================================================================
# 初始化 + 迁移
# ===================================================================

def init_db():
    conn = get_db()
    try:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS schema_info (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL DEFAULT ''
            );
        """)
        conn.commit()
        current_ver = _get_schema_version(conn)
        if current_ver < 3:
            _migrate_to_v3(conn, current_ver)
        if current_ver < 4:
            _migrate_to_v4(conn)
        if current_ver < 5:
            _migrate_to_v5(conn)
        if current_ver < 6:
            _migrate_to_v6(conn)
        if current_ver < 7:
            _migrate_to_v7(conn)
        _create_tables(conn)
        _set_schema_version(conn, SCHEMA_VERSION)
    finally:
        conn.close()


def _create_tables(conn):
    """创建所有表（v4 版，幂等）"""
    conn.executescript("""
        -- 公司注册表
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id),
            UNIQUE(project_id, name)
        );

        -- 项目管理
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            current_step INTEGER DEFAULT 1,
            step_status TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS project_settings (
            project_id INTEGER PRIMARY KEY,
            selected_standard TEXT DEFAULT 'cas',
            period_start TEXT,
            period_end TEXT,
            period_label TEXT,
            report_currency TEXT DEFAULT 'CNY',
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );

        -- 导入科目明细（含 company_id）
        CREATE TABLE IF NOT EXISTS imported_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            company_id INTEGER NOT NULL DEFAULT 0,
            company TEXT NOT NULL DEFAULT '',
            account_code TEXT NOT NULL DEFAULT '',
            account_name TEXT NOT NULL DEFAULT '',
            amount REAL NOT NULL DEFAULT 0,
            period_type TEXT DEFAULT '期末余额',
            statement TEXT DEFAULT '资产负债表',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id),
            FOREIGN KEY (company_id) REFERENCES companies(id)
        );
        CREATE INDEX IF NOT EXISTS idx_ir_project ON imported_records(project_id);
        CREATE INDEX IF NOT EXISTS idx_ir_cid ON imported_records(company_id);
        CREATE INDEX IF NOT EXISTS idx_ir_code ON imported_records(project_id, account_code);

        -- 合计行校验（含 company_id）
        CREATE TABLE IF NOT EXISTS import_checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            company_id INTEGER NOT NULL DEFAULT 0,
            company TEXT NOT NULL DEFAULT '',
            total_name TEXT NOT NULL DEFAULT '',
            computed_value REAL DEFAULT 0,
            reported_value REAL DEFAULT 0,
            difference REAL DEFAULT 0,
            passed INTEGER DEFAULT 1,
            period_type TEXT DEFAULT '',
            statement TEXT DEFAULT '',
            FOREIGN KEY (project_id) REFERENCES projects(id),
            FOREIGN KEY (company_id) REFERENCES companies(id)
        );
        CREATE INDEX IF NOT EXISTS idx_ic_project ON import_checks(project_id);
        CREATE INDEX IF NOT EXISTS idx_ic_cid ON import_checks(company_id);

        -- 股权结构（含 company_id, parent_company_id）
        CREATE TABLE IF NOT EXISTS equity_structures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            company_id INTEGER NOT NULL DEFAULT 0,
            company TEXT NOT NULL DEFAULT '',
            parent_company_id INTEGER DEFAULT NULL,
            parent_company TEXT DEFAULT '',
            ownership_pct REAL DEFAULT 0,
            voting_pct REAL DEFAULT 0,
            consolidation_method TEXT DEFAULT '',
            control_judgment TEXT DEFAULT '',
            consolidation_start_date TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id),
            FOREIGN KEY (company_id) REFERENCES companies(id),
            FOREIGN KEY (parent_company_id) REFERENCES companies(id)
        );
        CREATE INDEX IF NOT EXISTS idx_es_project ON equity_structures(project_id);
        CREATE INDEX IF NOT EXISTS idx_es_cid ON equity_structures(company_id);

        -- 分录头（含 company_id）
        CREATE TABLE IF NOT EXISTS journal_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            entry_id INTEGER NOT NULL,
            company_id INTEGER NOT NULL DEFAULT 0,
            company TEXT NOT NULL DEFAULT '',
            description TEXT DEFAULT '',
            date TEXT DEFAULT '',
            context TEXT DEFAULT '',
            adjust_type TEXT DEFAULT '期末',
            version INTEGER DEFAULT 1,
            created_at TEXT DEFAULT '',
            modified_at TEXT DEFAULT '',
            modified_by TEXT DEFAULT '',
            is_deleted INTEGER DEFAULT 0,
            deleted_at TEXT DEFAULT '',
            is_readonly INTEGER DEFAULT 0,
            FOREIGN KEY (project_id) REFERENCES projects(id),
            FOREIGN KEY (company_id) REFERENCES companies(id)
        );
        CREATE INDEX IF NOT EXISTS idx_je_project ON journal_entries(project_id);
        CREATE INDEX IF NOT EXISTS idx_je_cid ON journal_entries(company_id);
        CREATE INDEX IF NOT EXISTS idx_je_context ON journal_entries(project_id, context);

        -- 分录行
        CREATE TABLE IF NOT EXISTS journal_entry_lines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_fk INTEGER NOT NULL,
            side TEXT NOT NULL,
            account_code TEXT NOT NULL DEFAULT '',
            account_name TEXT DEFAULT '',
            amount REAL DEFAULT 0,
            cf_category TEXT DEFAULT '',
            aux1 TEXT DEFAULT '',
            aux2 TEXT DEFAULT '',
            aux3 TEXT DEFAULT '',
            FOREIGN KEY (entry_fk) REFERENCES journal_entries(id)
        );
        CREATE INDEX IF NOT EXISTS idx_jel_entry ON journal_entry_lines(entry_fk);

        -- 合并结果
        CREATE TABLE IF NOT EXISTS consolidation_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            account_code TEXT NOT NULL DEFAULT '',
            account_name TEXT DEFAULT '',
            amount REAL DEFAULT 0,
            report_type TEXT DEFAULT '',
            period_type TEXT DEFAULT '',
            source TEXT DEFAULT 'aggregate',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
        CREATE INDEX IF NOT EXISTS idx_cr_project ON consolidation_results(project_id);

        -- 校验结果
        CREATE TABLE IF NOT EXISTS validation_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            company TEXT DEFAULT '',
            rule_id INTEGER DEFAULT 0,
            rule_name TEXT DEFAULT '',
            expected TEXT DEFAULT '',
            actual TEXT DEFAULT '',
            diff TEXT DEFAULT '',
            passed INTEGER DEFAULT 1,
            detail TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
        CREATE INDEX IF NOT EXISTS idx_vr_project ON validation_results(project_id);

        -- 外币折算
        CREATE TABLE IF NOT EXISTS currency_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            company TEXT DEFAULT '',
            currency TEXT DEFAULT 'CNY',
            period_rates TEXT DEFAULT '{}',
            translation_results TEXT DEFAULT '{}',
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
        CREATE INDEX IF NOT EXISTS idx_cd_project ON currency_data(project_id);

        -- 内部往来配对
        CREATE TABLE IF NOT EXISTS internal_pairs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            parent_account TEXT NOT NULL,
            subsidiary_account TEXT NOT NULL,
            description TEXT DEFAULT '',
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
        CREATE INDEX IF NOT EXISTS idx_ip_project ON internal_pairs(project_id);

        -- 自动联动分录
        CREATE TABLE IF NOT EXISTS auto_adjustments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            source_entry_id INTEGER DEFAULT 0,
            reason TEXT DEFAULT '',
            target TEXT DEFAULT '',
            entries_json TEXT DEFAULT '[]',
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
        CREATE INDEX IF NOT EXISTS idx_aa_project ON auto_adjustments(project_id);
    """)
    conn.commit()


def _migrate_to_v4(conn):
    """v3 → v4: 创建 companies 表，加 company_id 列，从现有数据注册公司"""
    # 先加列（表已存在时 ALTER）
    for col_sql in [
        "ALTER TABLE imported_records ADD COLUMN company_id INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE import_checks ADD COLUMN company_id INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE equity_structures ADD COLUMN company_id INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE equity_structures ADD COLUMN parent_company_id INTEGER DEFAULT NULL",
        "ALTER TABLE journal_entries ADD COLUMN company_id INTEGER NOT NULL DEFAULT 0",
    ]:
        try:
            conn.execute(col_sql)
        except sqlite3.OperationalError:
            pass  # 列已存在

    # 创建 companies 表
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id),
            UNIQUE(project_id, name)
        );
    """)
    conn.commit()

    project_ids = [r['id'] for r in conn.execute("SELECT id FROM projects").fetchall()]
    for pid in project_ids:
        # 用 INSERT OR IGNORE 替代 DELETE+INSERT，避免 FK 约束冲突
        rows = conn.execute(
            "SELECT DISTINCT company FROM imported_records WHERE project_id=? AND company!=''",
            (pid,)
        ).fetchall()
        for r in rows:
            conn.execute("""
                INSERT OR IGNORE INTO companies (project_id, name) VALUES (?, ?)
            """, (pid, r['company']))

        # 更新 company_id
        for r in rows:
            row2 = conn.execute(
                "SELECT id FROM companies WHERE project_id=? AND name=?", (pid, r['company'])
            ).fetchone()
            if row2:
                conn.execute(
                    "UPDATE imported_records SET company_id=? WHERE project_id=? AND company=?",
                    (row2['id'], pid, r['company'])
                )
                conn.execute(
                    "UPDATE import_checks SET company_id=? WHERE project_id=? AND company=?",
                    (row2['id'], pid, r['company'])
                )

        # equity_structures
        eq_rows = conn.execute(
            "SELECT DISTINCT company FROM equity_structures WHERE project_id=? AND company!=''",
            (pid,)
        ).fetchall()
        for r in eq_rows:
            conn.execute("""
                INSERT OR IGNORE INTO companies (project_id, name) VALUES (?, ?)
            """, (pid, r['company']))

        mapping = {}
        for r in conn.execute(
            "SELECT id, name FROM companies WHERE project_id=?", (pid,)
        ).fetchall():
            mapping[r['name']] = r['id']

        for name, cid in mapping.items():
            conn.execute(
                "UPDATE equity_structures SET company_id=? WHERE project_id=? AND company=?",
                (cid, pid, name)
            )

        # parent_company → parent_company_id
        parent_rows = conn.execute(
            "SELECT DISTINCT parent_company FROM equity_structures WHERE project_id=? AND parent_company!=''",
            (pid,)
        ).fetchall()
        for pr in parent_rows:
            pcid = mapping.get(pr['parent_company'])
            if pcid:
                conn.execute(
                    "UPDATE equity_structures SET parent_company_id=? WHERE project_id=? AND parent_company=?",
                    (pcid, pid, pr['parent_company'])
                )

        # journal_entries
        je_rows = conn.execute(
            "SELECT DISTINCT company FROM journal_entries WHERE project_id=? AND company!=''",
            (pid,)
        ).fetchall()
        for r in je_rows:
            conn.execute("""
                INSERT OR IGNORE INTO companies (project_id, name) VALUES (?, ?)
            """, (pid, r['company']))

        for r in je_rows:
            row2 = conn.execute(
                "SELECT id FROM companies WHERE project_id=? AND name=?", (pid, r['company'])
            ).fetchone()
            if row2:
                conn.execute(
                    "UPDATE journal_entries SET company_id=? WHERE project_id=? AND company=?",
                    (row2['id'], pid, r['company'])
                )

    conn.commit()


def _migrate_to_v5(conn):
    """v4 → v5: project_settings 增加 import_results 列（JSON）"""
    try:
        conn.execute("ALTER TABLE project_settings ADD COLUMN import_results TEXT DEFAULT '[]'")
        conn.commit()
    except sqlite3.OperationalError:
        pass  # 列已存在


def _migrate_to_v6(conn):
    """v5 → v6: project_settings 增加 extra_data 列（JSON）"""
    try:
        conn.execute("ALTER TABLE project_settings ADD COLUMN extra_data TEXT DEFAULT '{}'")
        conn.commit()
    except sqlite3.OperationalError:
        pass  # 列已存在


def _migrate_to_v7(conn):
    """v6 → v7: 添加分录表唯一索引 (project_id, context, entry_id)，清理重复"""
    # 先清理重复行：保留最新一条，删除旧副本
    dupes = conn.execute("""
        SELECT project_id, context, entry_id, COUNT(*) as cnt
        FROM journal_entries
        GROUP BY project_id, context, entry_id
        HAVING cnt > 1
    """).fetchall()
    for d in dupes:
        rows = conn.execute("""
            SELECT id FROM journal_entries
            WHERE project_id=? AND context=? AND entry_id=?
            ORDER BY id DESC
        """, (d['project_id'], d['context'], d['entry_id'])).fetchall()
        for r in rows[1:]:
            conn.execute("DELETE FROM journal_entry_lines WHERE entry_fk=?", (r['id'],))
            conn.execute("DELETE FROM journal_entries WHERE id=?", (r['id'],))
    conn.commit()
    try:
        conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_je_unique
            ON journal_entries(project_id, context, entry_id)
        """)
        conn.commit()
    except sqlite3.OperationalError:
        pass


def _migrate_to_v3(conn, from_ver):
    """旧版 JSON-blob → v3 关系表"""
    _create_tables(conn)
    old_tables = [
        t['name'] for t in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name IN "
            "('records','equity_config','adjustments','consolidation_data','translation_data','validation_data')"
        ).fetchall()
    ]
    if not old_tables:
        return
    project_ids = [r['id'] for r in conn.execute("SELECT id FROM projects").fetchall()]
    for pid in project_ids:
        _migrate_project_data(conn, pid, old_tables)
    conn.execute("""
        INSERT INTO schema_info (key, value) VALUES ('v3_migrated', '1')
        ON CONFLICT(key) DO UPDATE SET value='1'
    """)
    conn.commit()


def _migrate_project_data(conn, pid, old_tables):
    """从 JSON blob 迁移单个项目（简版，已不再执行）"""
    pass  # 已有数据，v4 迁移会补全 company_id


# ===================================================================
# CRUD: 科目数据 (imported_records + import_checks)
# ===================================================================

def save_imported_records(project_id: int, records: List[Dict], checks: Optional[List[Dict]] = None):
    """保存导入的科目明细（先删后插），自动注册公司"""
    # 先注册所有公司
    company_names = set()
    for r in records:
        name = r.get('company', '') or r.get('公司', '')
        if name:
            company_names.add(name)
    if checks:
        for c in checks:
            name = c.get('公司', c.get('company', ''))
            if name:
                company_names.add(name)

    mapping = register_companies(project_id, list(company_names))

    conn = get_db()
    try:
        conn.execute("DELETE FROM imported_records WHERE project_id=?", (project_id,))
        if checks is not None:
            conn.execute("DELETE FROM import_checks WHERE project_id=?", (project_id,))

        for r in records:
            name = r.get('company', '') or r.get('公司', '')
            cid = mapping.get(name, 0)
            conn.execute("""
                INSERT INTO imported_records
                    (project_id, company_id, company, account_code, account_name, amount, period_type, statement)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                project_id, cid, name,
                r.get('科目编码', r.get('account_code', '')),
                r.get('科目名称', r.get('account_name', '')),
                float(r.get('金额', r.get('amount', 0))),
                r.get('期间类型', r.get('period_type', '期末余额')),
                r.get('报表', r.get('statement', '资产负债表')),
            ))

        if checks:
            for c in checks:
                name = c.get('公司', c.get('company', ''))
                cid = mapping.get(name, 0)
                conn.execute("""
                    INSERT INTO import_checks
                        (project_id, company_id, company, total_name, computed_value, reported_value,
                         difference, passed, period_type, statement)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    project_id, cid, name,
                    c.get('合计项目', c.get('total_name', '')),
                    float(c.get('计算值', c.get('computed_value', 0))),
                    float(c.get('报告值', c.get('reported_value', 0))),
                    float(c.get('差异', c.get('difference', 0))),
                    1 if c.get('是否一致', c.get('passed', True)) else 0,
                    c.get('期间类型', c.get('period_type', '')),
                    c.get('报表', c.get('statement', '')),
                ))

        conn.commit()
    finally:
        conn.close()


def load_imported_records(project_id: int) -> Dict:
    """加载导入的科目明细"""
    conn = get_db()
    try:
        rows = conn.execute("""
            SELECT ir.*, c.name AS company_name
            FROM imported_records ir
            LEFT JOIN companies c ON ir.company_id = c.id
            WHERE ir.project_id=?
            ORDER BY ir.company, ir.account_code
        """, (project_id,)).fetchall()
        records = [{
            'company': r['company_name'] or r['company'],
            '科目编码': r['account_code'],
            '科目名称': r['account_name'],
            '金额': r['amount'],
            '期间类型': r['period_type'],
            '报表': r['statement'],
            'company_id': r['company_id'],
        } for r in rows]

        check_rows = conn.execute("""
            SELECT ic.*, c.name AS company_name
            FROM import_checks ic
            LEFT JOIN companies c ON ic.company_id = c.id
            WHERE ic.project_id=?
        """, (project_id,)).fetchall()
        checks = [{
            '公司': chk['company_name'] or chk['company'],
            '合计项目': chk['total_name'],
            '计算值': chk['computed_value'],
            '报告值': chk['reported_value'],
            '差异': chk['difference'],
            '是否一致': bool(chk['passed']),
            '期间类型': chk['period_type'],
            '报表': chk['statement'],
        } for chk in check_rows]

        return {'data': records, 'checks': checks, 'files': []}
    finally:
        conn.close()


def get_imported_records_count(project_id: int) -> int:
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS cnt FROM imported_records WHERE project_id=?",
            (project_id,)
        ).fetchone()
        return row['cnt'] if row else 0
    finally:
        conn.close()


def get_imported_companies(project_id: int) -> List[str]:
    """查询已导入的公司列表（通过 companies 表）"""
    conn = get_db()
    try:
        rows = conn.execute("""
            SELECT DISTINCT c.name
            FROM imported_records ir
            JOIN companies c ON ir.company_id = c.id
            WHERE ir.project_id=?
            ORDER BY c.name
        """, (project_id,)).fetchall()
        return [r['name'] for r in rows if r['name']]
    finally:
        conn.close()


def query_company_summary(project_id: int) -> List[Dict]:
    conn = get_db()
    try:
        rows = conn.execute("""
            SELECT c.name AS company, ir.account_code, ir.account_name,
                   SUM(ir.amount) AS total_amount,
                   ir.statement, ir.period_type
            FROM imported_records ir
            JOIN companies c ON ir.company_id = c.id
            WHERE ir.project_id=?
            GROUP BY ir.company_id, ir.account_code, ir.statement, ir.period_type
            ORDER BY c.name, ir.account_code
        """, (project_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ===================================================================
# CRUD: 股权结构 (equity_structures)
# ===================================================================

def save_equity(project_id: int, data: List[Dict]):
    """保存股权结构，自动解析公司名 → company_id / parent_company_id"""
    # 先收集所有公司名并注册
    company_names = set()
    for eq in data:
        name = eq.get('公司', eq.get('company', ''))
        if name:
            company_names.add(name)
        parent = eq.get('其母公司', eq.get('parent_company', ''))
        if parent:
            company_names.add(parent)

    mapping = register_companies(project_id, list(company_names))

    conn = get_db()
    try:
        conn.execute("DELETE FROM equity_structures WHERE project_id=?", (project_id,))
        for eq in data:
            name = eq.get('公司', eq.get('company', ''))
            cid = mapping.get(name, 0)
            parent = eq.get('其母公司', eq.get('parent_company', ''))
            pcid = mapping.get(parent) if parent else None
            conn.execute("""
                INSERT INTO equity_structures
                    (project_id, company_id, company, parent_company_id, parent_company,
                     ownership_pct, voting_pct, consolidation_method, control_judgment, consolidation_start_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                project_id, cid, name, pcid, parent,
                float(eq.get('持股比例(%)', eq.get('ownership_pct', 0))),
                float(eq.get('表决权比例(%)', eq.get('voting_pct', 0))),
                eq.get('并表触发方式', eq.get('consolidation_method', '')),
                eq.get('关键判断点', eq.get('control_judgment', '')),
                eq.get('并表起点', eq.get('consolidation_start_date', '')),
            ))
        conn.commit()
    finally:
        conn.close()


def load_equity(project_id: int) -> List[Dict]:
    """加载股权结构，返回兼容旧格式的字段名"""
    conn = get_db()
    try:
        rows = conn.execute("""
            SELECT es.*, pc.name AS parent_company_name
            FROM equity_structures es
            LEFT JOIN companies pc ON es.parent_company_id = pc.id
            WHERE es.project_id=?
            ORDER BY es.id
        """, (project_id,)).fetchall()
        return [{
            '公司': r['company'],
            '其母公司': r['parent_company_name'] or r['parent_company'] or '',
            '持股比例(%)': r['ownership_pct'],
            '表决权比例(%)': r['voting_pct'],
            '并表触发方式': r['consolidation_method'],
            '关键判断点': r['control_judgment'],
            '并表起点': r['consolidation_start_date'],
        } for r in rows]
    finally:
        conn.close()


# ===================================================================
# CRUD: 分录 (journal_entries + lines)
# ===================================================================

def upsert_journal_entry(project_id: int, entry_dict: Dict, context: str = '') -> int:
    """更新或插入单条分录（凭证头 + 行）
    返回 entry_fk (DB 内部 PK)"""
    conn = get_db()
    try:
        # 注册公司（同一连接同一事务）
        company = entry_dict.get('company', '')
        cid = 0
        if company:
            row = conn.execute(
                "SELECT id FROM companies WHERE project_id=? AND name=?",
                (project_id, company)
            ).fetchone()
            if row:
                cid = row['id']
            else:
                cur = conn.execute(
                    "INSERT INTO companies (project_id, name) VALUES (?, ?)",
                    (project_id, company)
                )
                cid = cur.lastrowid
        eid = int(entry_dict.get('id', entry_dict.get('entry_id', 0)))
        # 查询是否已存在
        existing = conn.execute(
            "SELECT id, version FROM journal_entries WHERE project_id=? AND context=? AND entry_id=?",
            (project_id, context, eid)
        ).fetchone()

        desc = entry_dict.get('description', '')
        date_str = entry_dict.get('date', '')
        adj_type = entry_dict.get('adjust_type', '期末')
        now_str = str(datetime.now())

        lines = entry_dict.get('lines', [])

        if existing:
            # UPDATE 已有凭证头
            new_ver = existing['version'] + 1
            conn.execute("""
                UPDATE journal_entries SET
                    description=?, date=?, company=?, company_id=?,
                    adjust_type=?, version=?, modified_at=?,
                    is_readonly=?
                WHERE id=?
            """, (desc, date_str, company, cid,
                  adj_type, new_ver, now_str,
                  1 if entry_dict.get('is_readonly') else 0,
                  existing['id']))
            entry_fk = existing['id']
            # 删旧行，重插
            conn.execute("DELETE FROM journal_entry_lines WHERE entry_fk=?", (entry_fk,))
        else:
            # INSERT 新凭证头
            cursor = conn.execute("""
                INSERT INTO journal_entries
                    (project_id, entry_id, description, date, company, company_id,
                     context, adjust_type, version, created_at, modified_at,
                     modified_by, is_deleted, deleted_at, is_readonly)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (project_id, eid, desc, date_str, company, cid,
                  context, adj_type,
                  int(entry_dict.get('version', 1)),
                  entry_dict.get('created_at', now_str),
                  now_str,
                  entry_dict.get('modified_by', ''),
                  1 if entry_dict.get('is_deleted') else 0,
                  entry_dict.get('deleted_at', ''),
                  1 if entry_dict.get('is_readonly') else 0))
            entry_fk = cursor.lastrowid

        # 插入凭证行 — 涉现校验
        CASH_CODES = {'1001', '1002'}
        for line in lines:
            code = line.get('code', line.get('account_code', ''))
            cf_cat = line.get('cf_category', '')
            if code in CASH_CODES and not cf_cat:
                raise ValueError(f"货币资金({code})行必须指定现金流类别(cf_category)")
            conn.execute("""
                INSERT INTO journal_entry_lines
                    (entry_fk, side, account_code, account_name, amount,
                     cf_category, aux1, aux2, aux3)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (entry_fk,
                  line.get('side', 'debit'),
                  line.get('code', line.get('account_code', '')),
                  line.get('name', line.get('account_name', '')),
                  float(line.get('amount', 0)),
                  line.get('cf_category', ''),
                  line.get('aux1', ''),
                  line.get('aux2', ''),
                  line.get('aux3', '')))

        conn.commit()
        return entry_fk
    finally:
        conn.close()


def delete_journal_entry(project_id: int, entry_id: int, context: str) -> bool:
    """删除单条分录（凭证头 + 行）"""
    conn = get_db()
    try:
        entry = conn.execute(
            "SELECT id FROM journal_entries WHERE project_id=? AND context=? AND entry_id=?",
            (project_id, context, entry_id)
        ).fetchone()
        if entry:
            conn.execute("DELETE FROM journal_entry_lines WHERE entry_fk=?", (entry['id'],))
            conn.execute("DELETE FROM journal_entries WHERE id=?", (entry['id'],))
            conn.commit()
            return True
        return False
    finally:
        conn.close()


def save_journal_entries(project_id: int, entries: List[Dict], context: str = ''):
    """保存分录列表（增量 upsert + 自动清理已删除的分录）"""
    # 获取 DB 中现有的 entry_id 集合
    conn = get_db()
    try:
        existing_ids = set(r['entry_id'] for r in conn.execute(
            "SELECT entry_id FROM journal_entries WHERE project_id=? AND context=?",
            (project_id, context)
        ).fetchall())
    finally:
        conn.close()

    incoming_ids = set()
    for ed in entries:
        eid = int(ed.get('id', ed.get('entry_id', 0)))
        if eid:
            incoming_ids.add(eid)
        upsert_journal_entry(project_id, ed, context or ed.get('context', ''))

    # 删除未在入口中的旧分录
    stale = existing_ids - incoming_ids
    for eid in stale:
        delete_journal_entry(project_id, eid, context)


def load_journal_entries(project_id: int, context: str = '') -> List[Dict]:
    """加载分录列表（兼容 JournalEntry.to_dict() 格式）"""
    conn = get_db()
    try:
        if context:
            rows = conn.execute("""
                SELECT je.*, c.name AS company_name
                FROM journal_entries je
                LEFT JOIN companies c ON je.company_id = c.id
                WHERE je.project_id=? AND je.context=? AND je.is_deleted=0
                ORDER BY je.entry_id
            """, (project_id, context)).fetchall()
        else:
            rows = conn.execute("""
                SELECT je.*, c.name AS company_name
                FROM journal_entries je
                LEFT JOIN companies c ON je.company_id = c.id
                WHERE je.project_id=? AND je.is_deleted=0
                ORDER BY je.context, je.entry_id
            """, (project_id,)).fetchall()

        result = []
        for r in rows:
            lines = conn.execute(
                "SELECT * FROM journal_entry_lines WHERE entry_fk=? ORDER BY id",
                (r['id'],)
            ).fetchall()
            result.append({
                'id': r['entry_id'],
                'description': r['description'],
                'date': r['date'],
                'company': r['company_name'] or r['company'],
                'company_id': r['company_id'],
                'context': r['context'],
                'adjust_type': r['adjust_type'],
                'version': r['version'],
                'created_at': r['created_at'],
                'modified_at': r['modified_at'],
                'modified_by': r['modified_by'],
                'is_deleted': bool(r['is_deleted']),
                'deleted_at': r['deleted_at'],
                'is_readonly': bool(r['is_readonly']),
                'lines': [{
                    'side': l['side'],
                    'code': l['account_code'],
                    'name': l['account_name'],
                    'amount': l['amount'],
                    'cf_category': l['cf_category'],
                    'aux1': l['aux1'],
                    'aux2': l['aux2'],
                    'aux3': l['aux3'],
                } for l in lines],
            })
        return result
    finally:
        conn.close()


# ===================================================================
# CRUD: 合并结果 (consolidation_results)
# ===================================================================

def save_consolidation_results(project_id: int, records: List[Dict]):
    conn = get_db()
    try:
        conn.execute("DELETE FROM consolidation_results WHERE project_id=?", (project_id,))
        for r in records:
            conn.execute("""
                INSERT INTO consolidation_results
                    (project_id, account_code, account_name, amount, report_type, period_type)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                project_id,
                r.get('科目编码', r.get('account_code', '')),
                r.get('科目名称', r.get('account_name', '')),
                float(r.get('金额', r.get('amount', 0))),
                r.get('报表', r.get('report_type', '')),
                r.get('期间类型', r.get('period_type', '')),
            ))
        conn.commit()
    finally:
        conn.close()


def load_consolidation_results(project_id: int) -> List[Dict]:
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM consolidation_results WHERE project_id=? ORDER BY account_code",
            (project_id,)
        ).fetchall()
        return [{
            'company': '合并报表',
            '科目编码': r['account_code'],
            '科目名称': r['account_name'],
            '金额': r['amount'],
            '报表': r['report_type'],
            '期间类型': r['period_type'],
        } for r in rows]
    finally:
        conn.close()


# ===================================================================
# SQL 计算: 合并汇总
# ===================================================================

def query_consolidated(project_id: int, parent_company: str = '',
                       subsidiary_companies: List[str] = None) -> List[Dict]:
    conn = get_db()
    try:
        if subsidiary_companies:
            placeholders = ','.join('?' for _ in subsidiary_companies)
            companies = [parent_company] + subsidiary_companies if parent_company else subsidiary_companies
            rows = conn.execute(f"""
                SELECT ir.account_code, ir.account_name,
                       SUM(ir.amount) AS amount,
                       ir.statement, ir.period_type
                FROM imported_records ir
                JOIN companies c ON ir.company_id = c.id
                WHERE ir.project_id=? AND c.name IN ({placeholders})
                GROUP BY ir.account_code, ir.statement, ir.period_type
            """, (project_id, *companies)).fetchall()
        else:
            rows = conn.execute("""
                SELECT ir.account_code, ir.account_name,
                       SUM(ir.amount) AS amount,
                       ir.statement, ir.period_type
                FROM imported_records ir
                WHERE ir.project_id=?
                GROUP BY ir.account_code, ir.statement, ir.period_type
            """, (project_id,)).fetchall()

        merged = {}
        for r in rows:
            key = (r['account_code'], r['statement'] or '', r['period_type'] or '')
            merged[key] = float(r['amount'])

        # 应用抵消分录
        offset_rows = conn.execute("""
            SELECT jl.account_code, jl.account_name, jl.amount, jl.side
            FROM journal_entry_lines jl
            JOIN journal_entries je ON jl.entry_fk = je.id
            WHERE je.project_id=? AND je.is_deleted=0 AND je.context='合并抵消'
        """, (project_id,)).fetchall()

        for r in offset_rows:
            code = r['account_code']
            amt = float(r['amount'])
            side = r['side']
            from core.journal_entry import get_normal_balance
            normal = get_normal_balance(code)
            if side == 'debit':
                balance_amt = amt if normal == 'debit' else -amt
            else:
                balance_amt = -amt if normal == 'debit' else amt

            applied = False
            for mk in merged:
                if mk[0] == code:
                    merged[mk] += balance_amt
                    applied = True
                    break
            if not applied and abs(balance_amt) > 0.01:
                from core.consolidator import ConsolidationEngine
                inferred_report, inferred_period = ConsolidationEngine._infer_statement(code)
                merged[(code, inferred_report, inferred_period)] = balance_amt

        code_name_map = {}
        for r in rows:
            code_name_map[r['account_code']] = r['account_name']
        for r in offset_rows:
            if r['account_code'] not in code_name_map:
                code_name_map[r['account_code']] = r['account_name']

        result = []
        for (code, report, period), amount in merged.items():
            if abs(amount) < 0.01:
                continue
            result.append({
                'company': '合并报表',
                '科目编码': code,
                '科目名称': code_name_map.get(code, code),
                '金额': round(amount, 2),
                '报表': report,
                '期间类型': period,
            })

        result.sort(key=lambda x: x['科目编码'])
        return result
    finally:
        conn.close()


def query_company_subtotals(project_id: int) -> List[Dict]:
    conn = get_db()
    try:
        rows = conn.execute("""
            SELECT c.name AS company, ir.account_code, ir.account_name,
                   SUM(ir.amount) AS total_amount,
                   ir.statement, ir.period_type
            FROM imported_records ir
            JOIN companies c ON ir.company_id = c.id
            WHERE ir.project_id=?
            GROUP BY ir.company_id, ir.account_code, ir.statement, ir.period_type
            ORDER BY c.name, ir.account_code
        """, (project_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ===================================================================
# 批量保存/恢复（兼容旧 session 格式）
# ===================================================================

def _json_default_serializer(obj):
    """JSON 序列化默认处理器：支持 to_dict() 的对象 → dict"""
    if hasattr(obj, 'to_dict'):
        return obj.to_dict()
    return str(obj)


def save_full_state(project_id: int, state: Dict):
    """保存完整项目状态"""
    # Settings
    settings = state.get('settings', {})
    import_results_json = json.dumps(
        state.get('_import_results', []),
        ensure_ascii=False, default=str
    )
    
    # 辅助数据：所有未持久化到独立表的 session key
    extra_data = {}
    for key in ['validation_results', 'user_inputs_16', 'company_currencies',
                'period_rates_cache', 'translation_results', 'translated_records',
                'pre_consolidated_data', 'consolidation_result', 'consolidation_raw',
                'export_xlsx', 'export_json', 'export_path', 'unmatched_subjects',
                'adjustments', 'imported_files']:
        val = state.get(key)
        if val is not None and val != {} and val != []:
            extra_data[key] = val
    extra_data_json = json.dumps(extra_data, ensure_ascii=False,
                                  default=_json_default_serializer)
    
    conn = get_db()
    try:
        conn.execute("""
            INSERT INTO project_settings (project_id, selected_standard, period_start, period_end, period_label, report_currency, import_results, extra_data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(project_id) DO UPDATE SET
                selected_standard=excluded.selected_standard,
                period_start=excluded.period_start,
                period_end=excluded.period_end,
                period_label=excluded.period_label,
                report_currency=excluded.report_currency,
                import_results=excluded.import_results,
                extra_data=excluded.extra_data
        """, (
            project_id,
            settings.get('selected_standard', 'cas'),
            settings.get('period_start'),
            settings.get('period_end'),
            settings.get('period_label'),
            settings.get('report_currency', 'CNY'),
            import_results_json,
            extra_data_json,
        ))
        conn.commit()
    finally:
        conn.close()

    # 导入科目数据（先删后插，空列表=清空）
    records = state.get('all_records', [])
    checks = state.get('all_checks', [])
    save_imported_records(project_id, records, checks)

    # 股权结构
    equity = state.get('equity_config')
    if equity is not None:
        save_equity(project_id, equity)

    # 分录
    monotherapy = state.get('单体调整', {})
    if isinstance(monotherapy, dict) and hasattr(monotherapy, 'get') and monotherapy.get('__journal_mgr__'):
        from core.journal_entry import JournalManager
        mgr_data = monotherapy.get('data', {}) if isinstance(monotherapy, dict) else monotherapy.to_dict()
        if isinstance(mgr_data, dict):
            entries = mgr_data.get('entries', [])
            if entries:
                save_journal_entries(project_id, entries, '单体调整')
    elif isinstance(monotherapy, dict):
        entries_data = []
        for company, company_entries in monotherapy.items():
            if isinstance(company_entries, list):
                for e in company_entries:
                    e['company'] = company
                    entries_data.append(e)
        if entries_data:
            save_journal_entries(project_id, entries_data, '单体调整')

    cons_entries = state.get('合并抵消分录', {})
    if isinstance(cons_entries, dict) and cons_entries.get('__journal_mgr__'):
        mgr_data = cons_entries.get('data', {})
        if isinstance(mgr_data, dict):
            entries = mgr_data.get('entries', [])
            if entries:
                save_journal_entries(project_id, entries, '合并抵消')
    elif isinstance(cons_entries, dict):
        entries_data = []
        for company, company_entries in cons_entries.items():
            if isinstance(company_entries, list):
                for e in company_entries:
                    e['company'] = company
                    entries_data.append(e)
        if entries_data:
            save_journal_entries(project_id, entries_data, '合并抵消')

    # 合并结果
    report_data = state.get('report_data')
    if report_data:
        if isinstance(report_data, dict):
            items = report_data.get('consolidated', [])
        elif isinstance(report_data, list):
            items = report_data
        else:
            items = []
        if items:
            save_consolidation_results(project_id, items)

    # Step 状态
    step = state.get('current_step', 1)
    step_status = state.get('step_status', {})
    conn = get_db()
    try:
        conn.execute(
            "UPDATE projects SET current_step=?, step_status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (step, json.dumps(step_status, ensure_ascii=False), project_id)
        )
        conn.commit()
    finally:
        conn.close()


def load_full_state(project_id: int) -> Dict:
    """加载完整项目状态"""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM projects WHERE id=?", (project_id,)
        ).fetchone()
    finally:
        conn.close()

    if not row:
        return {}

    proj = dict(row)
    conn = get_db()
    try:
        srow = conn.execute(
            "SELECT * FROM project_settings WHERE project_id=?", (project_id,)
        ).fetchone()
    finally:
        conn.close()
    settings = dict(srow) if srow else {}
    import_results = json.loads(settings.get('import_results', '[]')) if settings.get('import_results') else []
    # 解析辅助数据
    extra_data_raw = settings.get('extra_data', '{}') or '{}'
    extra_data = json.loads(extra_data_raw) if extra_data_raw != '{}' else {}

    records_data = load_imported_records(project_id)
    
    # 兼容已有数据：如果 import_results 为空但 records 有数据，自动重构
    if not import_results and records_data.get('data'):
        from collections import defaultdict
        companies_records = defaultdict(list)
        companies_checks = defaultdict(list)
        for r in records_data['data']:
            companies_records[r['company']].append(r)
        for c in records_data.get('checks', []):
            companies_checks[c['公司']].append(c)
        
        for company, recs in companies_records.items():
            check_list = companies_checks.get(company, [])
            passed = all(chk.get('是否一致', True) for chk in check_list)
            fail_count = sum(1 for chk in check_list if not chk.get('是否一致', True))
            import_results.append({
                'file': company,  # 无原始文件名，用公司名替代
                'company': company,
                'records': len(recs),
                'checks': len(check_list),
                'passed': len(check_list) - fail_count,
                'status': '✅' if passed else '⚠️',
                'reason': f'{fail_count} 条校验不一致' if fail_count > 0 else '',
                '检测方式': '历史数据恢复',
            })
    
    equity = load_equity(project_id)

    monotherapy_entries = load_journal_entries(project_id, '单体调整')
    cons_entries_list = load_journal_entries(project_id, '合并抵消')

    from core.journal_entry import JournalEntry, JournalManager
    mono_mgr = JournalManager(context_name='单体调整')
    for ed in monotherapy_entries:
        entry = JournalEntry.from_dict(ed)
        mono_mgr.add(entry)

    cons_mgr = JournalManager(context_name='合并抵消')
    for ed in cons_entries_list:
        entry = JournalEntry.from_dict(ed)
        cons_mgr.add(entry)

    consolidation = load_consolidation_results(project_id)
    report_data = {'consolidated': consolidation} if consolidation else None

    result = {
        'project_id': project_id,
        'project_name': proj.get('name', ''),
        'project_description': proj.get('description', ''),
        'current_step': proj.get('current_step', 1),
        'step_status': json.loads(proj.get('step_status', '{}')),
        'created_at': proj.get('created_at', ''),
        'updated_at': proj.get('updated_at', ''),

        'selected_standard': settings.get('selected_standard', 'cas'),
        'period_start': settings.get('period_start'),
        'period_end': settings.get('period_end'),
        'period_label': settings.get('period_label'),
        'report_currency': settings.get('report_currency', 'CNY'),

        'all_records': records_data.get('data', []),
        'all_checks': records_data.get('checks', []),
        'imported_files': records_data.get('files', []) or (
            [r.get('file', r.get('company', '')) for r in import_results] if import_results else []
        ),
        '_import_results': import_results,
        'equity_config': equity,
        'adjustments': [],
        '单体调整': mono_mgr,
        '合并抵消分录': cons_mgr,

        'consolidation_raw': None,
        'report_data': report_data,
        'consolidation_result': None,
        'export_path': '',
        'export_xlsx': '',
    }
    
    # 合并辅助数据（extra_data 覆盖默认值）
    for k, v in extra_data.items():
        result[k] = v
    return result


# ===================================================================
# 兼容旧 API
# ===================================================================

def save_records(project_id: int, records: List, checks: List, files: List):
    save_imported_records(project_id, records, checks)


def load_records(project_id: int) -> Dict:
    return load_imported_records(project_id)


def save_adjustments(project_id: int, data: Any):
    if isinstance(data, dict):
        merge_adjs = data.get('merge_adjustments', [])
        if merge_adjs:
            save_journal_entries(project_id, merge_adjs, '单体调整')
        monotherapy = data.get('monotherapy', {})
        if isinstance(monotherapy, dict) and not monotherapy.get('__journal_mgr__'):
            entries_data = []
            for company, company_entries in monotherapy.items():
                if isinstance(company_entries, list):
                    for e in company_entries:
                        e['company'] = company
                        entries_data.append(e)
            if entries_data:
                save_journal_entries(project_id, entries_data, '单体调整')
        cons_entries = data.get('合并抵消分录', {})
        if isinstance(cons_entries, dict) and not cons_entries.get('__journal_mgr__'):
            entries_data = []
            for company, company_entries in cons_entries.items():
                if isinstance(company_entries, list):
                    for e in company_entries:
                        e['company'] = company
                        entries_data.append(e)
            if entries_data:
                save_journal_entries(project_id, entries_data, '合并抵消')


def load_adjustments(project_id: int) -> List:
    return []


def save_consolidation(project_id: int, raw: Dict = None, report_data: Dict = None, **kwargs):
    if report_data:
        if isinstance(report_data, dict):
            items = report_data.get('consolidated', [])
        elif isinstance(report_data, list):
            items = report_data
        else:
            items = []
        if items:
            save_consolidation_results(project_id, items)


def load_consolidation(project_id: int) -> Dict:
    records = load_consolidation_results(project_id)
    return {
        'raw': None,
        'report_data': {'consolidated': records} if records else None,
        'consolidation_result': None,
    }


# ===================================================================
# 项目管理
# ===================================================================

def list_projects() -> List[Dict]:
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT id, name, description, current_step, step_status, created_at, updated_at "
            "FROM projects ORDER BY updated_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def create_project(name: str, description: str = "") -> int:
    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO projects (name, description) VALUES (?, ?)", (name, description)
        )
        pid = cur.lastrowid
        conn.execute("INSERT OR IGNORE INTO project_settings (project_id) VALUES (?)", (pid,))
        conn.commit()
        return pid
    finally:
        conn.close()


def delete_project(project_id: int):
    conn = get_db()
    try:
        # 先删子表（含外键引用的），再删主表
        conn.execute("DELETE FROM journal_entry_lines WHERE entry_fk IN "
                      "(SELECT id FROM journal_entries WHERE project_id=?)", (project_id,))
        conn.execute("DELETE FROM equity_structures WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM journal_entries WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM imported_records WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM import_checks WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM consolidation_results WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM validation_results WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM currency_data WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM internal_pairs WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM auto_adjustments WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM companies WHERE project_id=?", (project_id,))
        # 兼容旧表（v2/v3 迁移遗留，新库可能不存在）
        for table in ['project_settings', 'records', 'equity_config',
                       'adjustments', 'consolidation_data', 'translation_data', 'validation_data']:
            try:
                conn.execute(f"DELETE FROM {table} WHERE project_id=?", (project_id,))
            except sqlite3.OperationalError:
                pass  # 表不存在则跳过
        conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
        conn.commit()
    finally:
        conn.close()


def rename_project(project_id: int, new_name: str):
    conn = get_db()
    try:
        conn.execute(
            "UPDATE projects SET name=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (new_name, project_id)
        )
        conn.commit()
    finally:
        conn.close()


def update_project_step(project_id: int, step: int, step_status: Dict[str, str]):
    conn = get_db()
    try:
        conn.execute(
            "UPDATE projects SET current_step=?, step_status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (step, json.dumps(step_status, ensure_ascii=False), project_id)
        )
        conn.commit()
    finally:
        conn.close()


def save_settings(project_id: int, settings: Dict):
    conn = get_db()
    try:
        conn.execute("""
            INSERT INTO project_settings (project_id, selected_standard, period_start, period_end, period_label, report_currency)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(project_id) DO UPDATE SET
                selected_standard=excluded.selected_standard,
                period_start=excluded.period_start,
                period_end=excluded.period_end,
                period_label=excluded.period_label,
                report_currency=excluded.report_currency
        """, (
            project_id,
            settings.get('selected_standard', 'cas'),
            settings.get('period_start'),
            settings.get('period_end'),
            settings.get('period_label'),
            settings.get('report_currency', 'CNY'),
        ))
        conn.commit()
    finally:
        conn.close()


def load_settings(project_id: int) -> Dict:
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM project_settings WHERE project_id=?", (project_id,)
        ).fetchone()
        return dict(row) if row else {}
    finally:
        conn.close()


# 初始化
init_db()
