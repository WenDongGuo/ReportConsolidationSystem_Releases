"""
会计准则管理与科目匹配引擎

管理多套准则的科目表，实现原始科目名称 → 标准CAS科目的智能匹配

v2 改进：
  1. 科目名称归一化（去数字前缀、去括号注释、全半角统一）
  2. 关键词重叠评分（适合长科目名匹配）
  3. 常见财务缩写匹配
  4. 差分矩阵匹配（容错错别字/顺序颠倒）
"""
import os
import yaml
import re
from typing import Dict, List, Optional, Tuple
from difflib import SequenceMatcher


class StandardsManager:
    """会计准则管理器 — 加载和管理多套准则的科目表"""

    def __init__(self, standards_dir: str):
        self.standards_dir = standards_dir
        self._standards = {}  # standard_id → config
        self._load_all()

    def _load_all(self):
        """加载所有准则配置"""
        for f in os.listdir(self.standards_dir):
            if f.endswith(('.yaml', '.yml')):
                path = os.path.join(self.standards_dir, f)
                with open(path, encoding='utf-8') as fp:
                    config = yaml.safe_load(fp)
                    std_id = os.path.splitext(f)[0]
                    self._standards[std_id] = config

    def get_standard(self, std_id: str = "cas") -> Dict:
        return self._standards.get(std_id, {})

    def list_standards(self) -> List[str]:
        return list(self._standards.keys())

    def get_accounts_flat(self, std_id: str = "cas") -> List[Dict]:
        config = self.get_standard(std_id)
        accounts = []
        for category, items in config.get('科目表', {}).items():
            for item in items:
                item['category'] = category
                accounts.append(item)
        return accounts

    def build_alias_map(self, std_id: str = "cas") -> Dict[str, str]:
        config = self.get_standard(std_id)
        alias_map = {}

        for acct in self.get_accounts_flat(std_id):
            alias_map[acct['名称']] = acct['编码']

        for source, target in config.get('别名映射', {}).items():
            for acct in self.get_accounts_flat(std_id):
                if acct['名称'] == target:
                    alias_map[source] = acct['编码']
                    break

        return alias_map


class SubjectMatcher:
    """
    科目匹配器 — 将原始科目名称匹配到标准科目（v2 增强）

    匹配策略（逐级降级）:
      1. 精确匹配（含别名）
      2. 归一化匹配（去前缀/后缀/括号/全半角后匹配）
      3. 核心关键词覆盖匹配（适合长科目名）
      4. 差分模糊匹配（SequenceMatcher）
    """

    # 需要忽略的前缀（按长度降序，先匹配长的）
    IGNORE_PREFIXES = [
        '加：', '减：', '其中：', '加:', '减:', '其中:',
        '一、', '二、', '三、', '四、', '五、', '六、', '七、', '八、',
        '一:', '二:', '三:', '四:', '五:', '六:', '七:', '八:',
        '一.', '二.', '三.', '四.', '五.', '六.', '七.', '八.',
        '1、', '2、', '3、', '4、', '5、', '6、',
        '1.', '2.', '3.', '4.', '5.', '6.',
        '（', '(',
    ]

    # 括号模式
    BRACKET_PATTERN = re.compile(r'[（(][^）)]*[）)]')

    def __init__(self, standards_mgr: StandardsManager, std_id: str = "cas"):
        self.standards_mgr = standards_mgr
        self.std_id = std_id
        self.alias_map = standards_mgr.build_alias_map(std_id)
        self.accounts = standards_mgr.get_accounts_flat(std_id)

        # 加载 IFRS 英文科目别名（同一编码体系，英文名→CAS编码）
        self._load_english_aliases()

        # 预计算：归一化名称 → 标准科目的映射
        self._norm_map = {}  # normalized_name → account
        for acct in self.accounts:
            norm = self._normalize(acct['名称'])
            self._norm_map[norm] = acct

        # 预计算：每个标准科目的关键词集
        self._keyword_map = {}  # code → set of keywords
        for acct in self.accounts:
            code = acct['编码']
            kw = self._extract_keywords(acct['名称'])
            self._keyword_map[code] = kw

    # ──────────────────────────────────────────────
    # 名称归一化
    # ──────────────────────────────────────────────

    def _load_english_aliases(self):
        """加载 IFRS 英文科目别名作为补充映射

        利用 ifrs.yaml 中的英文字段（名称）→ CAS编码（编码）
        使英文科目名如 "Cash and cash equivalents" 可匹配到 "1001"
        """
        try:
            import os
            std_dir = self.standards_mgr.standards_dir
            ifrs_path = os.path.join(std_dir, 'ifrs.yaml')
            if os.path.exists(ifrs_path):
                import yaml
                with open(ifrs_path, encoding='utf-8') as f:
                    ifrs_data = yaml.safe_load(f) or {}
                for category, items in ifrs_data.get('科目表', {}).items():
                    for item in items:
                        en_name = item.get('名称', '')
                        code = item.get('编码', '')
                        if en_name and code:
                            self.alias_map[en_name] = code
                # 也加载 ifrs.yaml 中的别名映射
                for source, target in ifrs_data.get('别名映射', {}).items():
                    for category, items in ifrs_data.get('科目表', {}).items():
                        for item in items:
                            if item.get('名称') == target or item.get('名称_zh', '') == target:
                                self.alias_map[source] = item['编码']
                                break
        except Exception:
            pass  # IFRS不存在时静默跳过

    @staticmethod
    def _normalize(name: str) -> str:
        """归一化科目名称（去噪版）"""
        if not name:
            return ''

        n = str(name).strip()

        # 全角 → 半角
        n = n.replace('（', '(').replace('）', ')')
        n = n.replace('：', ':').replace('；', ';')
        n = n.replace('，', ',').replace('。', '.')

        # 去括号内容及括号本身
        n = SubjectMatcher.BRACKET_PATTERN.sub('', n).strip()

        # 去长度前缀
        for pfx in sorted(SubjectMatcher.IGNORE_PREFIXES, key=len, reverse=True):
            if n.startswith(pfx):
                n = n[len(pfx):].strip()
                break

        # 去常见后缀（如行末的点号、空格）
        n = n.rstrip('.。，,·')

        # 压缩空白
        n = re.sub(r'\s+', '', n)

        return n

    @staticmethod
    def _extract_keywords(name: str) -> set:
        """从科目名中提取核心关键词"""
        if not name:
            return set()

        n = SubjectMatcher._normalize(name)

        # 中文关键词：按2字以上分词
        tokens = set()
        # 提取所有长度≥2的中文连贯子串
        chinese_parts = re.findall(r'[\u4e00-\u9fff]{2,}', n)
        for part in chinese_parts:
            tokens.add(part)

        # 英文关键词（如果有）
        for eng in re.findall(r'[a-zA-Z]{2,}', n):
            tokens.add(eng.lower())

        return tokens

    # ──────────────────────────────────────────────
    # 核心匹配
    # ──────────────────────────────────────────────

    def match(self, raw_name: str) -> Optional[Dict]:
        """
        匹配原始科目名称到标准科目

        返回: {编码, 名称, 类别, 置信度} 或 None
        """
        if not raw_name or not raw_name.strip():
            return None

        name = raw_name.strip()

        # 1. 精确匹配（含别名映射）
        result = self._exact_match(name)
        if result:
            return result

        # 2. 归一化匹配
        norm_name = self._normalize(name)
        result = self._normalized_match(norm_name)
        if result:
            return result

        # 3. 关键词覆盖匹配（适合长科目名如现金流量表明细）
        result = self._keyword_match(norm_name)
        if result:
            return result

        # 4. 差分模糊匹配（含错别字容错）
        result = self._fuzzy_match(norm_name)
        if result:
            return result

        return None

    def suggest_matches(self, raw_name: str, top_n: int = 5) -> List[Dict]:
        """
        对未匹配的科目名，推荐最接近的标准科目
        
        返回: [{编码, 名称, 类别, 置信度}, ...]
        """
        if not raw_name or not raw_name.strip():
            return []

        norm_name = self._normalize(raw_name.strip())
        if not norm_name:
            return []

        suggestions = []

        # 用模糊匹配找 top N
        scored = []
        for acct in self.accounts:
            std_norm = self._normalize(acct['名称'])
            if not std_norm:
                continue
            ratio = SequenceMatcher(None, norm_name, std_norm).ratio()
            if ratio > 0.3:
                scored.append((ratio, acct))

        scored.sort(key=lambda x: x[0], reverse=True)
        for ratio, acct in scored[:top_n]:
            suggestions.append({**acct, 'confidence': round(ratio, 2)})

        return suggestions

    def _exact_match(self, name: str) -> Optional[Dict]:
        """精确匹配 + 别名映射"""
        if name in self.alias_map:
            code = self.alias_map[name]
            for acct in self.accounts:
                if acct['编码'] == code:
                    return {**acct, 'confidence': 1.0}

        # 再查一次别名（避免双循环漏了别名表）
        for alias, code in self.alias_map.items():
            if name == alias:
                for acct in self.accounts:
                    if acct['编码'] == code:
                        return {**acct, 'confidence': 0.95}

        return None

    def _normalized_match(self, norm_name: str) -> Optional[Dict]:
        """归一化名称匹配"""
        if not norm_name:
            return None

        # 直接匹配归一化后的名称
        if norm_name in self._norm_map:
            acct = self._norm_map[norm_name]
            return {**acct, 'confidence': 0.9}

        # 包含关系（归一化后的）
        for norm, acct in self._norm_map.items():
            if norm in norm_name or norm_name in norm:
                ratio = len(norm) / max(len(norm_name), 1)
                if ratio > 0.7:
                    return {**acct, 'confidence': round(ratio, 2)}

        return None

    def _keyword_match(self, norm_name: str) -> Optional[Dict]:
        """
        关键词匹配 — 计算原始名称的关键词与每个标准科目的关键词重叠率

        适合长科目名（如现金流量表明细项目）
        """
        if not norm_name or len(norm_name) < 3:
            return None

        name_keywords = self._extract_keywords(norm_name)
        if not name_keywords:
            return None

        best_match = None
        best_score = 0.0

        for acct in self.accounts:
            code = acct['编码']
            std_keywords = self._keyword_map.get(code, set())
            if not std_keywords:
                continue

            # Jaccard 相似度 = 交集 / 并集
            intersection = name_keywords & std_keywords
            if not intersection:
                continue

            # 加权：更关注词在标准科目名中的覆盖率
            covered = len(intersection) / max(len(std_keywords), 1)
            precision = len(intersection) / max(len(name_keywords), 1)

            # 综合评分（覆盖率和精确率的调和）
            score = (covered * 0.6 + precision * 0.4)

            if score > best_score and score > 0.3:
                best_score = score
                best_match = acct

        if best_match:
            return {**best_match, 'confidence': round(best_score, 2)}

        return None

    def _fuzzy_match(self, norm_name: str) -> Optional[Dict]:
        """差分模糊匹配 + 错别字容错"""
        if not norm_name:
            return None

        best_match = None
        best_ratio = 0.0

        for acct in self.accounts:
            std_norm = self._normalize(acct['名称'])
            if not std_norm:
                continue

            # 如果标准名称包含在输入中，降权但接受
            if std_norm in norm_name:
                ratio = len(std_norm) / max(len(norm_name), 1) * 0.85
            else:
                ratio = SequenceMatcher(None, norm_name, std_norm).ratio()

            if ratio > best_ratio:
                best_ratio = ratio
                best_match = acct

        if best_ratio > 0.65:
            return {**best_match, 'confidence': round(best_ratio, 2)}

        return None

    def batch_match(self, names: List[str]) -> List[Optional[Dict]]:
        return [self.match(n) for n in names]

    def identify_section(self, raw_name: str, section_markers: List[Dict]) -> Optional[str]:
        if not raw_name:
            return None
        for marker in section_markers:
            for kw in marker.get('keywords', []):
                if kw in raw_name:
                    return marker.get('name')
        return None
