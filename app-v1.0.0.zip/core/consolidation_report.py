"""
合并报表生成器 — 将合并数据输出为标准财务报表

功能:
- 生成合并资产负债表 (按CAS格式排列)
- 生成合并利润表
- 生成合并现金流量表
- 支持 Excel / JSON 导出
"""
from typing import Dict, List, Optional
from collections import defaultdict
import json
import os


class ConsolidatedReport:
    """一份完整的合并报表"""

    def __init__(self, parent: str, period: str = "期末余额"):
        self.parent = parent
        self.period = period
        self.balance_sheet = []      # 资产负债表行
        self.income_statement = []   # 利润表行
        self.cash_flow = []          # 现金流量表行
        self.notes = []              # 附注

    def to_dict(self) -> Dict:
        return {
            '母公司': self.parent,
            '期间': self.period,
            '资产负债表': self.balance_sheet,
            '利润表': self.income_statement,
            '现金流量表': self.cash_flow,
            '附注': self.notes,
        }

    def to_json(self, path: str):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)

    def summary(self) -> Dict:
        return {
            '母公司': self.parent,
            '资产负债表科目数': len(self.balance_sheet),
            '利润表科目数': len(self.income_statement),
            '现金流量表科目数': len(self.cash_flow),
            '资产总计': self._get_total('资产总计'),
            '负债合计': self._get_total('负债合计'),
            '所有者权益合计': self._get_total('所有者权益合计'),
            '营业收入': self._get_total('营业收入'),
            '净利润': self._get_total('净利润'),
        }

    def _get_total(self, name: str) -> float:
        for row in self.balance_sheet + self.income_statement + self.cash_flow:
            if row.get('项目') == name:
                return row.get('金额', 0)
        return 0


class ReportGenerator:
    """
    合并报表生成器

    根据合并引擎输出的科目列表，按会计格式组织成三张报表
    """

    # 资产负债表行顺序 (CAS 标准)
    BS_ITEMS = [
        # 资产
        ("流动资产：", None, "section"),
        ("货币资金", "1001", "detail"),
        ("交易性金融资产", "1101", "detail"),
        ("应收票据", "1121", "detail"),
        ("应收账款", "1122", "detail"),
        ("预付款项", "1123", "detail"),
        ("应收股利", "1131", "detail"),
        ("其他应收款", "1221", "detail"),
        ("存货", "1401", "detail"),
        ("其他流动资产", "1291", "detail"),
        ("流动资产合计", None, "total"),
        ("非流动资产：", None, "section"),
        ("长期股权投资", "1511", "detail"),
        ("投资性房地产", "1521", "detail"),
        ("固定资产", "1601", "detail"),
        ("在建工程", "1604", "detail"),
        ("无形资产", "1701", "detail"),
        ("商誉", "1711", "detail"),
        ("长期待摊费用", "1801", "detail"),
        ("递延所得税资产", "1811", "detail"),
        ("其他非流动资产", "1901", "detail"),
        ("非流动资产合计", None, "total"),
        ("资产总计", None, "grand_total"),

        # 负债
        ("流动负债：", None, "section"),
        ("短期借款", "2001", "detail"),
        ("应付票据", "2201", "detail"),
        ("应付账款", "2202", "detail"),
        ("预收款项", "2203", "detail"),
        ("应付职工薪酬", "2211", "detail"),
        ("应交税费", "2221", "detail"),
        ("应付股利", "2231", "detail"),
        ("其他应付款", "2241", "detail"),
        ("其他流动负债", "2801", "detail"),
        ("流动负债合计", None, "total"),
        ("非流动负债：", None, "section"),
        ("长期借款", "2501", "detail"),
        ("应付债券", "2502", "detail"),
        ("长期应付款", "2701", "detail"),
        ("递延所得税负债", "2901", "detail"),
        ("其他非流动负债", "2903", "detail"),
        ("非流动负债合计", None, "total"),
        ("负债合计", None, "grand_total"),

        # 所有者权益
        ("所有者权益：", None, "section"),
        ("实收资本", "4001", "detail"),
        ("资本公积", "4002", "detail"),
        ("盈余公积", "4101", "detail"),
        ("未分配利润", "4104", "detail"),
        ("少数股东权益", "4105", "detail"),
        ("所有者权益合计", None, "total"),
        ("负债和所有者权益合计", None, "grand_total"),
    ]

    # 利润表行顺序
    IS_ITEMS = [
        # ── Layer A: 营业利润 ──
        ("一、营业收入", ("6001", "6051"), "detail"),
        ("减：营业成本", ("6401", "6402"), "detail"),
        ("税金及附加", "6403", "detail"),
        ("销售费用", "6601", "detail"),
        ("管理费用", "6602", "detail"),
        ("研发费用", "5301", "detail"),
        ("财务费用", "6603", "detail"),
        ("其中：利息费用", None, "detail"),
        ("  利息收入", None, "detail"),
        ("加：其他收益", "6116", "detail"),
        ("  投资收益", "6111", "detail"),
        ("  公允价值变动收益", "6101", "detail"),
        ("  信用减值损失", "6702", "detail"),
        ("  资产减值损失", "6701", "detail"),
        ("  资产处置收益", "6115", "detail"),
        ("二、营业利润", None, "total"),

        # ── Layer B: 利润总额 ──
        ("加：营业外收入", "6301", "detail"),
        ("减：营业外支出", "6711", "detail"),
        ("三、利润总额", None, "total"),

        # ── Layer C: 净利润 ──
        ("减：所得税费用", "6801", "detail"),
        ("四、净利润", None, "grand_total"),
        ("（一）持续经营净利润", None, "detail"),
        ("（二）终止经营净利润", None, "detail"),

        # ── Layer D: 其他综合收益（独立 section，不混入净利润）──
        ("五、其他综合收益的税后净额", None, "section"),
        ("（一）不能重分类进损益的其他综合收益", None, "section"),
        ("  1.重新计量设定受益计划变动额", None, "detail"),
        ("  2.权益法下不能转损益的其他综合收益", None, "detail"),
        ("  3.其他权益工具投资公允价值变动", None, "detail"),
        ("  4.企业自身信用风险公允价值变动", None, "detail"),
        ("不能重分类进损益小计", None, "total"),
        ("（二）将重分类进损益的其他综合收益", None, "section"),
        ("  1.权益法下可转损益的其他综合收益", None, "detail"),
        ("  2.其他债权投资公允价值变动", None, "detail"),
        ("  3.金融资产重分类计入其他综合收益的金额", None, "detail"),
        ("  4.其他债权投资信用减值准备", None, "detail"),
        ("  5.现金流量套期储备", None, "detail"),
        ("  6.外币财务报表折算差额", "420101", "detail"),
        ("可重分类进损益小计", None, "total"),
        ("其他综合收益合计", None, "total"),

        # ── Layer E: 综合收益总额 ──
        ("六、综合收益总额", None, "grand_total"),

        # ── 合并层面特有（在单体或无需列示时归零）──
        ("减：少数股东损益", "6902", "detail"),
        ("七、归属于母公司所有者的净利润", None, "total"),
    ]

    # 现金流量表行顺序
    CF_ITEMS = [
        ("一、经营活动产生的现金流量：", None, "section"),
        ("  经营活动现金流入：", None, "section"),
        ("销售商品、提供劳务收到的现金", "C001", "detail"),
        ("收到的税费返还", "C002", "detail"),
        ("收到其他与经营活动有关的现金", "C003", "detail"),
        ("经营活动现金流入小计", None, "total"),
        ("  经营活动现金流出：", None, "section"),
        ("购买商品、接受劳务支付的现金", "C004", "detail"),
        ("支付给职工以及为职工支付的现金", "C005", "detail"),
        ("支付的各项税费", "C006", "detail"),
        ("支付其他与经营活动有关的现金", "C007", "detail"),
        ("经营活动现金流出小计", None, "total"),
        ("经营活动产生的现金流量净额", None, "grand_total"),
        ("二、投资活动产生的现金流量：", None, "section"),
        ("  投资活动现金流入：", None, "section"),
        ("收回投资收到的现金", "C008", "detail"),
        ("取得投资收益收到的现金", "C009", "detail"),
        ("投资活动现金流入小计", None, "total"),
        ("  投资活动现金流出：", None, "section"),
        ("购建固定资产、无形资产支付的现金", "C010", "detail"),
        ("投资支付的现金", "C011", "detail"),
        ("投资活动现金流出小计", None, "total"),
        ("投资活动产生的现金流量净额", None, "grand_total"),
        ("三、筹资活动产生的现金流量：", None, "section"),
        ("  筹资活动现金流入：", None, "section"),
        ("取得借款收到的现金", "C012", "detail"),
        ("筹资活动现金流入小计", None, "total"),
        ("  筹资活动现金流出：", None, "section"),
        ("偿还债务支付的现金", "C013", "detail"),
        ("分配股利、利润或偿付利息支付的现金", "C014", "detail"),
        ("筹资活动现金流出小计", None, "total"),
        ("筹资活动产生的现金流量净额", None, "grand_total"),
        ("四、汇率变动对现金的影响", None, "detail"),
        ("五、现金及现金等价物净增加额", None, "grand_total"),
    ]

    def generate(self, consolidated_data: List[Dict]) -> ConsolidatedReport:
        """
        生成合并报表

        Args:
            consolidated_data: 合并引擎输出的合并后科目列表

        Returns:
            ConsolidatedReport 对象
        """
        # 构建科目编码 → 金额的映射
        bs_map = defaultdict(float)
        is_map = defaultdict(float)
        cf_map = defaultdict(float)

        for r in consolidated_data:
            code = r.get('科目编码', '')
            amount = r.get('金额', 0)
            stmt = r.get('报表', '')
            period = r.get('期间类型', '')

            # 资产负债表是时点报表，只取期末余额
            # 利润表/现金流量表是期间报表，只取本年累计
            if stmt == '资产负债表' and period != '期末余额':
                continue
            if stmt in ('利润表', '现金流量表') and period not in ('本年累计', '期末余额'):
                continue

            if stmt == '资产负债表':
                bs_map[code] += amount
            elif stmt == '利润表':
                is_map[code] += amount
            elif stmt == '现金流量表':
                cf_map[code] += amount

        parent = consolidated_data[0].get('company', '集团合并') if consolidated_data else '集团合并'
        period = "期末余额"

        report = ConsolidatedReport(parent, period)

        # 生成资产负债表
        report.balance_sheet = self._build_statement(self.BS_ITEMS, bs_map)

        # 生成利润表
        report.income_statement = self._build_statement(self.IS_ITEMS, is_map)

        # 生成现金流量表
        report.cash_flow = self._build_statement(self.CF_ITEMS, cf_map)

        return report

    def _build_statement(self, template: List[tuple],
                         data_map: Dict[str, float]) -> List[Dict]:
        """按模板顺序构建一张报表"""
        rows = []
        subtotal_stack = []  # 用于分段合计计算

        for item in template:
            name = item[0]
            codes = item[1]
            row_type = item[2]

            if row_type == "section":
                rows.append({'项目': name, '金额': None, '类型': 'section'})
                subtotal_stack.append([])
                continue

            if row_type == "detail":
                amount = self._sum_codes(codes, data_map)
                rows.append({'项目': name, '金额': round(amount, 2), '类型': 'detail'})
                if subtotal_stack:
                    subtotal_stack[-1].append(amount)
                continue

            if row_type == "total":
                if subtotal_stack:
                    section_total = sum(subtotal_stack.pop())
                    rows.append({'项目': name, '金额': round(section_total, 2), '类型': 'total'})
                    if subtotal_stack:
                        subtotal_stack[-1].append(section_total)
                continue

            if row_type == "grand_total":
                # 找明细行总计
                total = self._compute_grand_total(name, rows, data_map)
                rows.append({'项目': name, '金额': round(total, 2), '类型': 'grand_total'})
                continue

        return rows

    def _sum_codes(self, codes, data_map: Dict[str, float]) -> float:
        """汇总一个或多个科目的金额"""
        if codes is None:
            return 0.0
        if isinstance(codes, str):
            return data_map.get(codes, 0.0)
        if isinstance(codes, tuple):
            return sum(data_map.get(c, 0.0) for c in codes)
        return 0.0

    def _compute_grand_total(self, name: str, rows: List[Dict],
                              data_map: Dict[str, float]) -> float:
        """计算总计项的金额"""
        if name == "资产总计":
            return sum(r['金额'] for r in rows if r['类型'] == 'total' and r['项目'] in ('流动资产合计', '非流动资产合计'))

        if name == "负债合计":
            return sum(r['金额'] for r in rows if r['类型'] in ('total',) and r['项目'] in ('流动负债合计', '非流动负债合计'))

        if name in ("所有者权益合计",):
            return sum(r['金额'] for r in rows if r['类型'] == 'detail' and r['项目'] in
                       ('实收资本', '资本公积', '盈余公积', '未分配利润', '少数股东权益'))

        if name == "负债和所有者权益合计":
            total_liability = sum(r['金额'] for r in rows if r['类型'] in ('total',) and r['项目'] in ('流动负债合计', '非流动负债合计'))
            total_equity = sum(r['金额'] for r in rows if r['类型'] == 'detail' and r['项目'] in
                               ('实收资本', '资本公积', '盈余公积', '未分配利润', '少数股东权益'))
            return total_liability + total_equity

        if name == "净利润":
            return sum(r['金额'] for r in rows if r['类型'] == 'total' and r['项目'] in ('三、利润总额',)) - data_map.get("6801", 0)

        if name == "归属于母公司所有者的净利润":
            net_profit = self._compute_grand_total("净利润", rows, data_map)
            minority = data_map.get("6902", 0)
            return net_profit - minority

        return 0.0
