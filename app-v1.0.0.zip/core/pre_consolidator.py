"""
预合并引擎 — 自动计算层（Step 5）

角色:
  单体原始数据 + Step 4 调整分录 → [自动计算] → 调整后单体数据（预合并）
  
设计原则:
  - 无状态: 每次调用从头计算，不缓存，不持久化
  - 响应式: 单体调整变动后，预合并数据自动反映
  - 无UI: 用户无需手动触发，不生成独立页面

数据流:
  pre_consolidate(records, monotherapy)
      ↓
  按公司分组，逐家调用 adjuster.apply_adjustments()
      ↓
  返回调整后科目记录列表
      ↓
  供 Step 6 合并引擎消费
"""
from typing import Dict, List, Optional
from collections import defaultdict


def pre_consolidate(
    all_records: List[Dict],
    monotherapy: Dict[str, List[Dict]],
    adjuster=None,
) -> List[Dict]:
    """
    执行预合并计算：将 Step 4 调整分录应用到各单体数据上。

    Args:
        all_records: 原始导入的科目记录列表
        monotherapy: 单体调整数据 {公司名: [分录列表]}
                    每个分录: {company:, description:, date:, lines: [{side, code, name, amount}]}
        adjuster: Adjuster 实例（从 core/adjuster 导入）

    Returns:
        调整后的科目记录列表 (预合并数据)
    """
    if not all_records:
        return []

    if not adjuster:
        # 懒加载
        from core.adjuster import Adjuster
        from core.standards import StandardsManager
        import os
        CONFIG_DIR = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'config'
        )
        STANDARDS_DIR = os.path.join(CONFIG_DIR, 'standards')
        mgr = StandardsManager(STANDARDS_DIR)
        adjuster = Adjuster(mgr)

    # 按公司分组原始数据
    companies_data = defaultdict(list)
    for r in all_records:
        companies_data[r.get('company', '')].append(r)

    # 收集所有公司（含仅有调整没有原始数据的公司）
    all_companies = set(companies_data.keys())
    if monotherapy:
        all_companies.update(monotherapy.keys())

    # 逐家应用调整
    adjusted_records = []
    adjustment_summary = {}  # 公司 → {原始金额, 调整金额, 调整后金额, 分录数}

    for company in sorted(all_companies):
        raw = companies_data.get(company, [])
        entries = (monotherapy or {}).get(company, [])
        
        if not entries:
            # 无调整的公司直接透传
            adjusted_records.extend(raw)
            adjustment_summary[company] = {
                '原始金额': _total_amount(raw),
                '调整金额': 0.0,
                '调整后金额': _total_amount(raw),
                '分录数': 0,
            }
            continue

        # 应用调整
        # adjuster.apply_adjustments 需要的 entries 是包含 'lines' 的列表
        adjusted = adjuster.apply_adjustments(raw, entries)
        adjusted_records.extend(adjusted)

        # 统计调整影响
        raw_total = _total_amount(raw)
        adj_total = _total_amount(adjusted)
        adjustment_summary[company] = {
            '原始金额': raw_total,
            '调整金额': adj_total - raw_total,
            '调整后金额': adj_total,
            '分录数': len(entries),
        }

    return adjusted_records


def get_adjustment_summary(
    all_records: List[Dict],
    monotherapy: Dict[str, List[Dict]],
) -> Dict:
    """
    获取预合并调整摘要（快速计算，不执行完整合并）。

    Returns:
        {公司: {原始金额, 调整金额, 调整后金额, 分录数}}
    """
    from core.adjuster import Adjuster
    from core.standards import StandardsManager
    import os
    CONFIG_DIR = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'config'
    )
    STANDARDS_DIR = os.path.join(CONFIG_DIR, 'standards')
    mgr = StandardsManager(STANDARDS_DIR)
    adjuster = Adjuster(mgr)

    companies_data = defaultdict(list)
    for r in all_records:
        companies_data[r.get('company', '')].append(r)

    all_companies = set(companies_data.keys())
    if monotherapy:
        all_companies.update(monotherapy.keys())

    summary = {}
    for company in sorted(all_companies):
        raw = companies_data.get(company, [])
        entries = (monotherapy or {}).get(company, [])
        
        if not entries:
            summary[company] = {
                '原始金额': _total_amount(raw),
                '调整金额': 0.0,
                '调整后金额': _total_amount(raw),
                '分录数': 0,
            }
        else:
            adjusted = adjuster.apply_adjustments(raw, entries)
            raw_total = _total_amount(raw)
            adj_total = _total_amount(adjusted)
            summary[company] = {
                '原始金额': raw_total,
                '调整金额': adj_total - raw_total,
                '调整后金额': adj_total,
                '分录数': len(entries),
            }

    return summary


def _total_amount(records: List[Dict]) -> float:
    """计算科目记录的总金额"""
    return sum(abs(r.get('金额', 0)) for r in records)


def auto_mark_step5(monotherapy: Dict) -> bool:
    """
    判断 Step 5 是否自动完成（只要有调整分录就认为可计算）。
    预合并总是可计算的——Step 4 有数据时计算有效结果，无数据时透传原始数据。
    """
    return True  # 预合并始终可自动执行
