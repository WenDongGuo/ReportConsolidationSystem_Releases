"""
单体调整引擎 — 调表不调账

复式记账分录 → 分析影响范围 → 自动联动调整

联动规则（复用 core.journal_entry）:
1. 涉及现金流科目(1001/1002) → 同步调整现金流量表 (用户指定类别)
2. 涉及损益类科目(6开头) → 同步调整未分配利润
"""
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

from core.journal_entry import (
    classify_account, is_bs_account, is_is_account,
    is_cf_account, is_cash_account,
    CF_CATEGORIES, DEFAULT_ACCOUNT_GROUPS as ACCOUNT_GROUPS,
)

from core.consolidation_config import ConsolidationConfig

# 从配置读取关键科目编码
_cfg = ConsolidationConfig()
_cfg.load()
RETAINED_EARNINGS_CODE = _cfg.get_code('retained_earnings') or '4104'


# 科目类别判定 — 复用 core.journal_entry
# classify_account, is_bs_account, is_is_account, is_cf_account, is_cash_account
# 已从 core.journal_entry 导入


class AdjustmentEntry:
    """一条调整分录"""

    def __init__(self, company: str, description: str, date: str = ""):
        self.company = company
        self.description = description
        self.date = date
        self.lines = []  # [{side, code, name, amount}]

    def add_line(self, side: str, account_code: str, account_name: str, amount: float):
        """添加一行借/贷"""
        self.lines.append({
            'side': side,
            'code': account_code,
            'name': account_name,
            'amount': amount,
        })

    def validate(self) -> Tuple[bool, str]:
        """校验: 借贷平衡"""
        if not self.lines:
            return False, "分录为空"
        debit = sum(l['amount'] for l in self.lines if l['side'] == 'debit')
        credit = sum(l['amount'] for l in self.lines if l['side'] == 'credit')
        if abs(debit - credit) > 0.01:
            return False, f"借贷不平: 借={debit:,.2f}, 贷={credit:,.2f}"
        return True, ""

    def analyze(self) -> Dict:
        """分析分录的影响范围"""
        result = {
            '影响报表': set(),
            '涉及科目类别': set(),
            '涉及现金流': False,
            '涉及损益': False,
            '损益净额': 0.0,
        }
        for l in self.lines:
            cat = classify_account(l['code'])
            result['涉及科目类别'].add(cat)

            if is_bs_account(l['code']):
                result['影响报表'].add('资产负债表')
            if is_is_account(l['code']):
                result['影响报表'].add('利润表')
                # 损益类: 借增费用/减收入, 贷增收入/减费用
                if cat == '损益':
                    # 收入类(6开头但6001-6999中有收入有费用)
                    # 简化: 借增=费用增加/利润减少
                    if l['side'] == 'debit':
                        result['损益净额'] -= l['amount']
                    else:
                        result['损益净额'] += l['amount']
                    result['涉及损益'] = True
            if is_cash_account(l['code']):
                result['涉及现金流'] = True
            if is_cf_account(l['code']):
                result['影响报表'].add('现金流量表')

        result['影响报表'] = list(result['影响报表'])
        result['涉及科目类别'] = list(result['涉及科目类别'])
        return result

    def generate_auto_adjustments(self, cf_category: str = "") -> List[Dict]:
        """
        生成自动联动调整分录

        Returns: [{'target': 'retained_earnings'|'cash_flow', 'entries': [...]}, ...]
        """
        result = []
        analysis = self.analyze()

        # 1. 未分配利润联动
        if analysis['涉及损益']:
            pnl_impact = analysis['损益净额']
            if abs(pnl_impact) > 0.01:
                # 净利润变动 → 未分配利润同向变动
                # 损益净额>0 → 利润增加 → 未分配利润增加(贷方)
                # 损益净额<0 → 利润减少 → 未分配利润减少(借方)
                result.append({
                    'reason': f"损益变动 {pnl_impact:+,.2f} → 同步调整未分配利润",
                    'target': 'retained_earnings',
                    'entries': [
                        {'company': self.company,
                         'code': RETAINED_EARNINGS_CODE,
                         'name': '未分配利润',
                         'amount': abs(pnl_impact),
                         'side': 'debit' if pnl_impact < 0 else 'credit'}
                    ]
                })

        # 2. 现金流联动 (需用户指定分类)
        if analysis['涉及现金流'] and cf_category:
            # 计算货币资金变动额
            cash_change = 0.0
            for l in self.lines:
                if is_cash_account(l['code']):
                    if l['side'] == 'debit':
                        cash_change += l['amount']  # 借方=现金增加
                    else:
                        cash_change -= l['amount']  # 贷方=现金减少

            if abs(cash_change) > 0.01 and cf_category in CF_CATEGORIES:
                # 找对应类别的第一个科目
                cf_code = CF_CATEGORIES[cf_category][0]
                cf_name = self._get_cf_name(cf_code)
                result.append({
                    'reason': f"货币资金变动 {cash_change:+,.2f} → 同步调整现金流量表({cf_category})",
                    'target': 'cash_flow',
                    'cf_category': cf_category,
                    'entries': [
                        {'company': self.company,
                         'code': cf_code,
                         'name': cf_name,
                         'amount': cash_change,
                         'side': 'debit'}  # 现金流增加
                    ]
                })

        return result

    def to_dict(self) -> Dict:
        return {
            'company': self.company,
            'description': self.description,
            'date': self.date,
            'lines': self.lines,
        }

    @staticmethod
    def _get_cf_name(code: str) -> str:
        names = {
            'C001': '销售商品、提供劳务收到的现金',
            'C002': '收到的税费返还',
            'C003': '收到其他与经营活动有关的现金',
            'C004': '购买商品、接受劳务支付的现金',
            'C005': '支付给职工以及为职工支付的现金',
            'C006': '支付的各项税费',
            'C007': '支付其他与经营活动有关的现金',
            'C008': '收回投资收到的现金',
            'C009': '取得投资收益收到的现金',
            'C010': '购建固定资产、无形资产支付的现金',
            'C011': '投资支付的现金',
            'C012': '取得借款收到的现金',
            'C013': '偿还债务支付的现金',
            'C014': '分配股利、利润或偿付利息支付的现金',
        }
        return names.get(code, code)


class Adjuster:
    """
    单体调整管理器

    管理某家单体公司的所有调整分录, 并计算调整后的数据
    """

    def __init__(self, standards_mgr=None):
        self.standards_mgr = standards_mgr

    def apply_adjustments(self, company_records: List[Dict],
                          entries: List[Dict]) -> List[Dict]:
        """
        将调整分录应用到单体数据上

        Args:
            company_records: 该公司的原始科目记录
            entries: 调整分录列表 (含自动联动分录)

        Returns:
            调整后的科目记录 (原始 + 调整影响)
        """
        # 构建调整影响图谱: (code, period, report) → 金额变动
        from collections import defaultdict
        impact = defaultdict(float)

        for entry in entries:
            adjust_type = entry.get('adjust_type', '期末')
            for line in entry.get('lines', []):
                code = line.get('code', '')
                amount = line.get('amount', 0)
                side = line.get('side', 'debit')

                # 确定期间类型和报表
                cat = classify_account(code)
                if cat == '现金流':
                    period = '本年累计'   # 不再使用"本期金额"
                    report = '现金流量表'
                elif cat == '损益':
                    period = '本年累计'
                    report = '利润表'
                else:
                    # 资产负债表: 期初→年初余额, 期末→期末余额
                    period = '年初余额' if adjust_type == '期初' else '期末余额'
                    report = '资产负债表'

                # 调整方向需考虑科目余额方向:
                # 借增贷减 (借方余额科目: 资产/费用)
                # 贷增借减 (贷方余额科目: 负债/权益/收入)
                from core.journal_entry import get_normal_balance
                normal = get_normal_balance(code)
                if normal == 'debit':
                    adj_amount = amount if side == 'debit' else -amount
                else:
                    adj_amount = amount if side == 'credit' else -amount
                impact_key = (code, period, report)
                impact[impact_key] += adj_amount

            # === 处理自动联动分录 (auto_adjustments) ===
            # generate_linking_adjustments 生成的联动，结构:
            # [{'reason': '...', 'target': 'retained_earnings', 'entries': [{code, amount, side, ...}]}]
            for aa_group in entry.get('auto_adjustments', []):
                for aa_line in aa_group.get('entries', []):
                    aa_code = aa_line.get('code', '')
                    aa_amount = aa_line.get('amount', 0)
                    aa_side = aa_line.get('side', 'debit')

                    aa_cat = classify_account(aa_code)
                    if aa_cat == '现金流':
                        aa_period = '本年累计'
                        aa_report = '现金流量表'
                    elif aa_cat == '损益':
                        aa_period = '本年累计'
                        aa_report = '利润表'
                    else:
                        aa_period = '年初余额' if adjust_type == '期初' else '期末余额'
                        aa_report = '资产负债表'

                    from core.journal_entry import get_normal_balance
                    aa_normal = get_normal_balance(aa_code)
                    if aa_normal == 'debit':
                        aa_adj = aa_amount if aa_side == 'debit' else -aa_amount
                    else:
                        aa_adj = aa_amount if aa_side == 'credit' else -aa_amount
                    impact[(aa_code, aa_period, aa_report)] += aa_adj

        # 应用到原始数据
        result = []
        applied_keys = set()

        for r in company_records:
            code = r.get('科目编码', '')
            period = r.get('期间类型', '')
            report = r.get('报表', '')
            key = (code, period, report)

            amount = r.get('金额', 0)
            if key in impact:
                amount += impact[key]
                applied_keys.add(key)

            result.append({**r, '金额': round(amount, 2)})

        # 添加调整引入的新科目
        for key, adj_amount in impact.items():
            if key not in applied_keys and abs(adj_amount) > 0.01:
                code, period, report = key
                # 找科目名称
                name = self._get_name(code)
                result.append({
                    'company': company_records[0].get('company', '') if company_records else '',
                    '科目编码': code,
                    '科目名称': name,
                    '金额': round(adj_amount, 2),
                    '期间类型': period,
                    '报表': report,
                })

        return result

    def _get_name(self, code: str) -> str:
        if not self.standards_mgr:
            return code
        accounts = self.standards_mgr.get_accounts_flat('cas')
        for a in accounts:
            if a['编码'] == code:
                return a['名称']
        return code


# 科目选择列表 (按类别分组) — 复用 core.journal_entry.DEFAULT_ACCOUNT_GROUPS
# 已通过 ACCOUNT_GROUPS 导入
