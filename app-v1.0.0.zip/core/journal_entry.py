"""
会计分录引擎 (Journal Entry Engine)

统一的复式记账数据模型，供 Step 4（单体调整）和 Step 6（合并抵消）共用。

核心概念:
  - JournalEntry: 一条会计分录 (包含多条借贷行, 借=贷)
  - JournalManager: 分录管理 (增删查改, 序列化)
  - 联动规则: 可配置的自动调整 (损益→未分配利润, 现金流→CF表等)

设计原则:
  - 纯数据层: 无 UI 依赖, 纯 Python 可测
  - 可配置: 联动规则通过策略模式注入, 不同场景不同配置
  - 无状态: JournalManager 仅操作内存数据, 持久化由调用方负责
"""
from typing import Dict, List, Optional, Tuple, Callable
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date
import json
import os
import yaml


# =============================================================================
# 费用科目编码加载（从会计准则标准配置读取）
# =============================================================================

def _load_expense_codes() -> set:
    """从 cas.yaml 标准科目表加载费用类科目编码（6开头借方余额科目）

    也兼容 ifrs.yaml 等其他标准。若配置不可用则回退到内置硬编码列表。
    """
    config_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'standards')
    candidates = ['cas.yaml', 'ifrs.yaml']
    for fname in candidates:
        path = os.path.join(config_dir, fname)
        if os.path.exists(path):
            try:
                with open(path, encoding='utf-8') as f:
                    data = yaml.safe_load(f) or {}
                # 遍历各科目类别（如 损益类）
                codes = set()
                for cat_key, accounts in data.items():
                    if '损益' in cat_key or cat_key == '损益类':
                        for acct in accounts:
                            code = acct.get('编码', '')
                            name = acct.get('名称', '')
                            # 损益类中费用科目通常不在常见的收入名称列表中
                            income_keywords = ('收入', '收益', '利得')
                            if code.startswith('6') and not any(kw in name for kw in income_keywords):
                                codes.add(code)
                if codes:
                    return codes
            except Exception:
                continue
    # 回退到内置硬编码列表
    return {
        '6401', '6402', '6403', '6404', '6405', '6406', '6407',
        '6411', '6421',
        '6501', '6502', '6511', '6521',
        '6531', '6541', '6551', '6561', '6571', '6581',
        '6601', '6602', '6603', '6604',
        '6701', '6702', '6711',
        '6801',
        '6901', '6902',
    }

# 全局加载一次 expense_codes
_EXPENSE_CODES = _load_expense_codes()


# 从配置读取关键科目编码（用于联动规则中替代硬编码 4104）
from core.consolidation_config import ConsolidationConfig
_JE_CFG = ConsolidationConfig()
_JE_CFG.load()
_JE_RETAINED_EARNINGS = _JE_CFG.get_code('retained_earnings') or '4104'


# =============================================================================
# 科目分类工具
# =============================================================================

def classify_account(code: str) -> str:
    """判定科目类别: 资产/负债/权益/损益/现金流/其他"""
    if not code:
        return '其他'
    if code.startswith('C'):
        return '现金流'
    if code.startswith('1'):
        return '资产'
    if code.startswith('2'):
        return '负债'
    if code.startswith('4'):
        return '权益'
    if code.startswith('5'):
        return '资产'
    if code.startswith('6'):
        return '损益'
    return '其他'


def get_normal_balance(code: str) -> str:
    """判断科目的正常余额方向（借方余额 or 贷方余额）

    企业会计准则:
      资产类(1xxx) → 借方余额（**备抵科目除外**）
      负债类(2xxx) → 贷方余额
      权益类(4xxx) → 贷方余额
      成本类(5xxx) → 借方余额
      损益类(6xxx) → 收入(6001-6111)贷方余额，费用(6401-6801)借方余额
      现金流(Cxxx) → 借方余额（调整时作增加处理）

    备抵科目（贷方余额，虽是 1xxx）:
      坏账准备(1231), 存货跌价准备(1471), 长期股权投资减值准备(1512),
      债权投资减值准备(1503), 累计折旧(1602), 固定资产减值准备(1603),
      累计摊销(1702), 无形资产减值准备(1703)

    Returns:
        'debit' 或 'credit'
    """
    prefix = code[0] if code else ''
    if prefix == '1':
        # 备抵科目: 1xxx 中的贷方余额科目
        contra_accounts = {
            '1231',  # 坏账准备
            '1471',  # 存货跌价准备
            '1503',  # 债权投资减值准备
            '1504',  # 其他债权投资减值准备
            '1512',  # 长期股权投资减值准备
            '1525',  # 投资性房地产减值准备
            '1531',  # 长期应收款坏账准备
            '1602',  # 累计折旧
            '1603',  # 固定资产减值准备
            '1605',  # 工程物资减值准备
            '1702',  # 累计摊销
            '1703',  # 无形资产减值准备
        }
        return 'credit' if code in contra_accounts else 'debit'
    if prefix in ('2', '4'):  # 负债类, 权益类
        return 'credit'
    if prefix == '5':  # 成本类
        return 'debit'
    if prefix == '6':  # 损益类: 收入贷方余额, 费用借方余额
        return 'debit' if code in _EXPENSE_CODES else 'credit'
    # 现金流及其他默认借方余额
    return 'debit'


def is_bs_account(code: str) -> bool:
    return classify_account(code) in ('资产', '负债', '权益')


def is_is_account(code: str) -> bool:
    return classify_account(code) == '损益'


def is_cash_account(code: str) -> bool:
    return code in ('1001', '1002')


def is_cf_account(code: str) -> bool:
    return classify_account(code) == '现金流'


# 现金流量表科目选项 (供联动使用)
CF_CATEGORIES = {
    '经营流入': ['C001', 'C002', 'C003'],
    '经营流出': ['C004', 'C005', 'C006', 'C007'],
    '投资流入': ['C008', 'C009'],
    '投资流出': ['C010', 'C011'],
    '筹资流入': ['C012'],
    '筹资流出': ['C013', 'C014'],
}

CF_CATEGORY_NAMES = {
    'C001': '销售商品、提供劳务收到的现金',
    'C002': '收到的税费返还',
    'C003': '收到其他与经营活动有关的现金',
    'C004': '购买商品、接受劳务支付的现金',
    'C005': '支付给职工以及为职工支付的现金',
    'C006': '支付的各项税费',
    'C007': '支付其他与经营活动有关的现金',
    'C008': '收回投资收到的现金',
    'C009': '取得投资收益收到的现金',
    'C010': '购建固定资产、无形资产支付的现金',
    'C011': '投资支付的现金',
    'C012': '取得借款收到的现金',
    'C013': '偿还债务支付的现金',
    'C014': '分配股利、利润或偿付利息支付的现金',
}


# 科目选择列表 (按类别分组)
DEFAULT_ACCOUNT_GROUPS = {
    '资产类': [
        '1001', '1101', '1121', '1122', '1123', '1131', '1132', '1221', '1231',
        '1401', '1403', '1406', '1471', '1501', '1503',
        '1511', '1512', '1521', '1601', '1602', '1603', '1604',
        '1701', '1702', '1703', '1711', '1801', '1811', '1901',
    ],
    '负债类': [
        '2001', '2201', '2202', '2203', '2211', '2221', '2231', '2232', '2241',
        '2401', '2501', '2502', '2701', '2901', '2902',
    ],
    '权益类': [
        '4001', '4002', '4101', '4103', '4104', '4201',
        '4105',  # 少数股东权益
        '4401',  # 其他权益工具
    ],
    '损益类': [
        '6001', '6051', '6061', '6101', '6111', '6301',
        '6401', '6402', '6403', '6601', '6602', '6603',
        '6701', '6702', '6711', '6801',
        '6902',  # 少数股东损益
    ],
}


# =============================================================================
# 数据模型
# =============================================================================

class JournalLine:
    """分录的一行 (借或贷)"""

    def __init__(self, side: str, account_code: str, account_name: str, amount: float,
                 cf_category: str = "", aux1: str = "", aux2: str = "", aux3: str = ""):
        """
        Args:
            side: 'debit' 或 'credit'
            account_code: 科目编码
            account_name: 科目名称
            amount: 金额（正数=增加，负数=红冲）
            cf_category: 涉现对应现金流类别 (非涉现科目为空)
            aux1-3: 辅助段
        """
        self.side = side
        self.code = account_code
        self.name = account_name
        self.amount = amount  # 允许红冲（负数金额），不再强制转正
        self.cf_category = cf_category
        self.aux1 = aux1
        self.aux2 = aux2
        self.aux3 = aux3

    def to_dict(self) -> Dict:
        return {
            'side': self.side,
            'code': self.code,
            'name': self.name,
            'amount': round(self.amount, 2),
            'cf_category': self.cf_category,
            'aux1': self.aux1,
            'aux2': self.aux2,
            'aux3': self.aux3,
        }

    @staticmethod
    def from_dict(d: Dict) -> 'JournalLine':
        return JournalLine(
            side=d.get('side', 'debit'),
            account_code=d.get('code', ''),
            account_name=d.get('name', ''),
            amount=float(d.get('amount', 0)),
            cf_category=d.get('cf_category', ''),
            aux1=d.get('aux1', ''),
            aux2=d.get('aux2', ''),
            aux3=d.get('aux3', ''),
        )

    def __repr__(self):
        side_cn = "借" if self.side == 'debit' else "贷"
        cf = f" [{self.cf_category}]" if self.cf_category else ""
        aux_parts = [a for a in [self.aux1, self.aux2, self.aux3] if a]
        aux_str = f" {'/'.join(aux_parts)}" if aux_parts else ""
        return f"{side_cn} {self.code} {self.name} ¥{self.amount:,.2f}{cf}{aux_str}"


class JournalEntry:
    """
    一条会计分录 (复式记账)
    
    结构:
      - 描述、日期、公司(可选)
      - 多行: [{side, code, name, amount}]
      - 借 = 贷 (有校验)
      - 自动联动分录 (引擎生成)
    """

    def __init__(self, description: str = "", date_str: str = "",
                 company: str = "", entry_id: int = 0,
                 context: str = "", adjust_type: str = "期末"):  # context: '单体调整' | '合并抵消' | 任意
        self.id = entry_id
        self.description = description
        self.date = date_str or str(date.today())
        self.company = company
        self.context = context
        self.adjust_type = adjust_type  # '期初' | '期末'
        self.lines: List[JournalLine] = []
        self.auto_adjustments: List[Dict] = []  # 引擎生成的自动联动
        # 审计 & 版本控制字段
        self.version: int = 1
        self.created_at: str = str(date.today())
        self.modified_at: str = str(date.today())
        self.modified_by: str = ""
        self.is_deleted: bool = False
        self.deleted_at: str = ""
        self.is_readonly: bool = False  # 导入的原始数据保护

    def add_line(self, side: str, account_code: str, account_name: str, amount: float,
                 cf_category: str = "", aux1: str = "", aux2: str = "", aux3: str = ""):
        """添加一行借/贷"""
        self.lines.append(JournalLine(side, account_code, account_name, amount,
                                      cf_category=cf_category, aux1=aux1, aux2=aux2, aux3=aux3))

    def remove_line(self, index: int):
        """移除指定行"""
        if 0 <= index < len(self.lines):
            del self.lines[index]

    @property
    def debit_total(self) -> float:
        return sum(l.amount for l in self.lines if l.side == 'debit')

    @property
    def credit_total(self) -> float:
        return sum(l.amount for l in self.lines if l.side == 'credit')

    def validate(self) -> Tuple[bool, str]:
        """校验: 借贷平衡 + 非空"""
        if not self.lines:
            return False, "分录为空"
        diff = abs(self.debit_total - self.credit_total)
        if diff > 0.01:
            return False, f"借贷不平: 借={self.debit_total:,.2f}, 贷={self.credit_total:,.2f} (差额{diff:,.2f})"
        return True, ""

    def analyze(self) -> Dict:
        """分析分录的影响范围"""
        result = {
            '影响报表': set(),
            '涉及科目类别': set(),
            '涉及现金流': False,
            '涉及损益': False,
            '损益净额': 0.0,
            '涉及少数股东': False,
        }
        for l in self.lines:
            cat = classify_account(l.code)
            result['涉及科目类别'].add(cat)

            if is_bs_account(l.code):
                result['影响报表'].add('资产负债表')
            if is_is_account(l.code):
                result['影响报表'].add('利润表')
                if l.side == 'debit':
                    result['损益净额'] -= l.amount
                else:
                    result['损益净额'] += l.amount
                result['涉及损益'] = True
            if is_cash_account(l.code):
                result['涉及现金流'] = True
            if is_cf_account(l.code):
                result['影响报表'].add('现金流量表')
            if l.code in ('4105', '6902'):
                result['涉及少数股东'] = True

        result['影响报表'] = list(result['影响报表'])
        result['涉及科目类别'] = list(result['涉及科目类别'])
        return result

    def generate_linking_adjustments(self,
                                     linking_rules: List[str] = None) -> List[Dict]:
        """
        根据配置的联动规则，生成自动调整分录

        Args:
            linking_rules: 启用的联动规则列表
                ['retained_earnings', 'cash_flow', 'minority']
                None = 启用全部可用规则

        Returns:
            [{'reason': ..., 'target': ..., 'entries': [...]}, ...]
        """
        if linking_rules is None:
            linking_rules = ['retained_earnings', 'cash_flow']

        result = []
        analysis = self.analyze()
        linking_rules = set(linking_rules)

        # 规则 1: 损益 → 未分配利润联动
        if 'retained_earnings' in linking_rules and analysis['涉及损益']:
            pnl = analysis['损益净额']
            if abs(pnl) > 0.01:
                # 4104(未分配利润)是贷方余额科目，fix后的apply_adjustments:
                # 贷方=增, 借方=减
                # pnl>0 = 利润增加 → 未分配利润增加 → 贷方
                # pnl<0 = 利润减少 → 未分配利润减少 → 借方
                side = 'credit' if pnl > 0 else 'debit'
                result.append({
                    'reason': f"损益变动 {pnl:+,.2f} → 同步调整未分配利润",
                    'target': 'retained_earnings',
                    'entries': [{
                        'company': self.company,
                        'code': _JE_RETAINED_EARNINGS,
                        'name': '未分配利润',
                        'amount': abs(pnl),
                        'side': side,
                    }]
                })

        # 规则 2: 货币资金 → 现金流量表联动（从每行 cf_category 读取）
        if 'cash_flow' in linking_rules and analysis['涉及现金流']:
            cash_change = 0.0
            for l in self.lines:
                if is_cash_account(l.code):
                    cash_change += l.amount if l.side == 'debit' else -l.amount

            if abs(cash_change) > 0.01:
                # 从涉及现金的行提取 cf_category
                cf_cats = set()
                for l in self.lines:
                    if is_cash_account(l.code) and l.cf_category:
                        cf_cats.add(l.cf_category)
                # 如果能确定唯一类别，使用它
                cf_category = next(iter(cf_cats)) if len(cf_cats) == 1 else (list(cf_cats)[0] if cf_cats else "")

                # 如果未指定 cf_category，根据现金变动方向推断
                if not cf_category:
                    cf_category = '经营流出' if cash_change < 0 else '经营流入'

                # 查找匹配的 CF 类别名
                matched_cat = None
                matched_code = None
                for cat_name, codes in CF_CATEGORIES.items():
                    for code in codes:
                        if CF_CATEGORY_NAMES.get(code, '') == cf_category:
                            matched_cat = cat_name
                            matched_code = code
                            break
                    if matched_code:
                        break

                if not matched_code and cf_category:
                    # 如果 cf_category 本身就是类别名（如"经营流入"）
                    if cf_category in CF_CATEGORIES:
                        matched_cat = cf_category
                        matched_code = CF_CATEGORIES[cf_category][0]

                if matched_code:
                    # 现金流流出科目取反：Cr 1001(付钱)=流出增加
                    _outflow_codes = set()
                    for cat_name, codes_list in CF_CATEGORIES.items():
                        if '流出' in cat_name:
                            _outflow_codes.update(codes_list)
                    cf_side = 'debit' if cash_change > 0 else 'credit'
                    if matched_code in _outflow_codes:
                        cf_side = 'credit' if cash_change > 0 else 'debit'
                    result.append({
                        'reason': f"货币资金变动 {cash_change:+,.2f} → 同步现金流量表 ({cf_category})",
                        'target': 'cash_flow',
                        'entries': [{
                            'company': self.company,
                            'code': matched_code,
                            'name': CF_CATEGORY_NAMES.get(matched_code, matched_code),
                            'amount': abs(cash_change),
                            'side': cf_side,
                        }]
                    })

        return result

    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'description': self.description,
            'date': self.date,
            'company': self.company,
            'context': self.context,
            'adjust_type': self.adjust_type,
            'lines': [l.to_dict() for l in self.lines],
            'auto_adjustments': self.auto_adjustments,
            'version': self.version,
            'created_at': self.created_at,
            'modified_at': self.modified_at,
            'modified_by': self.modified_by,
            'is_deleted': self.is_deleted,
            'deleted_at': self.deleted_at,
            'is_readonly': self.is_readonly,
        }

    @staticmethod
    def from_dict(d: Dict) -> 'JournalEntry':
        entry = JournalEntry(
            description=d.get('description', ''),
            date_str=d.get('date', ''),
            company=d.get('company', ''),
            entry_id=int(d.get('id', 0)),
            context=d.get('context', ''),
        )
        for ld in d.get('lines', []):
            entry.lines.append(JournalLine.from_dict(ld))
        entry.auto_adjustments = d.get('auto_adjustments', [])
        entry.adjust_type = d.get('adjust_type', '期末')
        entry.version = int(d.get('version', 1))
        entry.created_at = d.get('created_at', str(date.today()))
        entry.modified_at = d.get('modified_at', str(date.today()))
        entry.modified_by = d.get('modified_by', '')
        entry.is_deleted = bool(d.get('is_deleted', False))
        entry.deleted_at = d.get('deleted_at', '')
        entry.is_readonly = bool(d.get('is_readonly', False))
        return entry

    def display_lines_html(self) -> str:
        """生成分录的HTML展示"""
        html = "<table style='width:100%; border-collapse:collapse; font-size:0.9em;'>"
        html += "<tr style='border-bottom:1px solid #ddd;'><th>方向</th><th>科目</th><th>涉现</th><th>金额</th><th>辅助段</th></tr>"
        for l in self.lines:
            side_cn = "借" if l.side == 'debit' else "贷"
            cf = l.cf_category if l.cf_category else "—"
            aux_parts = [a for a in [l.aux1, l.aux2, l.aux3] if a]
            aux_str = " / ".join(aux_parts) if aux_parts else "—"
            html += f"<tr style='border-bottom:1px solid #eee;'>"
            html += f"<td style='padding:2px 8px;'>{side_cn}</td>"
            html += f"<td style='padding:2px 8px;'>{l.code} {l.name}</td>"
            html += f"<td style='padding:2px 8px;'>{cf}</td>"
            html += f"<td style='padding:2px 8px; text-align:right;'><strong>{l.amount:,.2f}</strong></td>"
            html += f"<td style='padding:2px 8px;'>{aux_str}</td>"
            html += "</tr>"
        html += "</table>"
        for aa in self.auto_adjustments:
            html += f"<small>🔄 {aa.get('reason', '')}</small><br>"
        return html

    def __repr__(self):
        return f"#{self.id} {self.description} ({self.company}) 借={self.debit_total:,.2f} 贷={self.credit_total:,.2f}"


# =============================================================================
# 分录管理器 (Journal Manager)
# =============================================================================

class JournalManager:
    """
    分录管理器 — 增删查改 + 序列化

    用法:
      mgr = JournalManager(context_name='单体调整')
      mgr.add(entry)
      mgr.delete(entry_id)
      entries = mgr.list()
      data = mgr.to_dict()  # 用于持久化
      mgr.load_from(data)   # 从持久化恢复
    """

    def __init__(self, context_name: str = ""):
        self.context = context_name
        self._entries: List[JournalEntry] = []
        self._next_id = 1
        self._deleted_log: List[Dict] = []  # 修改/删除审计日志

    @property
    def entries(self) -> List[JournalEntry]:
        """返回未删除的分录"""
        return [e for e in self._entries if not e.is_deleted]

    @property
    def count(self) -> int:
        return len(self.entries)

    def add(self, entry: JournalEntry) -> int:
        """添加一条分录，返回 id"""
        entry.id = self._next_id
        entry.context = self.context or entry.context
        entry.created_at = str(date.today())
        entry.modified_at = str(date.today())
        entry.version = 1
        self._next_id += 1
        self._entries.append(entry)
        return entry.id

    def get(self, entry_id: int) -> Optional[JournalEntry]:
        """按 id 获取分录（含已删除）"""
        for e in self._entries:
            if e.id == entry_id:
                return e
        return None

    def delete(self, entry_id: int, deleted_by: str = "") -> bool:
        """软删除指定分录，保留记录"""
        for e in self._entries:
            if e.id == entry_id:
                e.is_deleted = True
                e.deleted_at = str(date.today())
                e.modified_by = deleted_by
                # 记录审计日志
                self._deleted_log.append({
                    'id': entry_id,
                    'description': e.description,
                    'deleted_at': e.deleted_at,
                    'deleted_by': deleted_by,
                    'snapshot': e.to_dict(),
                })
                return True
        return False

    def update(self, entry_id: int, new_entry: JournalEntry, modified_by: str = "") -> bool:
        """更新分录，记录修改日志"""
        for i, e in enumerate(self._entries):
            if e.id == entry_id:
                if e.is_readonly:
                    return False  # 只读数据禁止修改
                # 记录修改前快照
                old_snapshot = e.to_dict()
                new_entry.id = entry_id
                new_entry.context = self.context
                new_entry.version = e.version + 1
                new_entry.created_at = e.created_at
                new_entry.modified_at = str(date.today())
                new_entry.modified_by = modified_by
                new_entry.is_readonly = e.is_readonly
                new_entry.is_deleted = e.is_deleted
                new_entry.deleted_at = e.deleted_at
                self._entries[i] = new_entry
                # 记录审计日志
                self._deleted_log.append({
                    'id': entry_id,
                    'description': e.description,
                    'action': 'update',
                    'modified_at': new_entry.modified_at,
                    'modified_by': modified_by,
                    'before': old_snapshot,
                    'after': new_entry.to_dict(),
                })
                return True
        return False

    def clear(self):
        """清空所有分录"""
        self._entries.clear()

    def filter(self, company: str = None) -> List[JournalEntry]:
        """按条件过滤（只返回未删除分录）"""
        result = [e for e in self._entries if not e.is_deleted]
        if company:
            result = [e for e in result if e.company == company]
        return list(result)

    def get_audit_log(self) -> List[Dict]:
        """获取审计日志"""
        return list(self._deleted_log)

    def to_dict(self) -> Dict:
        """序列化为可持久化的 dict"""
        return {
            'context': self.context,
            'next_id': self._next_id,
            'entries': [e.to_dict() for e in self._entries],
            'deleted_log': self._deleted_log,
        }

    def load_from(self, data: Dict):
        """从 dict 恢复状态"""
        if not data:
            return
        self.context = data.get('context', self.context)
        self._next_id = int(data.get('next_id', 1))
        self._entries = []
        for ed in data.get('entries', []):
            self._entries.append(JournalEntry.from_dict(ed))
        self._deleted_log = data.get('deleted_log', [])

    @staticmethod
    def from_dict(data: Dict) -> 'JournalManager':
        """从 dict 构造"""
        mgr = JournalManager(data.get('context', ''))
        mgr.load_from(data)
        return mgr

    def get_impact_summary(self) -> Dict[str, Dict]:
        """
        获取所有分录的科目影响汇总
        
        Returns:
            {科目编码: {name, debit_total, credit_total, net, count}}
        """
        impact = defaultdict(lambda: {'name': '', 'debit': 0, 'credit': 0, 'count': 0})
        for entry in self._entries:
            for line in entry.lines:
                info = impact[line.code]
                info['name'] = line.name
                if line.side == 'debit':
                    info['debit'] += line.amount
                else:
                    info['credit'] += line.amount
                info['count'] += 1
            for aa in entry.auto_adjustments:
                for al in aa.get('entries', []):
                    code = al['code']
                    info = impact[code]
                    info['name'] = al['name']
                    if al['side'] == 'debit':
                        info['debit'] += al['amount']
                    else:
                        info['credit'] += al['amount']
                    info['count'] += 1
        result = {}
        for code, info in impact.items():
            result[code] = {
                'name': info['name'],
                'debit_total': round(info['debit'], 2),
                'credit_total': round(info['credit'], 2),
                'net': round(info['debit'] - info['credit'], 2),
                'count': info['count'],
            }
        return result


# =============================================================================
# 适配器: 将 JournalManager 桥接到 Step 4/6 的存储格式
# =============================================================================

def adapt_step4_storage(session_data: Dict) -> Dict[str, JournalManager]:
    """
    将 Step 4 的旧存储格式 (单体调整: {公司: [分录dict列表]})
    转换为 {公司: JournalManager}
    """
    result = {}
    for company, entries_list in (session_data or {}).items():
        mgr = JournalManager(context_name='单体调整')
        for ed in entries_list:
            entry = JournalEntry.from_dict(ed)
            if entry.id:
                mgr._next_id = max(mgr._next_id, entry.id + 1)
            mgr.add(entry)
        result[company] = mgr
    return result


def adapt_step4_back(mgrs: Dict[str, JournalManager]) -> Dict:
    """
    将 {公司: JournalManager} 转回 Step 4 存储格式
    """
    return {
        company: [e.to_dict() for e in mgr.entries]
        for company, mgr in mgrs.items()
    }
