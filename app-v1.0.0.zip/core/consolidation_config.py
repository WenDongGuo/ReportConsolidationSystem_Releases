"""
合并配置加载器 — 从 config/consolidation/ YAML 读取合并规则

解耦：合并引擎不再硬编码科目编码，全部从配置读取
"""
import os
import yaml
from typing import Dict, List, Any, Optional

CONSOLIDATION_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'consolidation')


class ConsolidationConfig:
    """合并配置 — 读取 YAML 并暴露属性"""

    def __init__(self, config_dir: str = None):
        self.config_dir = config_dir or CONSOLIDATION_DIR
        self._subjects = {}    # key → {name, code, ifrs_code}
        self._pairs = []       # [{pair_name, dr, cr, description}]
        self._equity_accounts = []  # [code, ...]
        self._specific = {}    # {key: code}
        self._loaded = False

    def load(self):
        """加载所有合并配置"""
        subjects_path = os.path.join(self.config_dir, 'subjects.yaml')
        rules_path = os.path.join(self.config_dir, 'offset_rules.yaml')

        # 读取科目定义
        if os.path.exists(subjects_path):
            with open(subjects_path, encoding='utf-8') as f:
                data = yaml.safe_load(f) or {}
            self._subjects = data.get('consolidation_subjects', {})

        # 读取抵消规则
        if os.path.exists(rules_path):
            with open(rules_path, encoding='utf-8') as f:
                data = yaml.safe_load(f) or {}
            self._pairs = data.get('internal_pairs', [])
            self._equity_accounts = data.get('equity_offset_accounts', [])
            self._specific = data.get('consolidation_specific', {})

        self._loaded = True

    def get_code(self, key: str) -> str:
        """按 key 获取科目编码"""
        if not self._loaded:
            self.load()
        subj = self._subjects.get(key, {})
        return str(subj.get('code', ''))

    def get_name(self, key: str) -> str:
        """按 key 获取科目名称"""
        if not self._loaded:
            self.load()
        return self._subjects.get(key, {}).get('name', key)

    def get_subject(self, key: str) -> Dict:
        """获取完整科目定义"""
        if not self._loaded:
            self.load()
        return self._subjects.get(key, {})

    @property
    def internal_pairs(self) -> List[Dict]:
        if not self._loaded:
            self.load()
        return self._pairs

    @property
    def equity_accounts(self) -> List[str]:
        if not self._loaded:
            self.load()
        return self._equity_accounts

    @property
    def minority_equity(self) -> str:
        return self._specific.get('minority_equity_code', '')

    @property
    def minority_pnl(self) -> str:
        return self._specific.get('minority_pnl_code', '')

    @property
    def goodwill(self) -> str:
        return self._specific.get('goodwill_code', '')

    @property
    def long_equity(self) -> str:
        return self._specific.get('long_equity_code', '')

    # ── 便捷命名属性（兼容旧代码） ──
    @property
    def SUBJECT_LONG_EQUITY(self) -> str: return self.get_code('long_equity')
    @property
    def SUBJECT_LONG_EQUITY_IMP(self) -> str: return self.get_code('long_equity_impairment')
    @property
    def SUBJECT_INVENTORY(self) -> str: return self.get_code('inventory')
    @property
    def SUBJECT_REVENUE(self) -> str: return self.get_code('revenue')
    @property
    def SUBJECT_COST(self) -> str: return self.get_code('cost_of_sales')
    @property
    def SUBJECT_INVEST_INCOME(self) -> str: return self.get_code('invest_income')
    @property
    def SUBJECT_CAPITAL_RESERVE(self) -> str: return self.get_code('capital_reserve')
    @property
    def SUBJECT_SURPLUS_RESERVE(self) -> str: return self.get_code('surplus_reserve')
    @property
    def SUBJECT_RETAINED_EARN(self) -> str: return self.get_code('retained_earnings')
    @property
    def SUBJECT_PAID_CAPITAL(self) -> str: return self.get_code('paid_capital')
    @property
    def SUBJECT_CURRENT_PROFIT(self) -> str: return self.get_code('current_profit')
    @property
    def SUBJECT_GOODWILL(self) -> str: return self.get_code('goodwill')
    @property
    def SUBJECT_ACCT_RECV(self) -> str: return self.get_code('acct_recv') or '1122'
    @property
    def SUBJECT_ACCT_PAY(self) -> str: return self.get_code('acct_pay') or '2202'
    @property
    def SUBJECT_OTHER_RECV(self) -> str: return self.get_code('other_recv') or '1221'
    @property
    def SUBJECT_OTHER_PAY(self) -> str: return self.get_code('other_pay') or '2241'
    @property
    def SUBJECT_NOTE_RECV(self) -> str: return self.get_code('note_recv') or '1121'
    @property
    def SUBJECT_NOTE_PAY(self) -> str: return self.get_code('note_pay') or '2201'
    @property
    def SUBJECT_DIVIDEND_RECV(self) -> str: return self.get_code('dividend_recv') or '1131'
    @property
    def SUBJECT_DIVIDEND_PAY(self) -> str: return self.get_code('dividend_pay') or '2231'

    # 合并特有科目
    @property
    def SUBJECT_MINORITY_EQ(self) -> str: return self.minority_equity or '4105'
    @property
    def SUBJECT_MINORITY_PNL(self) -> str: return self.minority_pnl or '6902'

    # ── 构建内部往来映射字典（兼容旧代码） ──
    def build_internal_pairs(self) -> Dict[str, str]:
        pairs = {}
        for p in self.internal_pairs:
            dr = p.get('dr', '')
            cr = p.get('cr', '')
            if dr and cr:
                pairs[dr] = cr
        return pairs

    def build_equity_accounts(self) -> List[str]:
        return list(self.equity_accounts)

    def validate(self) -> List[str]:
        """校验配置完整性，返回缺失清单"""
        missing = []
        required = ['long_equity', 'paid_capital', 'capital_reserve',
                    'surplus_reserve', 'retained_earnings', 'current_profit',
                    'goodwill', 'revenue', 'cost_of_sales', 'invest_income']
        for key in required:
            if not self.get_code(key):
                missing.append(key)
        return missing
