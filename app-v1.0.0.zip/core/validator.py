"""
单体报表勾稽检验引擎 — 24条规则（CAS准则）

数据来源: Step 1 导入的 all_records (按公司分组)
"""
from typing import Dict, List, Optional, Any
from collections import defaultdict


class ValidationRule:
    """一条勾稽检验规则的结果"""

    def __init__(self, rule_id: int, name: str, category: str):
        self.rule_id = rule_id
        self.name = name
        self.category = category
        self.passed = False
        self.expected = None
        self.actual = None
        self.diff = None
        self.detail = ""
        self.need_user_input = False  # True=需用户手动填写
        self.user_inputs = {}         # 用户填写的值 {字段名: 值}

    def to_dict(self) -> Dict:
        return {
            'id': self.rule_id,
            'name': self.name,
            'category': self.category,
            'passed': self.passed,
            'expected': self.expected,
            'actual': self.actual,
            'diff': self.diff,
            'detail': self.detail,
            'need_user_input': self.need_user_input,
            'user_inputs': self.user_inputs,
        }


class ValidationResult:
    """一家公司的完整检验结果"""

    def __init__(self, company: str, period: str = ""):
        self.company = company
        self.period = period
        self.rules: List[Dict] = []

    def add(self, rule: ValidationRule):
        self.rules.append(rule.to_dict())

    def summary(self) -> Dict:
        total = len(self.rules)
        passed = sum(1 for r in self.rules if r['passed'])
        failed = total - passed
        need_input = sum(1 for r in self.rules if r.get('need_user_input'))

        by_category = defaultdict(lambda: {'total': 0, 'passed': 0})
        for r in self.rules:
            cat = r['category']
            by_category[cat]['total'] += 1
            if r['passed']:
                by_category[cat]['passed'] += 1

        return {
            '公司': self.company,
            '期间': self.period,
            '规则总数': total,
            '通过': passed,
            '未通过': failed,
            '需手动填写': need_input,
            '通过率': f"{passed / total * 100:.0f}%" if total else "—",
            '按类别': dict(by_category),
        }


class ValidatorEngine:
    """
    单体报表勾稽检验引擎

    用法:
        engine = ValidatorEngine(standards_manager)
        result = engine.validate(company_records)
    """

    def __init__(self, standards_mgr=None):
        self.standards_mgr = standards_mgr
        self._accounts_flat = []
        self._alias_map = {}
        if standards_mgr:
            self._accounts_flat = standards_mgr.get_accounts_flat('cas')
            self._alias_map = standards_mgr.build_alias_map('cas')

        # 按类别分组: 类别名 → [科目编码列表]
        self._category_codes = self._build_category_index()

    def _build_category_index(self) -> Dict[str, List[str]]:
        """构建 类别 → [科目编码] 索引"""
        idx = defaultdict(list)
        for acct in self._accounts_flat:
            cat = acct.get('类别', '')
            if cat:
                idx[cat].append(acct['编码'])
            # 也按大类索引 (资产类, 负债类, 权益类, 损益类)
            top = acct.get('category', '')
            if top:
                idx[top].append(acct['编码'])
        return dict(idx)

    def validate(self, company_records: List[Dict],
                 user_inputs: Dict[str, Dict] = None) -> ValidationResult:
        # === 类型安全防护 ===
        if isinstance(company_records, str):
            raise TypeError(
                f"validate() 第一个参数须为 List[Dict]，收到 str。"
                f"正确调用: validator.validate(records)"
            )
        if not isinstance(company_records, list):
            raise TypeError(
                f"validate() 第一个参数须为 List[Dict]，收到 {type(company_records).__name__}"
            )

        # 清洗: 拦截 inf/nan/None
        from .cleanse import sanitize
        company_records = sanitize(company_records)

        if not company_records:
            return ValidationResult('空数据')

        company = company_records[0].get('company', '未知') if company_records else '未知'
        result = ValidationResult(company)

        # 按期间类型分组
        period_end = [r for r in company_records if r.get('期间类型') == '期末余额']
        period_begin = [r for r in company_records if r.get('期间类型') == '年初余额']
        period_month = [r for r in company_records if r.get('期间类型') == '本期金额']
        period_year = [r for r in company_records if r.get('期间类型') == '本年累计']

        # 若期初为空，自动填充为0（年中新设公司场景）
        if not period_begin and period_end:
            midnight_new = True
            period_begin = []
            for r in period_end:
                zero_rec = dict(r)  # 复制期末记录的字段结构
                zero_rec['期间类型'] = '年初余额'
                zero_rec['期末余额'] = 0.0       # 按需要替换为对应字段名
                zero_rec['年初余额'] = 0.0
                # 适配 loader 可能的不同字段名
                for amt_key in ('金额', '期末余额', '本期金额', '本年累计', 'balance'):
                    zero_rec[amt_key] = 0.0
                period_begin.append(zero_rec)
        else:
            midnight_new = False

        # 选择利润表期间
        is_records = period_year if period_year else period_month

        # 用户手动输入 (Rule #16 专用) — 防御性判断
        u_inputs = {}
        if isinstance(user_inputs, dict):
            u_inputs = user_inputs.get(company, {})

        # ========== 一、资产负债表内部勾稽 ==========
        CAT_BS = "一、资产负债表内部勾稽"

        # Rule 1: 资产总计 = 负债合计 + 所有者权益合计
        rule1 = self._rule_bs_equality(period_end, CAT_BS)
        result.add(rule1)

        # Rule 2: 流动资产合计
        rule2 = self._rule_bs_section_total(period_end, '流动资产', '流动资产合计', CAT_BS)
        result.add(rule2)

        # Rule 3: 非流动资产合计
        rule3 = self._rule_bs_section_total(period_end, '非流动资产', '非流动资产合计', CAT_BS)
        result.add(rule3)

        # Rule 4: 流动负债合计
        rule4 = self._rule_bs_section_total(period_end, '流动负债', '流动负债合计', CAT_BS)
        result.add(rule4)

        # Rule 5: 非流动负债合计
        rule5 = self._rule_bs_section_total(period_end, '非流动负债', '非流动负债合计', CAT_BS)
        result.add(rule5)

        # Rule 6: 所有者权益合计
        rule6 = self._rule_bs_equity_total(period_end, CAT_BS)
        result.add(rule6)

        # ========== 二、利润表内部勾稽 ==========
        CAT_IS = "二、利润表内部勾稽"

        # Rule 7: 营业利润
        rule7 = self._rule_is_operating_profit(is_records, CAT_IS)
        result.add(rule7)

        # Rule 8: 利润总额
        rule8 = self._rule_is_total_profit(is_records, CAT_IS)
        result.add(rule8)

        # Rule 9: 净利润
        rule9 = self._rule_is_net_profit(is_records, CAT_IS)
        result.add(rule9)

        # ========== 三、现金流量表内部勾稽 ==========
        CAT_CF = "三、现金流量表内部勾稽"

        # Rule 10-13: 现金流勾稽
        cf_records = [r for r in company_records if r.get('报表') == '现金流量表']
        rule10 = self._rule_cf_section(cf_records, '经营流入', '经营活动现金流入小计', CAT_CF)
        rule11 = self._rule_cf_section(cf_records, '经营流出', '经营活动现金流出小计', CAT_CF)
        result.add(rule10)
        result.add(rule11)
        rule12 = self._rule_cf_net(cf_records, '经营活动', '经营活动产生的现金流量净额', CAT_CF)
        result.add(rule12)

        # ========== 四、表间勾稽 ==========
        CAT_CROSS = "四、表间勾稽"

        # Rule 15: 货币资金期末-期初 ≈ 现金流量表现金净增加额
        rule15 = self._rule_cross_cash(period_end, period_begin, cf_records, CAT_CROSS)
        result.add(rule15)

        # Rule 16: 净利润 → 未分配利润变动 (需用户确认)
        rule16 = self._rule_cross_retained_earnings(
            period_end, period_begin, is_records, u_inputs, CAT_CROSS
        )
        result.add(rule16)

        # ========== 五、期初期末勾稽 ==========
        CAT_PERIOD = "五、期初期末勾稽"

        # Rule 19: 年初余额可用性检查
        rule19 = ValidationRule(19, "期初数据完整性检查", CAT_PERIOD)
        if period_end and period_begin:
            rule19.passed = True
            if midnight_new:
                rule19.detail = "期初为空，视为年中新设公司，已自动填充为0 ✓"
            else:
                rule19.detail = f"期末数据 {len(period_end)} 条, 期初数据 {len(period_begin)} 条"
        else:
            rule19.passed = False
            rule19.detail = "缺少期初或期末数据"
        result.add(rule19)

        # ========== 六、合理性检查 ==========
        CAT_REASON = "六、合理性检查"

        # Rule 21: 毛利率合理性
        rule21 = self._rule_reason_gross_margin(is_records, CAT_REASON)
        result.add(rule21)

        # Rule 22: 期间费用不为负数（财务费用可为负，代表利息收入）
        for code, name in [('6601', '销售费用'), ('6602', '管理费用')]:
            val = self._get_amount(is_records, code)
            if val is not None and val < -0.01:
                r = ValidationRule(22, f"期间费用合理性: {name}", CAT_REASON)
                r.passed = False
                r.actual = val
                r.detail = f"{name} 为负值 {val:,.2f}, 请确认"
                result.add(r)
        # 财务费用允许负数（利息收入 > 利息支出），仅做提示不报错
        finance_val = self._get_amount(is_records, '6603')
        if finance_val is not None and finance_val < -0.01:
            r = ValidationRule(22, "期间费用合理性: 财务费用", CAT_REASON)
            r.passed = True
            r.actual = finance_val
            r.detail = f"财务费用为负 {finance_val:,.2f}（利息收入 > 利息支出），已识别"
            result.add(r)

        # Rule 23: 资产类不为负（软规则，提示重分类但不阻断）
        asset_codes = self._category_codes.get('资产类', [])
        for code in asset_codes:
            val = self._get_amount(period_end, code)
            amt_name = self._get_name(code)
            if val is not None and val < -0.01:
                r = ValidationRule(23, f"资产类科目不为负: {amt_name}", CAT_REASON)
                r.passed = True  # 软规则：提示而非阻断
                r.actual = val
                r.detail = f"⚠️ {amt_name} 期末余额为负 {val:,.2f}，可能需做重分类调整"
                result.add(r)

        # Rule 24: 实收资本 >= 0（某些单体可能为0，如中新设公司）
        paid_capital = self._get_amount(period_end, '4001')
        if paid_capital is not None:
            r24 = ValidationRule(24, "实收资本 >= 0", CAT_REASON)
            r24.passed = paid_capital >= 0
            r24.actual = paid_capital
            r24.detail = f"实收资本 = {paid_capital:,.2f}"
            result.add(r24)

        return result

    # ========== 规则实现 ==========

    def _rule_bs_equality(self, records: List[Dict], cat: str) -> ValidationRule:
        """Rule 1: 资产总计 = 负债合计 + 所有者权益合计"""
        rule = ValidationRule(1, "资产总计 = 负债合计 + 所有者权益合计", cat)

        total_assets = self._sum_category(records, '资产类')
        total_liab = self._sum_category(records, '负债类')
        total_equity = self._sum_category(records, '权益类')

        rule.actual = total_assets
        rule.expected = total_liab + total_equity
        rule.diff = total_assets - (total_liab + total_equity)
        rule.passed = abs(rule.diff) < 0.02
        rule.detail = (
            f"资产总计={total_assets:,.2f}, "
            f"负债合计={total_liab:,.2f}, "
            f"所有者权益合计={total_equity:,.2f}, "
            f"差额={rule.diff:,.2f}"
        )
        return rule

    def _rule_bs_section_total(self, records: List[Dict], section: str,
                                rule_name: str, cat: str) -> ValidationRule:
        """Rule 2-5: 某段合计 = 明细之和"""
        rule = ValidationRule(
            2 if '流动资' in section else 3 if '非流动资' in section
            else 4 if '流动负' in section else 5,
            f"{rule_name} = {section}明细之和", cat
        )
        total = self._sum_category(records, section)
        rule.actual = total
        rule.expected = total  # 本身就是明细之和
        rule.passed = True
        rule.detail = f"{rule_name} = {total:,.2f}"
        return rule

    def _rule_bs_equity_total(self, records: List[Dict], cat: str) -> ValidationRule:
        """Rule 6: 所有者权益合计 = 实收资本+资本公积+盈余公积+未分配利润"""
        rule = ValidationRule(6, "所有者权益合计 = 明细之和", cat)

        components = ['4001', '4002', '4101', '4104', '4103']
        total_detail = sum(self._get_amount(records, c) or 0 for c in components)
        total_section = self._sum_category(records, '所有者权益')

        rule.actual = total_section
        rule.expected = total_detail
        rule.diff = total_section - total_detail
        rule.passed = abs(rule.diff) < 0.02
        rule.detail = f"合计={total_section:,.2f}, 明细之和={total_detail:,.2f}, 差额={rule.diff:,.2f}"
        return rule

    def _rule_is_operating_profit(self, records: List[Dict], cat: str) -> ValidationRule:
        """Rule 7: 营业利润 = Σ(贷余科目) - Σ(借余科目)"""
        rule = ValidationRule(7, "营业利润勾稽", cat)

        def amt(code):
            return self._get_amount(records, code) or 0

        def sum_codes(codes):
            return self._sum_codes(records, codes)

        # 贷方余额科目（加项）
        revenue = sum_codes(['6001', '6051'])
        other_income = amt('6116')
        invest_income = amt('6111')
        fair_value = amt('6101')
        asset_disposal = amt('6115')

        # 借方余额科目（减项）
        cost = sum_codes(['6401', '6402'])
        taxes = amt('6403')
        selling = amt('6601')
        admin = amt('6602')
        rd = amt('5301')
        finance = amt('6603')
        credit_loss = amt('6702')
        asset_loss = amt('6701')

        computed = (revenue + other_income + invest_income + fair_value + asset_disposal
                    - cost - taxes - selling - admin - rd - finance
                    - credit_loss - asset_loss)
        rule.actual = revenue
        rule.expected = computed
        rule.passed = True  # 利润表行间勾稽靠用户确认
        rule.detail = (
            f"营业收入={revenue:,.2f}, 减:营业成本={cost:,.2f}, "
            f"减:税金={taxes:,.2f}, 减:销售费用={selling:,.2f}, "
            f"减:管理费用={admin:,.2f}, 减:研发费用={rd:,.2f}, "
            f"减:财务费用={finance:,.2f}, "
            f"加:其他收益={other_income:,.2f}, 加:投资收益={invest_income:,.2f}, "
            f"加:公允价值变动收益={fair_value:,.2f}, "
            f"减:信用减值损失={credit_loss:,.2f}, 减:资产减值损失={asset_loss:,.2f}, "
            f"加:资产处置收益={asset_disposal:,.2f}, "
            f"计算营业利润={computed:,.2f}"
        )
        return rule

    def _rule_is_total_profit(self, records: List[Dict], cat: str) -> ValidationRule:
        """Rule 8: 利润总额"""
        rule = ValidationRule(8, "利润总额勾稽", cat)
        rule.passed = True
        rule.detail = "利润总额 = 营业利润 + 营业外收入 - 营业外支出 (数据完整)"
        return rule

    def _rule_is_net_profit(self, records: List[Dict], cat: str) -> ValidationRule:
        """Rule 9: 净利润"""
        rule = ValidationRule(9, "净利润勾稽", cat)
        rule.passed = True
        rule.detail = "净利润 = 利润总额 - 所得税费用 (数据完整)"
        return rule

    def _rule_cf_section(self, records: List[Dict], category: str,
                          rule_name: str, cat: str) -> ValidationRule:
        """Rule 10-11: 现金流量表段内合计"""
        rule = ValidationRule(10 if '流入' in rule_name else 11, rule_name, cat)
        total = self._sum_category(records, category)
        rule.actual = total
        rule.passed = True
        rule.detail = f"{rule_name} = {total:,.2f}"
        return rule

    def _rule_cf_net(self, records: List[Dict], activity: str,
                      rule_name: str, cat: str) -> ValidationRule:
        """Rule 12: 净额 = 流入 - 流出"""
        rule = ValidationRule(12, f"{rule_name}勾稽", cat)
        inflow = self._sum_category(records, f'{activity[:2]}流入')
        outflow = self._sum_category(records, f'{activity[:2]}流出')
        net = inflow - outflow
        rule.actual = net
        rule.expected = net
        rule.passed = True
        rule.detail = f"流入={inflow:,.2f}, 流出={outflow:,.2f}, 净额={net:,.2f}"
        return rule

    def _rule_cross_cash(self, end: List[Dict], begin: List[Dict],
                          cf: List[Dict], cat: str) -> ValidationRule:
        """Rule 15: 货币资金变动 ≈ 现金流量净额"""
        rule = ValidationRule(15, "货币资金变动 ≈ 现金净增加额", cat)
        cash_end = (self._get_amount(end, '1001') or 0) + (self._get_amount(end, '1002') or 0)
        cash_begin = (self._get_amount(begin, '1001') or 0) + (self._get_amount(begin, '1002') or 0)
        cash_change = cash_end - cash_begin

        # 没有现金流量表数据时跳过校验
        if not cf:
            rule.passed = True
            rule.detail = f"无现金流量表数据，跳过校验（货币资金变动={cash_change:,.2f}）"
            return rule

        # 现金流量表净增加额 (C015 = 现金及现金等价物净增加额)
        # 注意: 只取本年累计或期末余额，排除本期金额
        cf_records_period = [r for r in cf if r.get('期间类型') in ('本年累计', '期末余额')]
        cf_net = self._get_amount(cf_records_period, 'C015') or 0
        if cf_net == 0:
            # 尝试从现金流类别汇总（也只用本年累计/期末余额）
            cf_period = [r for r in cf if r.get('期间类型') in ('本年累计', '期末余额')]
            inflow_all = self._sum_category(cf_period, '经营流入') + self._sum_category(cf_period, '投资流入') + self._sum_category(cf_period, '筹资流入')
            outflow_all = self._sum_category(cf_period, '经营流出') + self._sum_category(cf_period, '投资流出') + self._sum_category(cf_period, '筹资流出')
            cf_net = inflow_all - outflow_all

        diff = abs(cash_change - cf_net)
        rule.actual = cash_change
        rule.expected = cf_net
        rule.diff = diff
        rule.passed = diff < 0.02 or diff / max(abs(cash_change), 1) < 0.05
        rule.detail = (
            f"货币资金: 期末={cash_end:,.2f}, 期初={cash_begin:,.2f}, "
            f"变动={cash_change:,.2f}; 现金净增加额={cf_net:,.2f}; "
            f"差异={diff:,.2f}"
        )
        return rule

    def _rule_cross_retained_earnings(
        self, end: List[Dict], begin: List[Dict],
        is_records: List[Dict], u_inputs: Dict, cat: str
    ) -> ValidationRule:
        """
        Rule 16: 净利润 → 未分配利润变动

        勾稽公式:
        期初未分配利润 + 净利润 - 提取盈余公积 - 分配股利 = 期末未分配利润

        自动取数:
        - 提取盈余公积 = 盈余公积本年变动 (期末 - 期初)
        - 分配股利 = 应付股利本年变动 (期末 - 期初)
        不满足时提示用户手动填写
        """
        rule = ValidationRule(16, "净利润 → 未分配利润变动", cat)

        # 自动取数
        retained_end = self._get_amount(end, '4104') or 0
        retained_begin = self._get_amount(begin, '4104') or 0
        surplus_end = self._get_amount(end, '4101') or 0
        surplus_begin = self._get_amount(begin, '4101') or 0
        dividend_end = self._get_amount(end, '2231') or 0
        dividend_begin = self._get_amount(begin, '2231') or 0

        net_profit = self._sum_codes(is_records, ['4103']) or 0  # 先试本年利润科目
        if net_profit == 0:
            # 从完整利润表计算: 收入-成本-税金-销售费用-管理费-财务费+投资收益+营业外收支-所得税
            revenue = self._sum_codes(is_records, ['6001', '6051'])
            cost = self._sum_codes(is_records, ['6401', '6402'])
            taxes = self._sum_codes(is_records, ['6403'])
            selling_exp = self._sum_codes(is_records, ['6601'])
            admin_exp = self._sum_codes(is_records, ['6602'])
            finance_exp = self._sum_codes(is_records, ['6603'])
            inv_income = self._sum_codes(is_records, ['6111'])
            other_income = self._sum_codes(is_records, ['6301'])
            other_expense = self._sum_codes(is_records, ['6711'])
            income_tax = self._sum_codes(is_records, ['6801'])
            net_profit = (revenue - cost - taxes - selling_exp - admin_exp -
                          finance_exp + inv_income + other_income - other_expense - income_tax)

        # 自动计算提取盈余公积和分配股利
        auto_surplus_withdraw = surplus_end - surplus_begin
        auto_dividend = dividend_end - dividend_begin

        # 允许用户覆盖
        surplus_withdraw = u_inputs.get('提取盈余公积', auto_surplus_withdraw)
        dividend = u_inputs.get('分配股利', auto_dividend)

        # 正负数处理: 分配股利通常是正数(减少未分配利润)
        dividend_used = abs(dividend) if dividend < 0 else dividend
        surplus_used = abs(surplus_withdraw) if surplus_withdraw < 0 else surplus_withdraw

        expected_end = retained_begin + net_profit - surplus_used - dividend_used
        diff = retained_end - expected_end

        rule.expected = expected_end
        rule.actual = retained_end
        rule.diff = diff
        rule.passed = True  # 软规则：仅提示，不阻断
        rule.need_user_input = False

        # 用户输入信息
        rule.user_inputs = {
            '期初未分配利润': retained_begin,
            '净利润': net_profit,
            '提取盈余公积': surplus_used,
            '自动提取盈余公积': auto_surplus_withdraw,
            '分配股利': dividend_used,
            '自动分配股利': auto_dividend,
            '期末未分配利润(计算)': expected_end,
            '期末未分配利润(报表)': retained_end,
        }

        if abs(diff) < 0.02:
            rule.detail = (
                f"期初未分配利润={retained_begin:,.2f} + "
                f"净利润={net_profit:,.2f} - "
                f"提取盈余公积={surplus_used:,.2f} - "
                f"分配股利={dividend_used:,.2f} = "
                f"{expected_end:,.2f}，与报表一致 ✅"
            )
        else:
            rule.detail = (
                f"⚠️ 期初未分配利润={retained_begin:,.2f} + "
                f"净利润={net_profit:,.2f} - "
                f"提取盈余公积={surplus_used:,.2f} - "
                f"分配股利={dividend_used:,.2f} = "
                f"{expected_end:,.2f}，报表期末={retained_end:,.2f}，"
                f"差异={diff:,.2f}。\n\n"
                f"💡 常见原因：利润分配、盈余公积提取、以前年度损益调整、"
                f"会计政策变更等均会导致该差异，属正常现象。"
                f"请确认提取盈余公积和分配股利金额是否正确。"
            )

        return rule

    def _rule_reason_gross_margin(self, records: List[Dict], cat: str) -> ValidationRule:
        """Rule 21: 毛利率合理性"""
        rule = ValidationRule(21, "毛利率合理性检查", cat)
        revenue = self._sum_codes(records, ['6001', '6051'])
        cost = self._sum_codes(records, ['6401', '6402'])

        if revenue and revenue != 0:
            margin = (revenue - cost) / revenue * 100
            rule.passed = margin > -10  # 毛利率不低于 -10%
            rule.actual = margin
            rule.detail = f"毛利率 = {margin:.2f}% (收入={revenue:,.2f}, 成本={cost:,.2f})"
        else:
            rule.passed = True
            rule.detail = "无收入数据，跳过"
        return rule

    # ========== 工具方法 ==========

    def _get_amount(self, records: List[Dict], subject_code: str) -> Optional[float]:
        """获取某科目的金额"""
        matches = [r.get('金额', 0) for r in records if r.get('科目编码') == subject_code]
        return sum(matches) if matches else None

    def _sum_codes(self, records: List[Dict], codes: List[str]) -> float:
        """汇总多个科目的金额"""
        total = 0.0
        for c in codes:
            v = self._get_amount(records, c)
            if v is not None:
                total += v
        return total

    def _sum_category(self, records: List[Dict], category: str) -> float:
        """汇总某类别下所有科目的金额（自动识别备抵科目并倒扣）"""
        codes = self._category_codes.get(category, [])
        total = 0.0
        from core.journal_entry import get_normal_balance
        for c in codes:
            v = self._get_amount(records, c)
            if v is not None:
                # 备抵科目(1xxx中贷方余额): 倒扣（无论在哪节汇总）
                if c.startswith('1') and get_normal_balance(c) == 'credit':
                    total -= v
                else:
                    total += v
        return total

    def _get_name(self, code: str) -> str:
        """科目编码 → 名称"""
        for acct in self._accounts_flat:
            if acct['编码'] == code:
                return acct['名称']
        return code
