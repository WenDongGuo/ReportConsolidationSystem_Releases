"""
外币折算引擎 — CAS 19 / IAS 21 财务报表外币折算

功能:
  1. 识别外币公司 (功能性货币 ≠ 报告币种)
  2. 按现行汇率法折算:
     - 资产/负债 → 期末汇率
     - 损益 → 平均汇率 (或交易日汇率)
     - 权益 (实收资本/资本公积) → 历史汇率
     - 未分配利润 → 期初未分配利润(按历史汇率) + 本期净利润(按平均汇率)
  3. 折算差额 → 其他综合收益 (外币财务报表折算差额)
  4. 生成自动调整分录

数据流:
  company_records + company_currency_config + period_rates
      ↓
  translate_company()
      ↓
  translated_records + auto_journal_entry (折算差额)
"""
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
from datetime import date
import json


# 折算方法
METHOD_CURRENT_RATE = "current_rate"  # 现行汇率法 (最常用)
METHOD_TEMPORAL = "temporal"          # 时态法 (高通胀经济体)


# =============================================================================
# 公司币种配置
# =============================================================================

class CompanyCurrencyConfig:
    """
    公司币种配置

    Args:
        company: 公司名称
        functional_currency: 功能性货币 (如 'USD')
        reporting_currency: 报告币种 (如 'CNY')
        method: 折算方法
        historical_rates: 历史汇率字典 {科目编码: 汇率}
    """

    def __init__(self,
                 company: str = "",
                 functional_currency: str = "CNY",
                 reporting_currency: str = "CNY",
                 method: str = METHOD_CURRENT_RATE,
                 historical_rates: Dict[str, float] = None):
        self.company = company
        self.functional_currency = functional_currency
        self.reporting_currency = reporting_currency
        self.method = method
        self.historical_rates = historical_rates or {}

    @property
    def needs_translation(self) -> bool:
        """是否需要折算"""
        return self.functional_currency != self.reporting_currency

    def to_dict(self) -> Dict:
        return {
            'company': self.company,
            'functional_currency': self.functional_currency,
            'reporting_currency': self.reporting_currency,
            'method': self.method,
            'historical_rates': self.historical_rates,
        }

    @staticmethod
    def from_dict(d: Dict) -> 'CompanyCurrencyConfig':
        return CompanyCurrencyConfig(
            company=d.get('company', ''),
            functional_currency=d.get('functional_currency', 'CNY'),
            reporting_currency=d.get('reporting_currency', 'CNY'),
            method=d.get('method', METHOD_CURRENT_RATE),
            historical_rates=d.get('historical_rates', {}),
        )

    def __repr__(self):
        status = "🔄 需折算" if self.needs_translation else "✅ 无需折算"
        return f"[{self.company}] {self.functional_currency}→{self.reporting_currency} {status}"


# =============================================================================
# 科目类型判定 (复用 journal_entry 的分类)
# =============================================================================

def classify_account(code: str) -> str:
    """判定科目类别"""
    if not code:
        return '其他'
    if code.startswith('C'):
        return '现金流'
    if code.startswith('1'):
        return '资产'
    if code.startswith('2'):
        return '负债'
    if code.startswith('4'):
        return '权益'
    if code.startswith(('5', '6')):
        return '损益'
    return '其他'


# 权益类科目 (需要历史汇率或特殊处理)
EQUITY_CODES = {'4001', '4002', '4101', '4104', '4201', '4105'}

# 未分配利润
RETAINED_EARNINGS_CODE = '4104'

# 外币折算差额科目 (其他综合收益)
FX_OCI_CODE = '4201'       # 其他综合收益
FX_RESERVE_CODE = '420101'  # 其他综合收益—外币折算差额 (子科目)


# =============================================================================
# 翻译结果
# =============================================================================

class TranslationResult:
    """一家公司的折算结果"""

    def __init__(self, company: str, config: CompanyCurrencyConfig):
        self.company = company
        self.config = config
        self.translated_records: List[Dict] = []   # 折算后的科目记录
        self.translation_diff: float = 0.0         # 折算差额
        self.details: Dict = {}                    # 详细分析
        self.errors: List[str] = []                # 折算过程中的问题

    def to_dict(self) -> Dict:
        return {
            'company': self.company,
            'functional_currency': self.config.functional_currency,
            'reporting_currency': self.config.reporting_currency,
            'translated_records_count': len(self.translated_records),
            'translation_diff': round(self.translation_diff, 2),
            'details': self.details,
            'errors': self.errors,
        }

    @property
    def success(self) -> bool:
        return len(self.errors) == 0

    @property
    def needs_translation(self) -> bool:
        return self.config.needs_translation


# =============================================================================
# 折算引擎
# =============================================================================

class TranslationEngine:
    """
    外币折算引擎

    用法:
        engine = TranslationEngine()
        result = engine.translate_company(records, config, period_rates)
        或
        results = engine.translate_all(all_records, configs, period_rates)
    """

    def __init__(self, standards_mgr=None):
        self.standards_mgr = standards_mgr

    def translate_company(
        self,
        records: List[Dict],
        config: CompanyCurrencyConfig,
        period_rates: Dict,  # 来自 forex.get_period_rates()
    ) -> TranslationResult:
        """
        对一家公司执行外币折算

        Args:
            records: 该公司原始科目记录 (功能性货币计价)
            config: 币种配置
            period_rates: 期间汇率数据 {
                '期初汇率': {USD: X},
                '期末汇率': {USD: X},
                '平均汇率': {USD: X},
                '期初日期': '...',
                '期末日期': '...',
            }

        Returns:
            TranslationResult
        """
        result = TranslationResult(config.company, config)
        from_ccy = config.functional_currency
        to_ccy = config.reporting_currency

        if not config.needs_translation:
            result.translated_records = list(records)
            result.details = {'无需折算': True}
            return result

        # 获取汇率
        period_end_rate = self._get_rate(period_rates, '期末汇率', from_ccy)
        avg_rate = self._get_rate(period_rates, '平均汇率', from_ccy)
        period_start_rate = self._get_rate(period_rates, '期初汇率', from_ccy)

        if period_end_rate == 0:
            result.errors.append(f"缺少期末汇率: {from_ccy}→{to_ccy}")
            result.translated_records = list(records)
            return result

        translated = []
        analysis = {
            '资产': {'原始': 0, '折算后': 0},
            '负债': {'原始': 0, '折算后': 0},
            '权益': {'原始': 0, '折算后': 0},
            '损益': {'原始': 0, '折算后': 0},
        }

        for r in records:
            code = r.get('科目编码', '')
            amount = r.get('金额', 0)
            report = r.get('报表', '')
            period = r.get('期间类型', '')

            cat = classify_account(code)
            rate = self._determine_rate(
                cat, code, period, report,
                period_end_rate, avg_rate, period_start_rate,
                config,
            )

            if rate == 0 and amount != 0:
                result.errors.append(f"汇率缺失: {code} ({cat}), 原币金额={amount}")

            translated_amount = amount * rate if amount != 0 else 0

            translated.append({
                **r,
                '金额': round(translated_amount, 2),
                '_原始金额': amount,
                '_汇率': rate,
                '_汇率类型': self._rate_type_label(cat, code, period, report),
            })

            # 统计
            if cat in analysis:
                analysis[cat]['原始'] += amount
                analysis[cat]['折算后'] += translated_amount

        # 计算折算差额
        total_original = sum(
            r.get('金额', 0) for r in translated
            if classify_account(r.get('科目编码', '')) in ('资产', '负债', '权益', '损益')
        )
        total_translated = sum(
            r.get('金额', 0) for r in translated
            if classify_account(r.get('科目编码', '')) in ('资产', '负债', '权益', '损益')
        )

        # 资产总计 - (负债+权益) = 折算差额 (四舍五入尾差)
        bs_asset = sum(
            r.get('金额', 0) for r in translated
            if classify_account(r.get('科目编码', '')) == '资产'
        )
        bs_liability_equity = sum(
            r.get('金额', 0) for r in translated
            if classify_account(r.get('科目编码', '')) in ('负债', '权益')
        )
        diff = bs_asset - bs_liability_equity

        # 另外计算：按原始币种的角度算折算差额
        # 资产(外币) × 期末汇率 + ... - 负债(外币)×期末汇率 - 权益(外币)×历史汇率 = 折算差额
        asset_fcy = sum(
            r.get('金额', 0) for r in records if classify_account(r.get('科目编码', '')) == '资产'
        )
        liability_fcy = sum(
            r.get('金额', 0) for r in records if classify_account(r.get('科目编码', '')) == '负债'
        )
        equity_fcy = sum(
            r.get('金额', 0) for r in records if classify_account(r.get('科目编码', '')) == '权益'
        )

        # 理论上: 资产 - 负债 - 权益 = 0 (原币平衡)
        # 折算后: 资产×期末 - 负债×期末 - 权益×历史 = 折算差额
        # = (资产 - 负债) × 期末 - 权益 × 历史
        # = 权益 × (期末 - 历史)  (如果原币平衡)
        theoretical_diff = (asset_fcy - liability_fcy) * period_end_rate - sum(
            r.get('金额', 0) * self._determine_rate(
                '权益', r.get('科目编码', ''), r.get('期间类型', ''), r.get('报表', ''),
                period_end_rate, avg_rate, period_start_rate, config,
            )
            for r in records if classify_account(r.get('科目编码', '')) == '权益'
        )

        result.translation_diff = round(theoretical_diff, 2)
        result.translated_records = translated
        result.details = {
            '汇率': {
                '期初': period_start_rate,
                '期末': period_end_rate,
                '平均': avg_rate,
            },
            '科目分析': analysis,
            '折算差额': result.translation_diff,
            '资产(原币)': round(asset_fcy, 2),
            '负债(原币)': round(liability_fcy, 2),
            '权益(原币)': round(equity_fcy, 2),
        }

        return result

    def translate_all(
        self,
        all_records: List[Dict],
        configs: List[CompanyCurrencyConfig],
        period_rates: Dict,
    ) -> Dict[str, TranslationResult]:
        """
        对所有公司执行批量折算

        Returns:
            {公司名: TranslationResult}
        """
        company_data = defaultdict(list)
        for r in all_records:
            company_data[r.get('company', '')].append(r)

        config_map = {c.company: c for c in configs}

        results = {}
        for company, records in company_data.items():
            config = config_map.get(company, CompanyCurrencyConfig(
                company=company,
                reporting_currency=configs[0].reporting_currency if configs else 'CNY',
            ))
            results[company] = self.translate_company(records, config, period_rates)

        return results

    def generate_fx_journal(
        self,
        result: TranslationResult,
        description: str = "",
    ) -> Optional[Dict]:
        """
        从折算结果生成自动调整分录

        折算差额直接计入其他综合收益—外币折算差额，无需过渡科目。
        差额 = 折算后资产 - 折算后负债 - 折算后权益（含未分配利润）

        分录:
          借: 其他综合收益—外币折算差额 (折算差额为负时，表示损失)
          贷: 其他综合收益—外币折算差额 (折算差额为正时，表示收益)
        """
        if not result.config.needs_translation or abs(result.translation_diff) < 0.01:
            return None

        diff = result.translation_diff
        desc = description or f"外币折算差额—{result.company} ({result.config.functional_currency}→{result.config.reporting_currency})"

        journal = {
            'id': -1,
            'description': desc,
            'date': '',
            'company': result.company,
            'context': '外币折算',
            'lines': [],
            'auto_adjustments': [],
        }

        # 折算差额直接计入 OCI (双方均为 420101)
        # diff > 0: 资产折算后 > 负债+权益 → 折算收益 → 贷:OCI
        # diff < 0: 资产折算后 < 负债+权益 → 折算损失 → 借:OCI
        if diff > 0:
            # 借: 其他综合收益—外币折算差额
            journal['lines'].append({
                'side': 'debit',
                'code': FX_RESERVE_CODE,
                'name': '其他综合收益—外币折算差额',
                'amount': round(abs(diff), 2),
            })
            journal['lines'].append({
                'side': 'credit',
                'code': FX_RESERVE_CODE,
                'name': '其他综合收益—外币折算差额',
                'amount': round(abs(diff), 2),
            })
        else:
            journal['lines'].append({
                'side': 'debit',
                'code': FX_RESERVE_CODE,
                'name': '其他综合收益—外币折算差额',
                'amount': round(abs(diff), 2),
            })
            journal['lines'].append({
                'side': 'credit',
                'code': FX_RESERVE_CODE,
                'name': '其他综合收益—外币折算差额',
                'amount': round(abs(diff), 2),
            })

        return journal

    # ======================================================================
    # 内部方法
    # ======================================================================

    def _get_rate(self, period_rates: Dict, rate_type: str, currency: str) -> float:
        """从 period_rates 中提取指定汇率"""
        rates = period_rates.get(rate_type, {})
        return float(rates.get(currency, 0))

    def _determine_rate(
        self,
        cat: str, code: str, period: str, report: str,
        period_end_rate: float, avg_rate: float, period_start_rate: float,
        config: CompanyCurrencyConfig,
    ) -> float:
        """
        确定该科目应使用的汇率

        CAS 19 / IAS 21:
        - 资产/负债 → 期末汇率
        - 损益 → 平均汇率
        - 权益 (实收资本/资本公积) → 历史汇率
        - 未分配利润 → 年初未分配利润(历史) + 本年净利润(平均)
        - 现金流量表 → 平均汇率
        """
        if cat in ('资产', '负债'):
            return period_end_rate if period_end_rate else 0

        if cat == '损益':
            return avg_rate if avg_rate else (period_end_rate or 0)

        if cat == '权益':
            # 未分配利润: CAS 19 要求按"期初(历史)+本期净利润(平均)-分配(历史)"计算
            # 系统中未拆分明细, 使用平均汇率作为近似（比期末汇率更合理）
            if code == RETAINED_EARNINGS_CODE:
                return avg_rate if avg_rate else (period_end_rate or 0)
            # 实收资本/资本公积 → 历史汇率 (简化: 用期初)
            return period_start_rate if period_start_rate else (period_end_rate or 0)

        if cat == '现金流':
            return avg_rate if avg_rate else (period_end_rate or 0)

        return period_end_rate or 0

    def _rate_type_label(self, cat: str, code: str, period: str, report: str) -> str:
        """汇率类型标签 (用于显示)"""
        if cat in ('资产', '负债'):
            return "期末汇率"
        if cat == '损益':
            return "平均汇率"
        if cat == '权益':
            if code == RETAINED_EARNINGS_CODE:
                return "期末汇率(未分配利润)"
            return "历史汇率"
        if cat == '现金流':
            return "平均汇率"
        return "期末汇率"
