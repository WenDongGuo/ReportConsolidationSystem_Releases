"""
汇率服务 — 通过 Frankfurter API 获取外币兑人民币汇率

功能:
- 期初汇率 (period_start 即期汇率)
- 期末汇率 (period_end 即期汇率)
- 期间平均汇率 (period_start ~ period_end 简单算术平均)

数据源: https://api.frankfurter.dev/v1/
返回格式: 1 外币 = X 人民币 (直接标价法)
"""
import json
import os
import time
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

# Frankfurter API 基础 URL
API_BASE = "https://api.frankfurter.dev/v1"

# 缓存目录
CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'output', '.forex_cache')
os.makedirs(CACHE_DIR, exist_ok=True)

# 常用货币列表 (用于 UI 选择)
MAJOR_CURRENCIES = {
    "CNY": "人民币 (CNY)",
    "USD": "美元 (USD)",
    "EUR": "欧元 (EUR)",
    "GBP": "英镑 (GBP)",
    "JPY": "日元 (JPY)",
    "HKD": "港币 (HKD)",
    "KRW": "韩元 (KRW)",
    "TWD": "新台币 (TWD)",
    "SGD": "新加坡元 (SGD)",
    "THB": "泰铢 (THB)",
    "INR": "印度卢比 (INR)",
    "AUD": "澳大利亚元 (AUD)",
    "CAD": "加拿大元 (CAD)",
    "CHF": "瑞士法郎 (CHF)",
    "NZD": "新西兰元 (NZD)",
    "MYR": "马来西亚林吉特 (MYR)",
    "VND": "越南盾 (VND)",
    "PHP": "菲律宾比索 (PHP)",
    "IDR": "印尼盾 (IDR)",
    "MOP": "澳门元 (MOP)",
    "RUB": "俄罗斯卢布 (RUB)",
}

# API 支持的全部币种 (以 CNY 为基准)
SUPPORTED_CURRENCIES = set(MAJOR_CURRENCIES.keys())

# 缓存有效期 (秒)
CACHE_TTL = 3600  # 1 小时


class ForexError(Exception):
    """汇率查询异常"""
    pass


class ForexRates:
    """一组汇率数据"""

    def __init__(self, base_currency: str = "CNY"):
        self.base = base_currency
        self.rates: Dict[str, float] = {}  # 外币 → 人民币 汇率
        self.date: Optional[str] = None
        self.fetched_at: Optional[str] = None

    def to_cny(self, foreign_amount: float, currency: str) -> float:
        """外币金额 → 人民币"""
        if currency == self.base or currency == "CNY":
            return foreign_amount
        rate = self.rates.get(currency)
        if rate is None:
            raise ForexError(f"未找到汇率: {currency}")
        # Frankfurter 返回 1 CNY = X 外币, 需取倒数
        return foreign_amount / rate

    def from_cny(self, cny_amount: float, currency: str) -> float:
        """人民币 → 外币金额"""
        if currency == self.base or currency == "CNY":
            return cny_amount
        rate = self.rates.get(currency)
        if rate is None:
            raise ForexError(f"未找到汇率: {currency}")
        return cny_amount * rate


def _api_request(endpoint: str) -> Optional[Dict]:
    """
    调用 Frankfurter API (含 HTTP 429 限流重试)

    Args:
        endpoint: API 路径, 如 'latest?base=CNY' 或 '2025-01-01?base=CNY'

    Returns:
        解析后的 JSON 字典, 失败返回 None
    """
    url = f"{API_BASE}/{endpoint}"
    max_retries = 3
    for attempt in range(max_retries):
        try:
            req = Request(url, headers={"User-Agent": "Hermes-Agent/1.0"})
            with urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except HTTPError as e:
            if e.code == 429 and attempt < max_retries - 1:
                wait = 2 ** attempt  # 指数退避: 1s, 2s, 4s
                time.sleep(wait)
                continue
            return None
        except (URLError, json.JSONDecodeError, TimeoutError):
            return None
    return None


def _cache_key(date_str: str) -> str:
    """缓存文件名"""
    safe_date = date_str.replace('..', '_to_')
    return os.path.join(CACHE_DIR, f"fx_{safe_date}.json")


def _read_cache(cache_path: str, max_age: int = CACHE_TTL) -> Optional[Dict]:
    """读取缓存"""
    if not os.path.exists(cache_path):
        return None
    try:
        with open(cache_path, 'r') as f:
            data = json.load(f)
        cached_time = data.get('_cached_at', 0)
        if time.time() - cached_time > max_age:
            return None
        return data
    except (json.JSONDecodeError, OSError):
        return None


def _write_cache(cache_path: str, data: Dict):
    """写入缓存"""
    data['_cached_at'] = time.time()
    try:
        with open(cache_path, 'w') as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_rates(date_obj: date) -> ForexRates:
    """
    获取指定日期的即期汇率 (所有币种→人民币)

    Args:
        date_obj: 查询日期

    Returns:
        ForexRates 对象, 失败时返回空对象
    """
    date_str = date_obj.isoformat()
    cache_path = _cache_key(date_str)

    # 尝试缓存
    cached = _read_cache(cache_path)
    if cached:
        rates = ForexRates()
        rates.rates = cached.get('rates', {})
        rates.date = cached.get('date', date_str)
        rates.fetched_at = cached.get('fetched_at')
        return rates

    # API 请求
    result = _api_request(f"{date_str}?base=CNY")
    if result is None:
        # 尝试前一个工作日 (Frankfurter 只返回工作日数据)
        for offset in range(1, 8):
            prev = date_obj - timedelta(days=offset)
            result = _api_request(f"{prev.isoformat()}?base=CNY")
            if result:
                date_str = prev.isoformat()
                break

    if result is None:
        return ForexRates()

    rates = ForexRates()
    rates.rates = result.get('rates', {})
    rates.date = result.get('date', date_str)
    rates.fetched_at = datetime.now().isoformat()

    # 写缓存
    _write_cache(cache_path, {
        'date': rates.date,
        'rates': rates.rates,
        'fetched_at': rates.fetched_at,
    })

    return rates


def get_period_rates(period_start: date, period_end: date) -> Dict:
    """
    获取完整期间汇率数据

    返回:
        {
            '期间': f"{start} ~ {end}",
            '期初汇率': { USD: X, EUR: Y, ... },    # 1外币=X人民币 (期初日即期汇率)
            '期末汇率': { USD: X, EUR: Y, ... },    # 1外币=X人民币 (期末日即期汇率)
            '平均汇率': { USD: X, EUR: Y, ... },    # 1外币=X人民币 (期间简单算术平均)
            '可用币种': [ "USD", "EUR", ... ],
        }
    """
    # 获取期初汇率
    start_rates = get_rates(period_start)
    end_rates = get_rates(period_end)

    # 获取期间平均值 — 通过时间序列计算
    avg_rates = _calc_average_rates(period_start, period_end)

    # 合并所有出现的币种
    all_currencies = set()
    for r in [start_rates, end_rates]:
        all_currencies.update(r.rates.keys())

    result = {
        '期间': f"{period_start.isoformat()} ~ {period_end.isoformat()}",
        # Frankfurter 返回 1 CNY = X 外币，反转后得到 1 外币 = X 人民币
        '期初汇率': {ccy: round(1 / start_rates.rates.get(ccy, 0), 6)
                    if start_rates.rates.get(ccy, 0) != 0 else 0
                    for ccy in sorted(all_currencies)},
        '期末汇率': {ccy: round(1 / end_rates.rates.get(ccy, 0), 6)
                    if end_rates.rates.get(ccy, 0) != 0 else 0
                    for ccy in sorted(all_currencies)},
        '平均汇率': {ccy: round(1 / avg_rates.get(ccy, 0), 6)
                    if avg_rates.get(ccy, 0) != 0 else 0
                    for ccy in sorted(all_currencies)},
        '可用币种': sorted(all_currencies),
        '期初日期': period_start.isoformat(),
        '期末日期': period_end.isoformat(),
    }

    return result


def _calc_average_rates(period_start: date, period_end: date) -> Dict[str, float]:
    """
    计算期间平均汇率 (简单算术平均)

    通过 Frankfurter 时间序列 API 获取期间的每日汇率后求平均
    """
    date_range = f"{period_start.isoformat()}..{period_end.isoformat()}"
    cache_path = _cache_key(date_range)

    # 检查缓存
    cached = _read_cache(cache_path)
    if cached:
        return cached.get('average', {})

    # 调用时间序列 API
    result = _api_request(f"{date_range}?base=CNY")

    if result is None:
        return {}

    rates_by_date = result.get('rates', {})
    if not rates_by_date:
        return {}

    # 计算每个币种的平均值
    currency_sums: Dict[str, float] = {}
    currency_counts: Dict[str, int] = {}

    for dt, day_rates in rates_by_date.items():
        for ccy, rate in day_rates.items():
            currency_sums[ccy] = currency_sums.get(ccy, 0) + rate
            currency_counts[ccy] = currency_counts.get(ccy, 0) + 1

    averages = {}
    for ccy in currency_sums:
        if currency_counts[ccy] > 0:
            raw_avg = currency_sums[ccy] / currency_counts[ccy]
            # Frankfurter 返回 1 CNY = X 外币, 反转得到 1 外币 = X 人民币
            if raw_avg != 0:
                averages[ccy] = round(1 / raw_avg, 6)
            else:
                averages[ccy] = 0.0

    # 写缓存 (已反转, 1 外币 = X 人民币)
    _write_cache(cache_path, {
        'period': date_range,
        'average': averages,
    })

    return averages


def get_available_currencies() -> List[str]:
    """获取当前支持的币种列表"""
    return sorted(SUPPORTED_CURRENCIES)


def format_rate_table(period_rates: Dict) -> List[Dict]:
    """
    将汇率数据格式化为表格行 (用于 UI 展示)

    返回: [{币种, 币种名称, 期初汇率, 期末汇率, 平均汇率, 变动}]
    """
    start = period_rates.get('期初汇率', {})
    end = period_rates.get('期末汇率', {})
    avg = period_rates.get('平均汇率', {})

    rows = []
    for ccy in sorted(set(list(start.keys()) + list(end.keys()) + list(avg.keys()))):
        s = start.get(ccy, 0)
        e = end.get(ccy, 0)
        a = avg.get(ccy, 0)

        if s == 0 and e == 0 and a == 0:
            continue

        # 变动率 (期末 vs 期初)
        change = ""
        if s and s != 0:
            pct = (e - s) / s * 100
            change = f"{pct:+.2f}%" if abs(pct) > 0.01 else "—"

        rows.append({
            '币种': ccy,
            '币种名称': MAJOR_CURRENCIES.get(ccy, ccy),
            '期初汇率': f"{s:.6f}" if s else "—",
            '期末汇率': f"{e:.6f}" if e else "—",
            '平均汇率': f"{a:.6f}" if a else "—",
            '变动': change,
        })

    return rows
