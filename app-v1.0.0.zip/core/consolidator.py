"""
合并引擎 — 企业合并财务报表核心逻辑

基于 CAS 33 (合并财务报表) 准则实现：
1. 长期股权投资与子公司所有者权益的抵消（全额法）
2. 内部交易抵消（往来款项）
3. 少数股东权益/损益计算
4. 合并汇总（全额法合并）

关键设计:
  - 全额法: 子公司 100% 并入，通过少数股东权益/损益口径反映非全资部分
  - 长投抵消分项: 按每家子公司的权益占比分配母公司长期股权投资
"""
from typing import Dict, List, Optional, Any, Callable
from collections import defaultdict


class ConsolidationJournal:
    """一条合并抵消分录"""

    def __init__(self, description: str, category: str = ""):
        self.description = description
        self.category = category
        self.entries = []  # [{科目编码, 科目名称, 金额(正=借,负=贷), 公司}]

    def add_entry(self, account_code: str, account_name: str, amount: float,
                  company: str = "合并抵消"):
        self.entries.append({
            '科目编码': account_code,
            '科目名称': account_name,
            '金额': amount,      # 正数=借方, 负数=贷方
            '公司': company,
        })

    def to_dict(self) -> Dict:
        total = sum(e['金额'] for e in self.entries)
        return {
            '说明': self.description,
            '类别': self.category,
            '分录': self.entries,
            '借贷平衡': abs(total) < 0.01,
            '借贷差额': round(total, 2),
        }


class ConsolidationResult:
    """合并结果"""

    def __init__(self, parent_name: str):
        self.parent = parent_name
        self.journals = []
        self.consolidated = []
        self.detail = {'母公司': [], '子公司': [], '少数股东': []}
        self.minority_interests = {}
        self.minority_pnl = {}

    def add_journal(self, journal: ConsolidationJournal):
        self.journals.append(journal.to_dict())

    def summary(self) -> Dict:
        return {
            '母公司': self.parent,
            '子公司数': len(self.detail.get('子公司', [])),
            '抵消分录数': len(self.journals),
            '合并科目数': len(self.consolidated),
            '少数股东权益': sum(self.minority_interests.values()),
            '少数股东损益': sum(self.minority_pnl.values()),
        }


class ConsolidationEngine:
    """
    合并引擎 — 全额法合并

    用法:
        engine = ConsolidationEngine(standards_mgr)
        result = engine.execute(all_records, equity_config, adjustments)

    配置:
        科目编码从 config/consolidation/subjects.yaml 和 offset_rules.yaml 读取
        不再硬编码 — 换会计准则只需要改 YAML 配置
    """

    def __init__(self, standards_mgr=None, config_dir=None):
        self.standards_mgr = standards_mgr
        self._accounts_lookup = {}

        # 从 YAML 配置读取合并科目编码
        from .consolidation_config import ConsolidationConfig
        self._cfg = ConsolidationConfig(config_dir)
        self._cfg.load()

        # 内部往来抵消对（从配置读取）
        self._internal_pairs = self._cfg.build_internal_pairs()

        # 权益抵消科目组（从配置读取）
        self._equity_subjects = set(self._cfg.build_equity_accounts())

    def execute(self, all_records: List[Dict], equity_config: Any,
                adjustments: List[Dict] = None) -> ConsolidationResult:
        parent, subs = self._parse_equity(equity_config)
        result = ConsolidationResult(parent)
        company_data = self._group_by_company(all_records)
        parent_data = company_data.get(parent, [])
        result.detail['母公司'] = parent_data

        # ---- 步骤 1: 构建子公司数据明细 ----
        # 引擎不再自动生成抵消分录，所有分录由用户在 Step 6 页面手工录入
        for sub in subs:
            sub_data = company_data.get(sub['name'], [])
            result.detail['子公司'].append({'name': sub['name'], 'data': sub_data})

        # ---- 步骤 2: 内部交易抵消 ----
        internal_journals = self._offset_internal_transactions(
            company_data, parent, subs, result
        )
        for j in internal_journals:
            result.add_journal(j)

        # ---- 步骤 3: 用户调整分录 ----
        # 按 entry_id 或 说明 字段合并：同一笔分录的多行被拆成多个 adj dict
        # 需要重新合并回一个 ConsolidationJournal
        if adjustments:
            # Group adj dicts by entry key (entry_id > description)
            grouped = {}
            order = []
            for adj in adjustments:
                eid = adj.get('entry_id', adj.get('说明', ''))
                if eid not in grouped:
                    grouped[eid] = []
                    order.append(eid)
                grouped[eid].append(adj)

            for eid in order:
                adj_list = grouped[eid]
                j = ConsolidationJournal(
                    adj_list[0].get('说明', '用户调整'),
                    category="用户调整"
                )
                for adj in adj_list:
                    debit_account = adj.get('借方', adj.get('debit_account', ''))
                    credit_account = adj.get('贷方', adj.get('credit_account', ''))
                    amount = float(adj.get('金额', adj.get('amount', 0)))
                    debit_code = self._resolve_account(debit_account)
                    credit_code = self._resolve_account(credit_account)

                    if debit_code and abs(amount) > 0.01:
                        j.add_entry(debit_code, debit_account, amount, "调整")
                    if credit_code and abs(amount) > 0.01:
                        j.add_entry(credit_code, credit_account, -amount, "调整")
                result.add_journal(j)

        # ---- 步骤 4: 合并汇总（全额法）----
        result.consolidated = self._aggregate(
            all_records, result.journals, parent, subs
        )

        return result

    def _parse_equity(self, config: Any) -> tuple:
        if not config:
            return ('', [])
        if isinstance(config, list):
            tops = [r for r in config if not r.get('其母公司')]
            parent = tops[0]['公司'] if tops else config[0]['公司']
            subs = []
            for r in config:
                if r.get('其母公司'):
                    ratio = float(r.get('持股比例(%)', 0) or 0) / 100.0
                    vote = float(r.get('表决权比例(%)', 0) or 0) / 100.0
                    method = r.get('并表触发方式', '')
                    is_control = '未形成控制' not in method and bool(r.get('其母公司'))
                    subs.append({
                        'name': r['公司'],
                        'ratio': ratio if is_control else 0,
                        'vote_ratio': vote, 'method': method,
                        'note': r.get('关键判断点', ''),
                        'start_date': r.get('并表起点', ''),
                        'is_control': is_control,
                    })
            return parent, subs
        else:
            parent = config.get('parent', '母公司')
            raw_subs = config.get('subsidiaries', [])
            subs = []
            for s in raw_subs:
                ratio = float(s.get('ratio', 0))
                subs.append({
                    'name': s.get('name', ''),
                    'ratio': ratio, 'vote_ratio': ratio,
                    'method': '直接投资设立' if ratio > 0.5 else '其他',
                    'note': '', 'start_date': '',
                    'is_control': ratio > 0.5,
                })
            return parent, subs

    def _group_by_company(self, records: List[Dict]) -> Dict[str, List]:
        groups = defaultdict(list)
        for r in records:
            groups[r.get('company', '未知')].append(r)
        return dict(groups)

    def _find_amount(self, data: List[Dict], subject_code: str,
                     statement: str = None, period: str = None,
                     company_hint: str = None) -> float:
        matches = []
        for r in data:
            if r.get('科目编码') != subject_code:
                continue
            if statement is not None and r.get('报表') != statement:
                continue
            if period is not None and r.get('期间类型') != period:
                continue
            if company_hint is not None:
                record_text = (str(r.get('公司', '')) + str(r.get('company', '')) +
                               str(r.get('备注', '')) + str(r.get('摘要', '')) +
                               str(r.get('科目名称', '')))
                if company_hint not in record_text:
                    continue
            matches.append(r.get('金额', 0))
        return sum(matches) if matches else 0.0

    @staticmethod
    def _infer_statement(code: str):
        """
        根据科目编码推断所属报表和期间
        Returns: (报表, 期间)
        """
        if not code:
            return ('资产负债表', '期末余额')
        if code.startswith('6'):
            return ('利润表', '本年累计')
        if code.startswith('C') or code.startswith('7'):
            return ('现金流量表', '本年累计')
        # 4xxx 权益类, 1xxx/2xxx 资产负债类
        return ('资产负债表', '期末余额')

    def _offset_internal_transactions(
        self, company_data: Dict, parent: str,
        subs: List[Dict], result: ConsolidationResult
    ) -> List[ConsolidationJournal]:
        """内部交易抵消

        注意: 系统不再自动估算内部往来金额（无法知道具体公司间的挂账）。
        用户通过 Step 6 页面上的「快速模板」按钮生成内部往来抵消分录，
        手动填写实际金额后再执行合并。

        本方法仅返回 0 条分录。内部收入/成本抵消、存货未实现利润、
        内部固定资产交易等复杂抵消也需用户手工录入。
        """
        return []

    def _apply_adjustment(self, adj: Dict) -> ConsolidationJournal:
        description = adj.get('说明', adj.get('description', '用户调整'))
        j = ConsolidationJournal(description, category="用户调整")

        debit_account = adj.get('借方', adj.get('debit_account', ''))
        credit_account = adj.get('贷方', adj.get('credit_account', ''))
        amount = float(adj.get('金额', adj.get('amount', 0)))

        debit_code = self._resolve_account(debit_account)
        credit_code = self._resolve_account(credit_account)

        if debit_code and abs(amount) > 0.01:
            j.add_entry(debit_code, debit_account, amount, "调整")
        if credit_code and abs(amount) > 0.01:
            j.add_entry(credit_code, credit_account, -amount, "调整")

        return j

    @staticmethod
    def _normalize_journal_amt(code: str, journal_amt: float) -> float:
        """
        将合并抵消分录的金额按科目类型转换为余额增减方向。

        ConsolidationJournal 格式: 正数=借, 负数=贷
        但 _aggregate 需要: 正数=余额增加, 负数=余额减少

        转换规则:
          - 借方余额科目(资产/费用): 借=增, 贷=减 → journal 金额不变
          - 贷方余额科目(负债/权益/收入): 贷=增, 借=减 → journal 金额反号
        """
        if code.startswith('1') or code.startswith('2') or code.startswith('3'):
            # 资产(1xxx)通常借方余额；成本(4xxx开头的不一定)
            # 更精确：用正常的余额方向
            from core.journal_entry import get_normal_balance
            normal = get_normal_balance(code)
            if normal == 'credit':
                return -journal_amt
            return journal_amt
        elif code.startswith('4'):
            # 权益(4xxx) = 贷方余额
            from core.journal_entry import get_normal_balance
            normal = get_normal_balance(code)
            if normal == 'debit':
                return journal_amt
            return -journal_amt
        elif code.startswith('5') or code.startswith('6'):
            # 5xxx=成本, 6xxx=损益 — 多数借方余额，收入类(60xx, 61xx)例外
            from core.journal_entry import get_normal_balance
            normal = get_normal_balance(code)
            if normal == 'credit':
                return -journal_amt
            return journal_amt
        elif code.startswith('C') or code.startswith('7'):
            # 现金流
            return journal_amt
        else:
            return journal_amt

    def _aggregate(self, all_records: List[Dict], journals: List[Dict],
                   parent: str, subs: List[Dict]) -> List[Dict]:
        """
        合并汇总 — 全额法

        规则:
        1. 母公司 100% 全额并入
        2. 子公司 100% 全额并入（不乘持股比例）
        3. 应用抵消分录（含少数股东权益调整）
        """
        company_groups = self._group_by_company(all_records)

        # 构建抵消分录影响图谱: 包含报表和期间信息
        offset_map = defaultdict(float)
        offset_map_fallback = defaultdict(float)  # 无报表/期间信息的兜底匹配
        for journal in journals:
            for entry in journal.get('分录', []):
                code = entry.get('科目编码', '')
                report = entry.get('报表', '')
                period = entry.get('期间', '')
                amt = entry.get('金额', 0)
                key = (code, report, period)
                offset_map[key] += amt
                # 兜底: 也按纯科目编码累计
                offset_map_fallback[code] += amt

        # 全额汇总：母公司 100% + 子公司 100%
        merged = defaultdict(float)

        for r in company_groups.get(parent, []):
            key = (r.get('科目编码', ''), r.get('报表', ''), r.get('期间类型', ''))
            merged[key] += r.get('金额', 0)

        for sub in subs:
            for r in company_groups.get(sub['name'], []):
                key = (r.get('科目编码', ''), r.get('报表', ''), r.get('期间类型', ''))
                merged[key] += r.get('金额', 0)  # 全额法：不乘比例

        # 应用抵消分录：优先精确匹配，失败时用兜底
        for (code, report, period), offset_amt in list(offset_map.items()):
            key = (code, report or '', period or '')
            # 将 journal 格式金额（正=借, 负=贷）转换为余额增减方向
            # 借方余额科目: 借↑贷↓ → journal金额不变
            # 贷方余额科目: 借↓贷↑ → journal金额取反
            balance_amt = self._normalize_journal_amt(code, offset_amt)
            if key in merged:
                merged[key] += balance_amt
            elif abs(balance_amt) > 0.01:
                # 找同科目的所有键（应对多期间数据，如期末+年初余额）
                found = False
                for mk in merged:
                    if mk[0] == code:
                        merged[mk] += balance_amt
                        found = True
                if not found:
                    # 新科目（如少数股东权益4105）— 根据科目编码推断报表和期间
                    inferred_report, inferred_period = self._infer_statement(code)
                    merged[(code, inferred_report, inferred_period)] += balance_amt

        # 应用兜底（防漏：无报表/期间标的抵消额确保已生效）
        for code, fallback_amt in offset_map_fallback.items():
            # 如果已通过精确匹配处理过则跳过
            already = False
            for mk in merged:
                if mk[0] == code:
                    already = True
                    break
            if not already and abs(fallback_amt) > 0.01:
                merged[(code, '', '')] += self._normalize_journal_amt(code, fallback_amt)

        # 转为列表
        code_name_cache = {}
        for r in all_records:
            code = r.get('科目编码', '')
            if code and code not in code_name_cache:
                code_name_cache[code] = r.get('科目名称', '')

        result = []
        seen = set()
        for (code, report, period), amount in merged.items():
            if abs(amount) < 0.01:
                continue
            key = (code, report, period)
            if key in seen:
                continue
            seen.add(key)
            name = code_name_cache.get(code, code)
            result.append({
                'company': '合并报表',
                '科目编码': code,
                '科目名称': name,
                '金额': round(amount, 2),
                '报表': report or '',
                '期间类型': period or '',
            })

        return result

    def _get_name(self, code: str) -> str:
        if not self.standards_mgr:
            return code
        accounts = self.standards_mgr.get_accounts_flat('cas')
        for a in accounts:
            if a['编码'] == code:
                return a['名称']
        # 合并特有科目
        extra = {'4105': '少数股东权益', '6902': '少数股东损益',
                 '4201': '其他综合收益', '420101': '其他综合收益—外币折算差额'}
        return extra.get(code, code)

    def _resolve_account(self, name: str) -> Optional[str]:
        """根据科目名称找编码"""
        if not name:
            return None
        if not self.standards_mgr:
            return name
        accounts = self.standards_mgr.get_accounts_flat('cas')
        for a in accounts:
            if name == a['名称'] or name == a['编码']:
                return a['编码']
        # 按名称模糊匹配
        for a in accounts:
            if name in a['名称'] or a['名称'] in name:
                return a['编码']
        return name
