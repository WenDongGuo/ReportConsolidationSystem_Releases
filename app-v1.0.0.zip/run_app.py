"""
合并报表系统 — EXE 启动入口

双击运行：启动 Streamlit 服务并打开浏览器。
采用 subprocess 方式启动，比 bootstrap 更兼容 PyInstaller 打包。
"""
import sys
import os
import webbrowser
import threading
import time
import socket
import subprocess


def find_free_port():
    """找一个空闲端口"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        return s.getsockname()[1]


def open_browser(port, delay=3):
    """延迟打开浏览器"""
    time.sleep(delay)
    webbrowser.open(f'http://localhost:{port}')


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # PyInstaller 打包后资源在 _MEIPASS
    if getattr(sys, 'frozen', False):
        # 打包模式
        work_dir = sys._MEIPASS
    else:
        work_dir = base_dir

    # 找空端口
    port = find_free_port()
    url = f'http://localhost:{port}'
    print(f"🚀 启动合并报表系统 → {url}")

    # 后台打开浏览器
    threading.Thread(target=open_browser, args=(port,), daemon=True).start()

    # 主页面路径
    app_path = os.path.join(work_dir, 'app', 'app.py')

    if not os.path.exists(app_path):
        print(f"❌ 未找到入口文件: {app_path}")
        input("\n按 Enter 键退出...")
        sys.exit(1)

    # 方式1: 用 streamlit run 启动（推荐，兼容性最好）
    cmd = [
        sys.executable, '-m', 'streamlit', 'run', app_path,
        '--server.port', str(port),
        '--server.address', 'localhost',
        '--server.headless', 'true',
        '--browser.gatherUsageStats', 'false',
    ]

    try:
        proc = subprocess.run(cmd, cwd=work_dir)
        if proc.returncode != 0:
            print(f"\n⚠️ Streamlit 进程退出 (代码: {proc.returncode})")
            input("\n按 Enter 键退出...")
    except Exception as e:
        print(f"❌ 启动失败: {e}")
        input("\n按 Enter 键退出...")


if __name__ == '__main__':
    main()
