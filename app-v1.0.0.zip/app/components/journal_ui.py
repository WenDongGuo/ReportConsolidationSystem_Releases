"""
会计分录 UI 组件 (Journal Entry UI)

供 Step 4（单体调整）和 Step 6（合并抵消）共用的 Streamlit UI 组件。

用法:
  from app.components.journal_ui import JournalEntryUI
  
  ui = JournalEntryUI(key_prefix='step4', context_name='单体调整')
  ui.render_add_form(company, account_groups, standards_mgr)
  ui.render_entry_list(company)
  ui.render_impact_preview()
"""
import sys, os
from typing import Dict, List, Optional, Callable
from datetime import date

import streamlit as st
import pandas as pd

# Import journal engine
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from core.journal_entry import (
    JournalEntry, JournalLine, JournalManager,
    DEFAULT_ACCOUNT_GROUPS, CF_CATEGORIES, CF_CATEGORY_NAMES,
)


class JournalEntryUI:
    """
    会计分录 UI 管理器
    
    封装了分录的增/删/查/改 + 科目选择 + 联动规则配置。
    同一个组件可被 Step 4 和 Step 6 共用，差异仅在于配置。
    
    Args:
        key_prefix: Streamlit widget key 前缀 (避免跨页面冲突)
        context_name: 上下文名称 ('单体调整' / '合并抵消')
        storage_key: session_state 存储 key (默认=context_name)
        account_groups: 科目分组配置 (默认=DEFAULT_ACCOUNT_GROUPS)
        cf_categories: 现金流类别 (默认=CF_CATEGORIES)
        standards_mgr: 科目名称解析器
    """

    def __init__(
        self,
        key_prefix: str = "je",
        context_name: str = "会计分录",
        storage_key: str = None,
        account_groups: Dict[str, List[str]] = None,
        cf_categories: Dict[str, List[str]] = None,
        standards_mgr=None,
    ):
        self.key_prefix = key_prefix
        self.context_name = context_name
        self.storage_key = storage_key or context_name
        self.account_groups = account_groups or DEFAULT_ACCOUNT_GROUPS
        self.cf_categories = cf_categories or CF_CATEGORIES
        self.standards_mgr = standards_mgr
        self._init_state()

    def _init_state(self):
        """确保 session_state 中有 JournalManager"""
        if self.storage_key not in st.session_state:
            st.session_state[self.storage_key] = JournalManager(context_name=self.context_name)
            return
        mgr = st.session_state[self.storage_key]
        # 兼容旧格式 dict → JournalManager 迁移
        if isinstance(mgr, dict):
            new_mgr = JournalManager(context_name=self.context_name)
            from core.journal_entry import JournalEntry as JE
            for company, entries_list in mgr.items():
                for ed in entries_list:
                    entry = JE.from_dict(ed)
                    if entry.id:
                        new_mgr._next_id = max(new_mgr._next_id, entry.id + 1)
                    new_mgr.add(entry)
            st.session_state[self.storage_key] = new_mgr
            mgr = new_mgr
        if not mgr.context:
            mgr.context = self.context_name

    @property
    def manager(self) -> JournalManager:
        """获取当前 JournalManager"""
        return st.session_state[self.storage_key]

    # ======================================================================
    # 科目名称解析
    # ======================================================================

    def _get_account_name(self, code: str) -> str:
        """获取科目名称"""
        if self.standards_mgr:
            accounts = self.standards_mgr.get_accounts_flat('cas')
            for a in accounts:
                if a['编码'] == code:
                    return a['名称']
        return code

    def _build_account_options(self, codes: List[str]) -> List[str]:
        """构建 {编码 名称} 选项列表"""
        options = []
        for c in codes:
            name = self._get_account_name(c)
            options.append(f"{c} {name}")
        return options

    # ======================================================================
    # 渲染: 新增分录表单
    # ======================================================================

    def render_add_form(
        self,
        company: str = "",
        show_company_selector: bool = False,
        companies: List[str] = None,
        show_cf: bool = True,
        linking_rules: List[str] = None,
        on_save_callback: Callable = None,
        period_start: str = "",
        period_end: str = "",
    ):
        """
        渲染复式记账新增分录表单
        
        Args:
            company: 当前选中的公司 (Step 4 用)
            show_company_selector: 是否显示公司下拉框 (Step 6 可能需要)
            companies: 可选公司列表
            show_cf: 是否显示现金流联动选项
            linking_rules: 联动规则列表, None=默认全部
            on_save_callback: 保存后的回调
        """
        st.markdown("#### 新增分录")
        st.caption("借 = 贷，复式记账")

        # 公司选择 (可选)
        selected_company = company
        if show_company_selector and companies:
            selected_company = st.selectbox(
                "公司", companies,
                key=f"{self.key_prefix}_company",
            )

        # 描述 + 调整类型
        col_desc, col_type = st.columns([3, 1])
        with col_desc:
            desc = st.text_input(
                "调整说明",
                placeholder="如: 补提折旧、内部交易抵消",
                key=f"{self.key_prefix}_desc",
            )
        with col_type:
            adj_type_options = ["期末", "期初"]
            adj_type = st.selectbox(
                "调整类型",
                adj_type_options,
                index=0,
                key=f"{self.key_prefix}_adj_type",
                help="期初=调整年初余额(上期期末), 期末=调整本期期末余额",
            )
        # 实际日期根据调整类型自动获取
        period_start = period_start or str(date.today())
        period_end = period_end or str(date.today())
        adj_date = period_end if adj_type == "期末" else period_start

        st.markdown("---")
        
        # ===== 借贷行列表 (支持多条) =====
        # 初始化行的数量
        row_count_key = f"{self.key_prefix}_row_count"
        if row_count_key not in st.session_state:
            st.session_state[row_count_key] = 2  # 默认一借一贷

        # 当前行数
        n_rows = st.session_state[row_count_key]

        # 存储所有行数据
        lines_config = []

        # CF 类别选项列表（完整名称，供涉现行选择）
        cf_options_flat = []
        for cat_name, codes in self.cf_categories.items():
            for code in codes:
                full_name = CF_CATEGORY_NAMES.get(code, code)
                cf_options_flat.append(full_name)
        NON_CF_PLACEHOLDER = "非涉现科目禁止填写"

        for i in range(n_rows):
            side_key = f"{self.key_prefix}_side_{i}"
            cat_key = f"{self.key_prefix}_cat_{i}"
            acct_key = f"{self.key_prefix}_acct_{i}"
            amt_key = f"{self.key_prefix}_amt_{i}"
            cf_key = f"{self.key_prefix}_cf_{i}"
            aux1_key = f"{self.key_prefix}_aux1_{i}"
            aux2_key = f"{self.key_prefix}_aux2_{i}"
            aux3_key = f"{self.key_prefix}_aux3_{i}"

            # 初始化默认 side: 第0行=借, 第1行=贷, 后续=借
            if side_key not in st.session_state:
                st.session_state[side_key] = 'debit' if i == 0 else 'credit'

            cols = st.columns([1, 1.5, 2.5, 2, 1.2, 1.2, 1.2, 1.2, 0.4])

            with cols[0]:
                side = st.selectbox(
                    "方向", ['debit', 'credit'],
                    format_func=lambda x: '借' if x == 'debit' else '贷',
                    key=side_key,
                    label_visibility="collapsed" if i > 0 else "visible",
                )

            with cols[1]:
                cat = st.selectbox(
                    "科目类别",
                    list(self.account_groups.keys()),
                    key=cat_key,
                    label_visibility="collapsed" if i > 0 else "visible",
                )

            with cols[2]:
                codes = self.account_groups.get(cat, [])
                options = self._build_account_options(codes)
                acct = st.selectbox(
                    "科目",
                    options,
                    key=acct_key,
                    label_visibility="collapsed" if i > 0 else "visible",
                )

            with cols[3]:
                # 涉现对应现金流: 取当前选择的科目编码判断
                selected_acct = st.session_state.get(acct_key, options[0] if options else "")
                selected_code = selected_acct.split()[0] if selected_acct else ""
                is_cash = selected_code in ('1001', '1002')
                if is_cash:
                    cf_val = st.selectbox(
                        "涉现对应现金流",
                        cf_options_flat,
                        key=cf_key,
                        index=cf_options_flat.index(st.session_state.get(cf_key, cf_options_flat[0]))
                        if st.session_state.get(cf_key, '') in cf_options_flat else 0,
                        label_visibility="collapsed" if i > 0 else "visible",
                    )
                else:
                    # 非涉现: 禁用控件
                    if cf_key in st.session_state:
                        del st.session_state[cf_key]
                    st.text_input(
                        "涉现对应现金流",
                        value=NON_CF_PLACEHOLDER,
                        disabled=True,
                        key=f"{cf_key}_disabled",
                        label_visibility="collapsed" if i > 0 else "visible",
                    )
                    cf_val = ""

            with cols[4]:
                amt = st.number_input(
                    "金额", min_value=0.0, format="%.2f",
                    key=amt_key,
                    label_visibility="collapsed" if i > 0 else "visible",
                )

            with cols[5]:
                aux1 = st.text_input(
                    "辅助段1", key=aux1_key,
                    label_visibility="collapsed" if i > 0 else "visible",
                )

            with cols[6]:
                aux2 = st.text_input(
                    "辅助段2", key=aux2_key,
                    label_visibility="collapsed" if i > 0 else "visible",
                )

            with cols[7]:
                aux3 = st.text_input(
                    "辅助段3", key=aux3_key,
                    label_visibility="collapsed" if i > 0 else "visible",
                )

            with cols[8]:
                # 删除行按钮
                if n_rows > 2 and i >= 0:
                    if st.button("✕", key=f"{self.key_prefix}_del_{i}",
                                 help="删除此行", use_container_width=True):
                        st.session_state[f"{self.key_prefix}_row_count"] = max(2, n_rows - 1)
                        st.rerun()

            lines_config.append({
                'side': side,
                'cat': cat,
                'acct': acct,
                'amt': amt,
                'cf': cf_val,
                'aux1': aux1,
                'aux2': aux2,
                'aux3': aux3,
                'index': i,
            })

        # 操作按钮: 添加行 / 删除最后行
        col_add, col_del = st.columns([1, 5])
        with col_add:
            if st.button("➕ 添加一行", key=f"{self.key_prefix}_add_row",
                         use_container_width=True):
                st.session_state[row_count_key] = n_rows + 1
                st.rerun()
        with col_del:
            if n_rows > 2 and st.button("➖ 移除最后一行",
                                         key=f"{self.key_prefix}_remove_row",
                                         use_container_width=True):
                st.session_state[row_count_key] = max(2, n_rows - 1)
                st.rerun()

        st.markdown("---")

        # ===== 保存按钮 =====
        if st.button("💾 保存分录", type="primary", use_container_width=True):
            try:
                # 从 lines_config 提取有效行
                entry = JournalEntry(
                    description=desc or f"调整 #{self.manager._next_id}",
                    date_str=str(adj_date),
                    company=selected_company,
                    context=self.context_name,
                    adjust_type=adj_type,
                )

                for cfg in lines_config:
                    if not cfg['acct'] or cfg['amt'] <= 0:
                        continue
                    code = cfg['acct'].split()[0]
                    name = cfg['acct'].split(' ', 1)[1] if ' ' in cfg['acct'] else cfg['acct']
                    entry.add_line(cfg['side'], code, name, cfg['amt'],
                                   cf_category=cfg.get('cf', ''),
                                   aux1=cfg.get('aux1', ''),
                                   aux2=cfg.get('aux2', ''),
                                   aux3=cfg.get('aux3', ''))

                # 校验
                valid, msg = entry.validate()
                if not valid:
                    st.error(f"❌ {msg}")
                else:
                    # 生成联动调整（已从每行 cf_category 读取）
                    entry.auto_adjustments = entry.generate_linking_adjustments(
                        linking_rules=linking_rules,
                    )

                    # 保存
                    self.manager.add(entry)

                    # 显示联动信息
                    st.success(f"✅ 已保存分录 #{entry.id}")
                    if entry.auto_adjustments:
                        for aa in entry.auto_adjustments:
                            st.info(f"🔄 自动联动: {aa.get('reason', '')}")

                    if on_save_callback:
                        on_save_callback()

                    st.rerun()

            except Exception as e:
                st.error(f"❌ 保存失败: {e}")

    # ======================================================================
    # 渲染: 已有分录列表
    # ======================================================================

    def render_entry_list(self, company: str = ""):
        """渲染已有分录列表"""
        entries = self.manager.filter(company=company)

        if not entries:
            st.info("暂无调整分录")
            return

        st.markdown(f"**{len(entries)}** 条分录")

        for idx, entry in enumerate(reversed(entries)):
            with st.expander(
                f"#{entry.id} {entry.description} — {entry.date}",
                expanded=(idx == 0),
            ):
                # 分录行
                st.markdown(entry.display_lines_html(), unsafe_allow_html=True)

                # 编辑按钮 → 弹出编辑表单
                edit_key = f"{self.key_prefix}_edit_{entry.id}"
                if st.button("✏️ 编辑", key=edit_key):
                    st.session_state[f"{edit_key}_active"] = True

                if st.session_state.get(f"{edit_key}_active", False):
                    self._render_edit_form(entry)

                # 删除按钮
                col_del, col_clear = st.columns([1, 5])
                with col_del:
                    if st.button("🗑 删除", key=f"{self.key_prefix}_del_{entry.id}"):
                        self.manager.delete(entry.id)
                        if hasattr(st, 'rerun'):
                            st.rerun()

        # 清空所有
        if st.button("🗑 清空所有分录", key=f"{self.key_prefix}_clear_all"):
            self.manager.clear()
            if hasattr(st, 'rerun'):
                st.rerun()

    def _render_edit_form(self, entry: JournalEntry):
        """渲染编辑分录表单"""
        st.markdown("---")
        st.markdown(f"**编辑分录 #{entry.id}**")

        new_desc = st.text_input(
            "调整说明",
            value=entry.description,
            key=f"{self.key_prefix}_edit_desc_{entry.id}",
        )

        # 编辑行: 简单重建 (复用 lines)
        st.caption("修改行内容 (暂不支持增删行, 全量重写)")
        new_lines = []
        for i, line in enumerate(entry.lines):
            cols = st.columns([1, 1.5, 2.5, 2, 1.2, 1.2, 1.2, 1.2])
            with cols[0]:
                side = st.selectbox(
                    "方向", ['debit', 'credit'],
                    index=0 if line.side == 'debit' else 1,
                    key=f"{self.key_prefix}_edit_side_{entry.id}_{i}",
                    format_func=lambda x: '借' if x == 'debit' else '贷',
                    label_visibility="collapsed",
                )
            with cols[1]:
                cat = st.selectbox(
                    "科目类别",
                    list(self.account_groups.keys()),
                    key=f"{self.key_prefix}_edit_cat_{entry.id}_{i}",
                    label_visibility="collapsed",
                )
            with cols[2]:
                codes = self.account_groups.get(cat, [])
                options = self._build_account_options(codes)
                current = f"{line.code} {line.name}"
                default_idx = 0
                try:
                    default_idx = options.index(current)
                except ValueError:
                    default_idx = 0
                acct = st.selectbox(
                    "科目",
                    options,
                    index=default_idx if current in options else 0,
                    key=f"{self.key_prefix}_edit_acct_{entry.id}_{i}",
                    label_visibility="collapsed",
                )
            with cols[3]:
                cf_val = st.text_input(
                    "涉现",
                    value=line.cf_category or "",
                    key=f"{self.key_prefix}_edit_cf_{entry.id}_{i}",
                    label_visibility="collapsed",
                )
            with cols[4]:
                amt = st.number_input(
                    "金额",
                    value=float(line.amount),
                    format="%.2f",
                    key=f"{self.key_prefix}_edit_amt_{entry.id}_{i}",
                    label_visibility="collapsed",
                )
            with cols[5]:
                aux1 = st.text_input(
                    "辅助段1", value=line.aux1 or "",
                    key=f"{self.key_prefix}_edit_aux1_{entry.id}_{i}",
                    label_visibility="collapsed",
                )
            with cols[6]:
                aux2 = st.text_input(
                    "辅助段2", value=line.aux2 or "",
                    key=f"{self.key_prefix}_edit_aux2_{entry.id}_{i}",
                    label_visibility="collapsed",
                )
            with cols[7]:
                aux3 = st.text_input(
                    "辅助段3", value=line.aux3 or "",
                    key=f"{self.key_prefix}_edit_aux3_{entry.id}_{i}",
                    label_visibility="collapsed",
                )
            new_lines.append({'side': side, 'acct': acct, 'amt': amt, 'cf': cf_val,
                              'aux1': aux1, 'aux2': aux2, 'aux3': aux3})

        col_save, col_cancel = st.columns(2)
        with col_save:
            if st.button("💾 保存修改", key=f"{self.key_prefix}_edit_save_{entry.id}"):
                try:
                    new_entry = JournalEntry(
                        description=new_desc,
                        date_str=entry.date,
                        company=entry.company,
                        context=self.context_name,
                    )
                    for nl in new_lines:
                        code = nl['acct'].split()[0]
                        name = nl['acct'].split(' ', 1)[1] if ' ' in nl['acct'] else nl['acct']
                        new_entry.add_line(nl['side'], code, name, nl['amt'],
                                           cf_category=nl.get('cf', ''),
                                           aux1=nl.get('aux1', ''),
                                           aux2=nl.get('aux2', ''),
                                           aux3=nl.get('aux3', ''))

                    valid, msg = new_entry.validate()
                    if not valid:
                        st.error(f"❌ {msg}")
                    else:
                        self.manager.update(entry.id, new_entry)
                        st.session_state[f"{self.key_prefix}_edit_{entry.id}_active"] = False
                        st.success("✅ 已更新")
                        if hasattr(st, 'rerun'):
                            st.rerun()
                except Exception as e:
                    st.error(f"❌ 保存失败: {e}")
        with col_cancel:
            if st.button("取消", key=f"{self.key_prefix}_edit_cancel_{entry.id}"):
                st.session_state[f"{self.key_prefix}_edit_{entry.id}_active"] = False
                if hasattr(st, 'rerun'):
                    st.rerun()

        st.markdown("---")

    # ======================================================================
    # 渲染: 科目影响汇总
    # ======================================================================

    def render_impact_preview(self, company: str = ""):
        """渲染分录的科目影响汇总"""
        entries = self.manager.filter(company=company)

        if not entries:
            st.info("暂无分录，无法预览")
            return

        impact = self.manager.get_impact_summary()
        if not impact:
            st.info("无有效数据")
            return

        st.markdown("**科目影响汇总**")
        rows = []
        for code, info in sorted(impact.items()):
            if abs(info['net']) > 0.01:
                rows.append({
                    '科目': f"{code} {info['name']}",
                    '借方合计': info['debit_total'],
                    '贷方合计': info['credit_total'],
                    '净额': info['net'],
                    '次数': info['count'],
                })

        if rows:
            st.dataframe(
                pd.DataFrame(rows),
                use_container_width=True,
                hide_index=True,
                column_config={
                    "科目": st.column_config.TextColumn("科目", width="large"),
                    "借方合计": st.column_config.NumberColumn("借方合计", format="¥%.2f"),
                    "贷方合计": st.column_config.NumberColumn("贷方合计", format="¥%.2f"),
                    "净额": st.column_config.NumberColumn("净额", format="¥%.2f"),
                    "次数": st.column_config.NumberColumn("次数", format="%d"),
                }
            )
        else:
            st.info("所有科目净额为零")

    # ======================================================================
    # 统计指标
    # ======================================================================

    def get_stats(self, company: str = "") -> Dict:
        """获取统计指标"""
        entries = self.manager.filter(company=company)
        total_lines = sum(len(e.lines) for e in entries)
        total_auto = sum(len(e.auto_adjustments) for e in entries)
        total_debit = sum(e.debit_total for e in entries)
        total_credit = sum(e.credit_total for e in entries)
        return {
            '分录数': len(entries),
            '行数': total_lines,
            '联动数': total_auto,
            '借方合计': round(total_debit, 2),
            '贷方合计': round(total_credit, 2),
        }
