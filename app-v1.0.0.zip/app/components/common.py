"""共享 UI 组件 — header, metric_card, step_indicator, render_sidebar"""
import streamlit as st
import pandas as pd
from typing import Dict, List, Optional
from app.utils.session import get_state, set_state, auto_save, STANDARD_LABELS


# ──────────────────────────────────────────────
# 全局 CSS：表头居中 + 粘性列
# ──────────────────────────────────────────────
_PREVIEW_CSS_INJECTED = False


def inject_preview_css():
    """注入报表预览所需的全局面样式"""
    global _PREVIEW_CSS_INJECTED
    if _PREVIEW_CSS_INJECTED:
        return
    _PREVIEW_CSS_INJECTED = True
    st.markdown("""
<style>
/* 表头居中 */
thead tr th {
    text-align: center !important;
}
thead tr th p {
    text-align: center !important;
}
/* 单元格内容居中 */
tbody tr td {
    text-align: center !important;
}
/* 金额列右对齐 */
td.amount-col, th.amount-col {
    text-align: right !important;
}
/* 集团/公司名自适应 */
.wrap-cell {
    white-space: normal !important;
    word-wrap: break-word !important;
    font-size: 0.85em !important;
    line-height: 1.2 !important;
    max-width: 120px !important;
}
/* 粘性列 */
.sticky-col {
    position: sticky !important;
    background-color: white !important;
    z-index: 1 !important;
}
.sticky-col-left {
    left: 0 !important;
}
.sticky-col-left-2 {
    left: 100px !important;
}
</style>
""", unsafe_allow_html=True)


def _fmt_amt(v) -> str:
    """千分位金额，不加货币符号"""
    if v is None or abs(v) < 0.005:
        return "—"
    return f"{v:,.2f}"


def render_df(
    df: pd.DataFrame,
    locked_cols: int = 0,
    column_config: Optional[Dict] = None,
    use_container_width: bool = True,
    hide_index: bool = True,
    height: Optional[int] = None,
):
    """增强版 dataframe：粘性列 + 居中表头 + 千分位金额
    
    Args:
        df: 数据
        locked_cols: 锁定前 N 列（水平滚动时不滚动）
        column_config: 同 streamlit column_config
        use_container_width: 自动宽度
        hide_index: 隐藏行号
        height: 表格高度
    """
    inject_preview_css()
    
    kwargs = dict(
        column_config=column_config or {},
        use_container_width=use_container_width,
        hide_index=hide_index,
    )
    if height is not None:
        kwargs['height'] = height
    
    # 如果有粘性列要求，用 data_editor
    if locked_cols > 0:
        col_list = list(df.columns)
        locked_names = col_list[:locked_cols]
        kwargs['disabled'] = locked_names
        st.data_editor(df, **kwargs)
    else:
        st.dataframe(df, **kwargs)


def header(title: str, subtitle: str = ""):
    """页面标题 + 说明"""
    st.markdown(f"# {title}")
    if subtitle:
        st.caption(subtitle)
    st.divider()


def metric_card(label: str, value, delta=None, help_text: str = ""):
    """紧凑型指标卡片"""
    st.metric(label=label, value=value, delta=delta, help=help_text)


def step_indicator(current_step: int, total_steps: int = 8):
    """步骤指示器"""
    cols = st.columns(total_steps)
    for i in range(total_steps):
        with cols[i]:
            done = i < current_step - 1
            active = i == current_step - 1
            icon = "✅" if done else ("🟦" if active else "⬜")
            st.markdown(f"{icon} **{i+1}**")
    st.caption(f"Step {current_step} of {total_steps}")


def status_tag(label: str, is_ok: bool):
    """状态标签"""
    icon = "✅" if is_ok else "❌"
    st.markdown(f"{icon} {label}")


def render_sidebar():
    """渲染全局侧边栏（工作流状态 + 项目信息）

    所有页面（app.py + pages/*.py）都应调用此函数，
    确保子页面侧边栏不消失 + 刷新后自动恢复数据。
    """
    # 刷新恢复：init_session 会自动从 SQLite 加载数据
    from app.utils.session import init_session
    init_session()
    st.sidebar.markdown(f"""
# 📊 合并报表系统
**{st.session_state.get('project_name', '未命名项目')}**
""")

    # 项目信息（项目名下方）
    equity_config = st.session_state.get('equity_config')
    if equity_config and isinstance(equity_config, list) and len(equity_config) > 0:
        # 找母公司（其母公司为空/None的）
        parents = [row for row in equity_config if not row.get('其母公司')]
        if len(parents) == 1:
            parent_name = parents[0].get('公司', '')
            # 需要合并的数量 = 有母公司的子公司（剔除母公司自身）
            subsidiaries = [row for row in equity_config if row.get('其母公司')]
            st.sidebar.caption(f"🏢 母公司: **{parent_name}**")
            st.sidebar.caption(f"📊 合并范围: **{len(subsidiaries)}** 家单体")

    st.sidebar.divider()

    # 返回项目列表（放在导航上方，独立按钮）
    if st.sidebar.button("🏠 项目列表", use_container_width=True, type="secondary"):
        # 清空当前项目，否则 app.py 加载后直接进项目内容
        st.session_state.pop('active_project_id', None)
        st.session_state['_db_restored'] = False
        st.query_params.clear()  # URL 参数也清掉
        st.switch_page("app.py")

    st.sidebar.markdown("#### 📌 页面导航")
    nav_pages = [
        ("📥 导入数据", "pages/01_import_data.py"),
        ("🔗 股权架构", "pages/03_equity_structure.py"),
        ("✅ 单体勾稽", "pages/02_data_validation.py"),
        ("📋 报表调整", "pages/02z_report_adjustment.py"),   # 已涵盖单体调整 + 合并抵消
        # ("📝 单体调整", "pages/04_individual_adjustment.py"),
        # ("🔄 合并抵消", "pages/05_consolidation_offset.py"),
        # ("💱 外币折算", "pages/06_foreign_currency.py"),
        # ("📊 合并导出", "pages/07_report_export.py"),
    ]
    for label, path in nav_pages:
        st.sidebar.page_link(path, label=label, use_container_width=True)

    st.sidebar.divider()

    # 会计准则信息
    std_id = st.session_state.get('selected_standard', 'cas')
    std_label = STANDARD_LABELS.get(std_id, std_id.upper())
    st.sidebar.info(f"🏛️ **准则**: {std_label}")

    # 报告期间 + 币种
    period_label = st.session_state.get('period_label')
    if period_label:
        st.sidebar.caption(f"📅 {period_label}")

    report_ccy = st.session_state.get('report_currency')
    if report_ccy:
        from core.forex import MAJOR_CURRENCIES
        ccy_label = MAJOR_CURRENCIES.get(report_ccy, report_ccy)
        if report_ccy == 'CNY':
            st.sidebar.caption(f"💰 {ccy_label}")
        else:
            st.sidebar.caption(f"💰 {ccy_label} — ⚠️需折算")

    st.sidebar.divider()

    # 工作流进度
    st.sidebar.markdown("#### 📋 工作流状态")
    step_status = st.session_state.get('step_status', {})
    steps = [
        "1. 导入数据",
        "2. 股权架构",
        "3. 单体勾稽",
        "4. 报表调整",
        "5. 外币折算",
    ]
    step_keys = ['1', '2', '3', '4', '5']
    step_flags = {
        '1': st.session_state.get('imported_files'),
        '2': st.session_state.get('equity_config'),
        '3': st.session_state.get('validation_results'),
        '4': st.session_state.get('单体调整') or st.session_state.get('合并抵消分录'),
        '5': st.session_state.get('translated_records') or st.session_state.get('translation_results'),
    }

    for i, (label, sk) in enumerate(zip(steps, step_keys)):
        flag = step_flags.get(sk)
        status = step_status.get(sk, '')
        if flag:
            st.sidebar.markdown(f"✅ {label}")
        elif status == 'in_progress':
            st.sidebar.markdown(f"🔄 {label}")
        else:
            st.sidebar.markdown(f"⬜ {label}")
