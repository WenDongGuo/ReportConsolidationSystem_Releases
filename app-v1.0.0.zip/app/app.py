"""
ReportConsolidationSystem — Streamlit Web UI 入口

功能:
- 项目选择器 (新建/切换/删除)
- 自动保存/恢复工作进度
- 8步工作流导航
"""
import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import streamlit as st

st.set_page_config(
    page_title="合并报表系统",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

from app.utils.session import init_session, get_state, set_state, STANDARD_LABELS
from app.components.common import header, metric_card, step_indicator, render_sidebar
from core.store import (
    list_projects, create_project, delete_project, rename_project,
    save_full_state, load_full_state, save_records, save_equity,
    save_adjustments, save_settings,
)

# 初始化 session
init_session()

# ========== 项目选择器（无项目时全屏显示） ==========
active_project = st.session_state.get('active_project_id')

if not active_project:
    # ==========================================
    # 全屏项目选择界面
    # ==========================================
    st.markdown("""
    <div style="text-align:center; padding:40px 0;">
        <h1>📊 合并报表系统</h1>
        <p style="color:#888;">企业财务报表合并工具</p>
    </div>
    """, unsafe_allow_html=True)

    projects = list_projects()

    # 已有项目
    if projects:
        st.markdown("### 📂 打开已有项目")
        cols = st.columns(min(len(projects), 3))
        for idx, p in enumerate(projects):
            col = cols[idx % 3]
            with col:
                # 时间格式化
                updated = p.get('updated_at', '')[:16] if p.get('updated_at') else ''
                step = p.get('current_step', 1)
                status = p.get('step_status', '{}')

                with st.container(border=True):
                    st.markdown(f"**{p['name']}**")
                    st.caption(f"📅 {updated}  |  Step {step}/8")
                    if p.get('description'):
                        st.caption(p['description'])

                    col_a, col_b = st.columns(2)
                    with col_a:
                        if st.button("▶ 打开", key=f"open_{p['id']}", use_container_width=True):
                            state = load_full_state(p['id'])
                            if state:
                                # 还原所有 session state
                                for key, val in state.items():
                                    st.session_state[key] = val
                                st.session_state['active_project_id'] = p['id']
                                st.query_params['project_id'] = str(p['id'])
                                st.rerun()
                    with col_b:
                        if st.button("🗑", key=f"del_{p['id']}", help="删除项目"):
                            delete_project(p['id'])
                            st.rerun()

        st.divider()

    # 新建项目
    st.markdown("### ✨ 新建项目")
    col1, col2 = st.columns([2, 1])
    with col1:
        new_name = st.text_input("项目名称", placeholder="如: XXX集团2025Q1合并",
                                 label_visibility="collapsed")
    with col2:
        new_desc = st.text_input("备注（可选）", placeholder="描述",
                                  label_visibility="collapsed")

    if st.button("🚀 创建并进入", type="primary", use_container_width=True) and new_name:
        pid = create_project(new_name.strip(), new_desc.strip())
        if pid:
            st.session_state['active_project_id'] = pid
            st.session_state['project_name'] = new_name.strip()
            st.session_state['current_step'] = 1
            st.session_state['step_status'] = {}
            st.query_params['project_id'] = str(pid)
            # 保存默认设置
            save_settings(pid, {
                'selected_standard': 'cas',
                'report_currency': 'CNY',
            })
            st.rerun()

    st.stop()  # 没选项目时不再渲染下面的内容


# ==========================================
# 正常项目页面（已有活跃项目）
# ==========================================

# ---- 侧边栏（共享组件） ----
render_sidebar()

# 创建/打开项目后直接进入导入数据页面
st.switch_page("pages/01_import_data.py")
