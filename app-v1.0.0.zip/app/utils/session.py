"""
Session State 管理 — 系统的全局状态

自动双向同步到 SQLite 关系表：
  - auto_save(): 每次写操作后自动保存到新关系表
  - restore_from_db(): 刷新后从 SQLite 恢复所有状态（刷新不丢失！）
"""
import streamlit as st
from typing import Dict, List, Optional

# 会计准则显示名
STANDARD_LABELS = {
    "cas": "中国企业会计准则 (CAS)",
    "ifrs": "国际财务报告准则 (IFRS)",
    "us_gaap": "美国公认会计原则 (US GAAP)",
}


# ===================================================================
# 初始化和恢复
# ===================================================================

def init_session():
    """初始化或保持 session state"""
    # 确保数据库初始化
    try:
        from core.store import init_db
        init_db()
    except ImportError:
        pass

    defaults = {
        # 会计准则 + 期间 + 币种
        'selected_standard': 'cas',
        'import_standard': None,
        'period_start': None,
        'period_end': None,
        'period_label': None,
        'report_currency': 'CNY',

        # 导入数据
        'imported_files': [],
        'imported_companies': {},
        'all_records': [],
        'all_checks': [],

        # 股权结构
        'equity_config': None,
        'equity_tree': {},

        # 合并状态
        'adjustments': [],
        'consolidation_result': None,
        'consolidation_raw': None,
        'report_data': None,

        # 外币折算
        'company_currencies': None,
        'period_rates_cache': {},
        'translation_results': {},
        'translated_records': None,

        # 输出
        'export_path': None,
        'export_xlsx': None,

        # 刷新恢复标记
        '_db_restored': False,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val

    # 【关键修复】刷新后从 URL 参数恢复 project_id
    qp = st.query_params
    if 'project_id' in qp and not st.session_state.get('active_project_id'):
        try:
            pid = int(qp['project_id'])
            st.session_state['active_project_id'] = pid
            # 从 SQLite 取项目名
            from core.store import list_projects
            for p in list_projects():
                if p['id'] == pid:
                    st.session_state['project_name'] = p['name']
                    break
        except (ValueError, TypeError):
            pass

    pid = st.session_state.get('active_project_id')
    if pid:
        # 【关键】始终同步到 URL，page_link 跳转不携带 query_params
        st.query_params['project_id'] = str(pid)
        if not st.session_state.get('_db_restored'):
            _do_restore(pid)
    else:
        # 没选项目时清除 URL 参数
        if 'project_id' in st.query_params:
            del st.query_params['project_id']


def restore_from_db(project_id: int):
    """手动触发从 SQLite 恢复（页面加载时调用）"""
    _do_restore(project_id)


def _do_restore(project_id: int):
    """从 SQLite 加载完整状态到 session state"""
    try:
        from core.store import load_full_state
        # 先检查是否有数据（通过 imported_records 数量判断）
        from core.store import get_db
        conn = get_db()
        try:
            cnt = conn.execute(
                "SELECT COUNT(*) AS c FROM imported_records WHERE project_id=?",
                (project_id,)
            ).fetchone()['c']
        finally:
            conn.close()

        if cnt == 0:
            # 这个项目没有导入数据，暂不恢复
            return

        state = load_full_state(project_id)
        if not state:
            return

        # 恢复基础设置
        st.session_state['selected_standard'] = state.get('selected_standard', 'cas')
        st.session_state['period_start'] = state.get('period_start')
        st.session_state['period_end'] = state.get('period_end')
        st.session_state['period_label'] = state.get('period_label')
        st.session_state['report_currency'] = state.get('report_currency', 'CNY')
        st.session_state['current_step'] = state.get('current_step', 1)
        st.session_state['project_name'] = state.get('project_name', '未命名项目')

        # 恢复导入数据
        st.session_state['all_records'] = state.get('all_records', [])
        st.session_state['all_checks'] = state.get('all_checks', [])
        st.session_state['_import_results'] = state.get('_import_results', [])

        # 恢复股权
        st.session_state['equity_config'] = state.get('equity_config', [])

        # 恢复分录
        st.session_state['单体调整'] = state.get('单体调整')
        st.session_state['合并抵消分录'] = state.get('合并抵消分录')

        # 恢复合并结果
        st.session_state['report_data'] = state.get('report_data')

        # 恢复辅助数据
        for extra_key in ['validation_results', 'user_inputs_16', 'company_currencies',
                          'period_rates_cache', 'translation_results', 'translated_records',
                          'pre_consolidated_data', 'consolidation_result', 'consolidation_raw',
                          'export_xlsx', 'export_json', 'export_path', 'unmatched_subjects',
                          'imported_files']:
            val = state.get(extra_key)
            if val is not None:
                st.session_state[extra_key] = val

        st.session_state['_db_restored'] = True
        # 确保 URL 参数中有 project_id（后续刷新时用）
        st.query_params['project_id'] = str(project_id)
    except Exception as e:
        print(f"[session] restore error: {e}")


# ===================================================================
# 读写帮助
# ===================================================================

def get_state(key: str, default=None):
    """安全获取状态值"""
    return st.session_state.get(key, default)


def set_state(key: str, value):
    """设置状态值"""
    st.session_state[key] = value


def append_state(key: str, item):
    """追加到列表状态"""
    if key not in st.session_state:
        st.session_state[key] = []
    st.session_state[key].append(item)


# ===================================================================
# 自动保存（双向同步到 SQLite）
# ===================================================================

def auto_save():
    """自动保存当前项目状态到 SQLite 关系表"""
    try:
        from core.store import save_full_state
    except ImportError:
        return

    pid = st.session_state.get('active_project_id')
    if not pid:
        return

    step_status = st.session_state.get('step_status', {})

    # 同步单体调整和合并抵消分录到新的 store
    # JournalManager 对象需要转为 dict 列表
    monotherapy = st.session_state.get('单体调整', {})
    cons_entries = st.session_state.get('合并抵消分录', {})

    # 构造兼容 save_full_state 的 state dict
    save_full_state(pid, {
        'settings': {
            'selected_standard': st.session_state.get('selected_standard', 'cas'),
            'period_start': st.session_state.get('period_start'),
            'period_end': st.session_state.get('period_end'),
            'period_label': st.session_state.get('period_label'),
            'report_currency': st.session_state.get('report_currency', 'CNY'),
        },
        'all_records': st.session_state.get('all_records', []),
        'all_checks': st.session_state.get('all_checks', []),
        'imported_files': st.session_state.get('imported_files', []),
        '_import_results': st.session_state.get('_import_results', []),
        'equity_config': st.session_state.get('equity_config', []),
        'adjustments': st.session_state.get('adjustments', []),
        '单体调整': monotherapy,
        '合并抵消分录': cons_entries,
        'translated_records': st.session_state.get('translated_records'),
        'user_inputs_16': st.session_state.get('user_inputs_16', {}),
        'validation_results': st.session_state.get('validation_results', {}),
        'company_currencies': st.session_state.get('company_currencies'),
        'period_rates_cache': st.session_state.get('period_rates_cache'),
        'translation_results': st.session_state.get('translation_results'),
        'pre_consolidated_data': st.session_state.get('pre_consolidated_data'),
        'consolidation_result': st.session_state.get('consolidation_result'),
        'consolidation_raw': st.session_state.get('consolidation_raw'),
        'export_xlsx': st.session_state.get('export_xlsx'),
        'export_json': st.session_state.get('export_json'),
        'export_path': st.session_state.get('export_path'),
        'unmatched_subjects': st.session_state.get('unmatched_subjects'),
        'current_step': st.session_state.get('current_step', 1),
        'step_status': step_status,
        'report_data': st.session_state.get('report_data'),
    })
