"""
📥 导入数据 — 选会计准则 → 上传 Excel → 自动识别 → 预览 → 自动校验
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import streamlit as st
import json
import yaml
import pandas as pd
from pathlib import Path
from datetime import date, timedelta

st.set_page_config(page_title="导入数据", page_icon="📥", layout="wide")

from app.components.common import header, metric_card, render_sidebar
from app.utils.session import get_state, set_state, append_state

PROJECT_DIR = os.path.join(os.path.dirname(__file__), '..', '..')
CONFIG_DIR = os.path.join(PROJECT_DIR, 'config')
MAPPINGS_DIR = os.path.join(CONFIG_DIR, 'mappings')
STANDARDS_DIR = os.path.join(CONFIG_DIR, 'standards')
SAMPLE_DIR = os.path.join(PROJECT_DIR, 'sample_data')
OUTPUT_DIR = os.path.join(PROJECT_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

header("📥 导入数据", "选准则 → 设期间 → 选币种 → 导入 → 自动校验")
render_sidebar()

from core.standards import StandardsManager
std_mgr = StandardsManager(STANDARDS_DIR)
available_standards = std_mgr.list_standards()

STANDARD_INFO = {
    "cas": {
        "label": "中国企业会计准则 (CAS)",
        "desc": "中华人民共和国财政部颁布的企业会计准则体系",
        "icon": "🇨🇳",
        "status": "✅ 可用",
    },
}
future_standards = [
    {"id": "ifrs", "label": "国际财务报告准则 (IFRS)", "icon": "🌐", "status": "✅ 可用（骨架）"},
    {"id": "us_gaap", "label": "美国公认会计原则 (US GAAP)", "icon": "🇺🇸", "status": "⏳ 开发中"},
]


# ===================================================================
# 通用的导入执行函数
# ===================================================================
def run_import(file_paths, label_fn, std_id='cas', forced_format_id=None):
    from core.loader import FormatDetector, ExcelReader
    from core.standards import StandardsManager, SubjectMatcher
    from core.mapper import MappingEngine

    detector = FormatDetector(MAPPINGS_DIR)
    mgr = StandardsManager(STANDARDS_DIR)
    matcher = SubjectMatcher(mgr, std_id=std_id)
    engine = MappingEngine(matcher)

    progress_bar = st.progress(0)
    status_text = st.empty()

    all_records = []
    all_checks = []
    all_unmatched = []
    results = []
    total = len(file_paths)

    from concurrent.futures import ThreadPoolExecutor, as_completed
    import threading
    _lock = threading.Lock()

    def _process_one(fp, fname):
        try:
            if forced_format_id:
                config = detector.get_format(forced_format_id)
                method = "手动指定"
            else:
                config = detector.detect(fp)
                method = "文件名匹配" if detector._detect_by_filename(fp) else                          "内容匹配" if config else "TryAll"
            if not config:
                return {"file": fname, "status": "⚠️ 未识别格式", "reason": "无法匹配已知的 Excel 模板格式", "records": 0}

            thread_reader = ExcelReader(config)
            thread_mgr = StandardsManager(STANDARDS_DIR)
            thread_matcher = SubjectMatcher(thread_mgr, std_id=std_id)
            thread_engine = MappingEngine(thread_matcher)

            raw = thread_reader.read_workbook(fp)
            company = raw.get('company_name', '未知')
            has_bs = 'balance_sheet' in raw
            has_is = 'income_statement' in raw
            has_cf = 'cash_flow_statement' in raw

            if has_bs or has_is or has_cf:
                result = thread_engine.transform(raw)
                unmatched = getattr(thread_engine, '_unmatched_names', [])
                val = result.get_validation_summary()
                fail_count = val['未通过']
                fail_details = ""
                if fail_count > 0:
                    failed_rules = [c.get('name', '?') for c in result.total_checks if not c.get('passed', True)]
                    fail_details = f"校验未通过: {', '.join(failed_rules[:3])}" + (f"...共{fail_count}条" if fail_count > 3 else "")
                return {
                    "file": fname, "company": company,
                    "records": len(result.records),
                    "checks": val['合计校验总数'], "passed": val['通过'],
                    "status": "✅" if fail_count == 0 else "⚠️",
                    "reason": fail_details,
                    "检测方式": method,
                    "_engine_records": result.records,
                    "_engine_checks": result.total_checks,
                    "_unmatched_names": unmatched,
                }
            else:
                return {"file": fname, "company": company, "status": "⚠️ 无可用报表", "reason": "文件中未检测到资产负债表、利润表或现金流量表", "records": 0}
        except Exception as e:
            return {"file": fname, "status": f"❌ {str(e)[:80]}", "reason": str(e)[:120], "records": 0}

    BATCH_SIZE = min(4, max(1, total))
    batches = [file_paths[i:i+BATCH_SIZE] for i in range(0, total, BATCH_SIZE)]
    completed = 0

    for batch_idx, batch in enumerate(batches):
        status_text.text(f"⏳ 处理中... 批次 {batch_idx+1}/{len(batches)} ({completed}/{total})")
        batch_fnames = [label_fn(fp) if callable(label_fn) else fp for fp in batch]
        batch_results = []
        with ThreadPoolExecutor(max_workers=BATCH_SIZE) as executor:
            futures = {executor.submit(_process_one, fp, fname): fname
                       for fp, fname in zip(batch, batch_fnames)}
            for future in as_completed(futures):
                fname = futures[future]
                try:
                    r = future.result()
                    if r is not None:
                        with _lock:
                            batch_results.append(r)
                            completed += 1
                            records = r.pop('_engine_records', [])
                            checks = r.pop('_engine_checks', [])
                            unmatched = r.pop('_unmatched_names', [])
                            all_records.extend(records)
                            all_checks.extend(checks)
                            if unmatched:
                                all_unmatched.extend(unmatched)
                except Exception as e:
                    with _lock:
                        batch_results.append({"file": fname, "status": f"❌ {str(e)[:80]}", "records": 0})
                        completed += 1
        results.extend(batch_results)
        progress_bar.progress(min(completed / total, 1.0))

    status_text.text("✅ 导入完成！")

    # 保存到 session
    set_state('imported_files', [r['file'] for r in results])
    set_state('all_records', all_records)
    set_state('all_checks', all_checks)
    if all_unmatched:
        existing = get_state('unmatched_subjects') or []
        existing.extend(all_unmatched)
        set_state('unmatched_subjects', existing)
    from app.utils.session import auto_save
    auto_save()
    set_state('current_step', 1)

    # ── 保存 JSON ──
    import datetime as dt
    output_path = os.path.join(OUTPUT_DIR, 'imported_data.json')
    output_data = {
        '期间信息': {
            '会计准则': std_id,
            '期初日期': str(get_state('period_start') or ''),
            '期末日期': str(get_state('period_end') or ''),
            '导入时间': dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        },
        '科目记录': all_records,
        '校验记录': all_checks,
    }
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2, default=str)
    set_state('export_path', output_path)
    set_state('import_standard', std_id)

    # 保存导入结果详情到 session 供下方展示
    set_state('_import_results', results)
    # 不 rerun — 自动导入模式下 rerun 会导致死循环
    # 导入结果由 Section 3 直接从 session 读取展示

    return results


# ===================================================================
# Section 1: 基础信息设置（3 卡片 — 同高）
# ===================================================================
st.markdown("""
<style>
.info-card {
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    padding: 20px 16px;
    min-height: 280px;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
}
</style>
""", unsafe_allow_html=True)

st.markdown("### 🏛️ 基础信息设置")
card1, card2, card3 = st.columns(3)

with card1:
    with st.container(border=True, height=280):
        st.markdown("**📘 会计准则**")
        current_std = get_state('selected_standard') or 'cas'

        # 3 横向小卡片
        std_defs = [
            {"id": "cas",  "icon": "🇨🇳", "label": "CAS",  "desc": "中国企业会计准则"},
            {"id": "ifrs", "icon": "🌐", "label": "IFRS", "desc": "国际财务报告准则"},
            {"id": "us_gaap", "icon": "🇺🇸", "label": "GAAP", "desc": "美国公认会计原则"},
        ]
        sc1, sc2, sc3 = st.columns(3)
        for scol, std in zip([sc1, sc2, sc3], std_defs):
            with scol:
                is_active = current_std == std['id']
                btn_type = "primary" if is_active else "secondary"
                if st.button(
                    f"{std['icon']} {std['label']}",
                    key=f"std_{std['id']}",
                    use_container_width=True,
                    type=btn_type,
                    help=std['desc'],
                ):
                    set_state('selected_standard', std['id'])
                    # 切换准则后：清除旧匹配缓存 + 持久化
                    st.session_state.pop('unmatched_subjects', None)
                    st.session_state.pop('_import_results', None)
                    from app.utils.session import auto_save
                    auto_save()
                    st.rerun()

        selected_std = current_std
        accounts = std_mgr.get_accounts_flat(selected_std)
        categories = set(a.get('类别', '') for a in accounts)
        st.caption(f"📊 {len(accounts)} 标准科目 / {len(categories)} 类别")

with card2:
    with st.container(border=True, height=280):
        st.markdown("**📅 报告期间**")
        today = date.today()
        default_end = today.replace(day=1)
        if default_end.month <= 3:
            default_end = default_end.replace(month=12, year=default_end.year - 1)
        else:
            q = (default_end.month - 1) // 3
            default_end = default_end.replace(month=q * 3 + 3, day=1)
        default_end = default_end - timedelta(days=1)
        default_start = default_end.replace(month=1, day=1)

        period_start = st.date_input(
            "期初日期", value=get_state('period_start') or default_start,
            min_value=date(2000, 1, 1), max_value=today, format="YYYY-MM-DD",
        )
        period_end = st.date_input(
            "期末日期", value=get_state('period_end') or default_end,
            min_value=date(2000, 1, 1), max_value=today, format="YYYY-MM-DD",
        )
        if period_start >= period_end:
            st.error("❌ 期初日期必须早于期末日期")
        else:
            days = (period_end - period_start).days
            st.caption(f"⏱ {days} 天 ({(days+1)//30} 个月)")

        set_state('period_start', period_start.isoformat())
        set_state('period_end', period_end.isoformat())
        set_state('period_label', f"{period_start} ~ {period_end}")
        from app.utils.session import auto_save
        auto_save()

with card3:
    with st.container(border=True, height=280):
        st.markdown("**💰 报表币种**")
        from core.forex import MAJOR_CURRENCIES
        ccy_options = list(MAJOR_CURRENCIES.values())
        current_ccy = get_state('report_currency') or 'CNY'
        default_ccy_idx = list(MAJOR_CURRENCIES.keys()).index(current_ccy) if current_ccy in MAJOR_CURRENCIES else 0
        selected_ccy_display = st.selectbox(
            "报表币种", options=ccy_options, index=default_ccy_idx,
            label_visibility="collapsed",
        )
        ccy_keys = list(MAJOR_CURRENCIES.keys())
        ccy_values = list(MAJOR_CURRENCIES.values())
        selected_ccy = ccy_keys[ccy_values.index(selected_ccy_display)]
        if get_state('report_currency') != selected_ccy:
            set_state('report_currency', selected_ccy)
            from app.utils.session import auto_save
            auto_save()

        if selected_ccy == 'CNY':
            st.success("✅ 无需外币折算")
        else:
            st.warning(f"⚠️ 后续需外币折算至 CNY")

st.caption(" | ".join(
    f"{s['icon']} {s['label']}: {s['status']}" for s in future_standards
))

st.divider()

# ===================================================================
# Section 2: 导入报表数据（两个直放 file_uploader）
# ===================================================================
st.markdown("### 📤 导入报表数据")
std_label = STANDARD_INFO.get(selected_std, {}).get('label', selected_std.upper())
st.caption(f"🏛️ {std_label}  |  📅 {period_start} ~ {period_end}  |  💰 {selected_ccy_display}")

st.markdown("##### 📁 单文件导入")
single_files = st.file_uploader(
    "选择一个或多个 Excel 文件（.xlsx / .xls）",
    type=['xlsx', 'xls'], accept_multiple_files=True,
    help="支持单个或多个文件同时上传，选择后自动导入",
    key="single_file_uploader",
)
if single_files:
    current_ids = tuple(uf.file_id for uf in single_files)
    last_ids = get_state('_last_single_ids')
    if current_ids == last_ids and get_state('_import_results'):
        # 已导入过的文件，提供重新导入按钮
        st.info("📌 已导入，如需覆盖可点击下方按钮")
        if st.button("🔄 重新导入", key="reimport_btn", type="primary", use_container_width=True):
            set_state('_last_single_ids', None)  # 清除缓存，允许重导
            st.rerun()
    else:
        set_state('_last_single_ids', current_ids)
        tmp_dir = os.path.join(OUTPUT_DIR, '_tmp_uploads')
        os.makedirs(tmp_dir, exist_ok=True)
        file_paths = []
        for uf in single_files:
            tmp_path = os.path.join(tmp_dir, uf.name)
            with open(tmp_path, 'wb') as f:
                f.write(uf.getbuffer())
            file_paths.append(tmp_path)
        def label_fn(fp):
            return os.path.basename(fp)
        run_import(file_paths, label_fn, std_id=selected_std)
        import shutil
        shutil.rmtree(tmp_dir, ignore_errors=True)

st.divider()

# ===================================================================
# Section 3: 导入结果框
# ===================================================================
import_results = get_state('_import_results')
imported_files = get_state('imported_files')
all_records = get_state('all_records')
all_checks = get_state('all_checks') or []

if import_results and all_records:
    st.markdown("### 📋 导入结果")
    # ...（原有导入结果表格代码保持不变，从下一行stat1开始到清空按钮前）
    
    # 统计卡片
    total_files = len(import_results)
    success = sum(1 for r in import_results if r.get('status', '').startswith('✅'))
    warns = sum(1 for r in import_results if r.get('status', '').startswith('⚠️'))
    fails = total_files - success - warns

    stat1, stat2, stat3, stat4 = st.columns(4)
    with stat1: metric_card("文件总数", total_files)
    with stat2: metric_card("✅ 成功", success)
    with stat3: metric_card("⚠️ 警告/失败", warns + fails)
    with stat4: metric_card("科目总数", sum(r.get('records', 0) for r in import_results))

    # 清晰的结果表格：公司名 | 文件路径 | 记录数 | 状态 | 原因
    table_rows = []
    for r in import_results:
        company = r.get('company', '?')
        fname = r.get('file', '?')
        status_icon = r.get('status', '?')
        records = r.get('records', 0)
        reason = r.get('reason', '')
        is_ok = status_icon.startswith('✅')
        table_rows.append({
            '公司名': company,
            '文件': fname,
            '记录数': records,
            '状态': '✅ 成功' if is_ok else status_icon,
            '原因': '' if is_ok else reason,
            '_公司': company,
        })

    if table_rows:
        st.markdown("#### 📊 导入明细")
        result_df = pd.DataFrame(table_rows)
        selection = st.dataframe(
            result_df[['公司名', '文件', '记录数', '状态', '原因']],
            use_container_width=True, hide_index=True,
            column_config={
                '公司名': st.column_config.TextColumn("公司名", width="medium"),
                '文件': st.column_config.TextColumn("数据源文件", width="large"),
                '记录数': st.column_config.NumberColumn("科目数", width="small"),
                '状态': st.column_config.TextColumn("解析结果", width="small"),
                '原因': st.column_config.TextColumn("原因", width="medium"),
            },
            on_select="rerun",
            selection_mode="multi-row",
        )

        if selection is not None and hasattr(selection, 'selection') and selection.selection:
            selected_rows = selection.selection.get('rows', [])
            if selected_rows:
                if st.button(f"🗑 删除选中的 {len(selected_rows)} 行", type="secondary"):
                    selected_indices = set(selected_rows)
                    new_results = [r for i, r in enumerate(import_results) if i not in selected_indices]
                    removed_companies = set(import_results[i].get('company', '') for i in selected_indices)
                    new_records = [r for r in all_records if r.get('company') not in removed_companies]
                    new_checks = [c for c in all_checks if c.get('公司', '') not in removed_companies]
                    set_state('_import_results', new_results)
                    set_state('all_records', new_records)
                    set_state('all_checks', new_checks)
                    set_state('imported_files', [r['file'] for r in new_results])
                    st.success(f"已删除 {len(selected_rows)} 行数据")
                    st.rerun()

    # ── 合计行校验：原表合计行金额 vs 系统内部计算金额 ──
    check_data = []
    for c in all_checks:
        is_ok = c.get('是否一致', False)
        check_data.append({
            '公司': c.get('公司', ''),
            '报表': c.get('报表', ''),
            '期间': c.get('期间类型', ''),
            '合计项目': c.get('合计项目', ''),
            '原表金额': f"{c.get('报告值', 0):,.2f}",
            '系统计算': f"{c.get('计算值', 0):,.2f}",
            '差异': f"{c.get('差异', 0):,.2f}",
            '结果': '✅ 一致' if is_ok else '❌ 不一致',
        })

    if check_data:
        perf_total = len(check_data)
        perf_pass = sum(1 for c in all_checks if c.get('是否一致', False))
        perf_fail = perf_total - perf_pass

        st.markdown("#### 📐 合计行校验：原表金额 vs 系统计算")
        cols_a, cols_b, cols_c = st.columns(3)
        with cols_a: metric_card("合计行总数", perf_total)
        with cols_b: metric_card("✅ 一致", perf_pass)
        with cols_c: metric_card("❌ 差异", perf_fail)

        st.dataframe(
            pd.DataFrame(check_data),
            use_container_width=True, hide_index=True,
            column_config={
                '公司': st.column_config.TextColumn("公司", width="medium"),
                '报表': st.column_config.TextColumn("报表", width="small"),
                '期间': st.column_config.TextColumn("期间", width="small"),
                '合计项目': st.column_config.TextColumn("合计项目", width="medium"),
                '原表金额': st.column_config.TextColumn("原表金额", width="medium"),
                '系统计算': st.column_config.TextColumn("系统计算", width="medium"),
                '差异': st.column_config.TextColumn("差异", width="medium"),
                '结果': st.column_config.TextColumn("结果", width="small"),
            },
        )

        # 如果有不一致的，高亮警告
        if perf_fail > 0:
            st.warning(f"🚨 {perf_fail} 个合计行金额与原表不一致，请检查数据")

    # ── 交叉校验（R1-R6）折叠 ──
    with st.expander("🔍 交叉校验（资产=负债+权益等）", expanded=False):
        diff_rows = []
        from core.validator import ValidatorEngine
        val_engine = ValidatorEngine(std_mgr)
        _df = pd.DataFrame(all_records)
        companies = sorted(set(r.get('company', '') for r in all_records)) if not _df.empty else []
        for company in companies:
            records = _df[_df['company'] == company].to_dict('records')
            vresult = val_engine.validate(records, company)
            for r in vresult.rules:
                if not r['passed']:
                    diff_rows.append({
                        '公司': company,
                        '规则': f"R{r['id']}",
                        '名称': r['name'],
                        '期望值': r.get('expected', '—'),
                        '实际值': r.get('actual', '—'),
                        '差异': r.get('diff', '—'),
                        '说明': r.get('detail', '')[:120],
                    })
        if diff_rows:
            st.warning(f"🚨 {len(diff_rows)} 条规则未通过，涉及 {len(set(r['公司'] for r in diff_rows))} 家公司")
            st.dataframe(
                pd.DataFrame(diff_rows),
                use_container_width=True, hide_index=True,
                column_config={
                    '公司': st.column_config.TextColumn("公司", width="medium"),
                    '规则': st.column_config.TextColumn("规则", width="small"),
                    '名称': st.column_config.TextColumn("检验名称", width="medium"),
                    '期望值': st.column_config.TextColumn("期望值", width="medium"),
                    '实际值': st.column_config.TextColumn("实际值", width="medium"),
                    '差异': st.column_config.TextColumn("差异", width="medium"),
                    '说明': st.column_config.TextColumn("说明", width="large"),
                },
            )
        else:
            st.success("✅ 全部交叉校验通过")

    st.divider()
    col_del1, col_del2 = st.columns([1, 3])
    with col_del1:
        if st.button("🗑 清空全部数据", type="secondary", use_container_width=True,
                     help="删除所有已导入的数据，不可恢复"):
            for key in ['all_records', 'imported_files', 'all_checks', 'validation_results',
                        'unmatched_subjects', 'validation_passed', 'import_standard',
                        'export_path', 'company_currencies', 'period_rates_cache',
                        'translation_results', '_import_results', '_last_single_ids']:
                st.session_state.pop(key, None)
            from app.utils.session import auto_save
            auto_save()  # 同步清空 SQLite，防止 rerun 后恢复旧数据
            st.success("✅ 已清空全部导入数据")
            st.rerun()

elif all_records and not import_results:
    # 刷新后恢复：已有数据但丢了导入结果明细
    st.info(f"✅ 已导入 {len(all_records)} 条数据（来自 {len(set(r.get('company','') for r in all_records))} 家公司），如需重新导入可上传文件覆盖")

    # ── 合计行校验：原表合计行金额 vs 系统内部计算金额 ──
    if all_checks:
        check_data = []
        for c in all_checks:
            is_ok = c.get('是否一致', False)
            check_data.append({
                '公司': c.get('公司', ''),
                '报表': c.get('报表', ''),
                '合计项目': c.get('合计项目', ''),
                '原表金额': f"{c.get('报告值', 0):,.2f}",
                '系统计算': f"{c.get('计算值', 0):,.2f}",
                '差异': f"{c.get('差异', 0):,.2f}",
                '结果': '✅ 一致' if is_ok else '❌ 不一致',
            })
        perf_total = len(check_data)
        perf_pass = sum(1 for c in all_checks if c.get('是否一致', False))
        perf_fail = perf_total - perf_pass
        st.markdown("#### 📐 合计行校验：原表金额 vs 系统计算")
        cols_a, cols_b, cols_c = st.columns(3)
        with cols_a: metric_card("合计行总数", perf_total)
        with cols_b: metric_card("✅ 一致", perf_pass)
        with cols_c: metric_card("❌ 差异", perf_fail)
        st.dataframe(pd.DataFrame(check_data), use_container_width=True, hide_index=True,
                     column_config={
                         '公司': st.column_config.TextColumn("公司", width="medium"),
                         '报表': st.column_config.TextColumn("报表", width="small"),
                         '合计项目': st.column_config.TextColumn("合计项目", width="medium"),
                         '原表金额': st.column_config.TextColumn("原表金额", width="medium"),
                         '系统计算': st.column_config.TextColumn("系统计算", width="medium"),
                         '差异': st.column_config.TextColumn("差异", width="medium"),
                         '结果': st.column_config.TextColumn("结果", width="small"),
                     })
        if perf_fail > 0:
            st.warning(f"🚨 {perf_fail} 个合计行金额与原表不一致，请检查数据")

    # ── 交叉校验（R1-R6）折叠 ──
    with st.expander("🔍 交叉校验（资产=负债+权益等）", expanded=False):
        diff_rows = []
        from core.validator import ValidatorEngine
        val_engine = ValidatorEngine(std_mgr)
        _df = pd.DataFrame(all_records)
        companies = sorted(set(r.get('company', '') for r in all_records)) if not _df.empty else []
        for company in companies:
            records = _df[_df['company'] == company].to_dict('records')
            vresult = val_engine.validate(records, company)
            for r in vresult.rules:
                if not r['passed']:
                    diff_rows.append({
                        '公司': company,
                        '规则': f"R{r['id']}",
                        '名称': r['name'],
                        '期望值': r.get('expected', '—'),
                        '实际值': r.get('actual', '—'),
                        '差异': r.get('diff', '—'),
                        '说明': r.get('detail', '')[:120],
                    })
        if diff_rows:
            st.warning(f"🚨 {len(diff_rows)} 条规则未通过，涉及 {len(set(r['公司'] for r in diff_rows))} 家公司")
            st.dataframe(pd.DataFrame(diff_rows), use_container_width=True, hide_index=True,
                         column_config={k: st.column_config.TextColumn(k, width="medium" if k in ['公司','说明'] else "small") for k in ['公司','规则','名称','期望值','实际值','差异','说明']})
        else:
            st.success("✅ 全部交叉校验通过")

    st.divider()
    if st.button("🗑 清空全部数据", type="secondary", use_container_width=True):
        for key in ['all_records', 'imported_files', 'all_checks', 'validation_results',
                    'unmatched_subjects', '_import_results', '_last_single_ids']:
            st.session_state.pop(key, None)
        from app.utils.session import auto_save
        auto_save()  # 同步清空 SQLite
        st.rerun()

    st.divider()

# ===================================================================
# Section 4: 未能识别匹配科目映射管理（底部固定）
# ===================================================================
all_unmatched = get_state('unmatched_subjects') or []
if all_unmatched:
    st.markdown("### 🧠 未能识别匹配科目映射管理")
    st.caption(f"共 {len(all_unmatched)} 个科目未匹配到标准科目，可以手动映射并保存为别名")

    seen_names = set()
    unique_unmatched = []
    for u in all_unmatched:
        name = u.get('原始名称', '')
        if name and name not in seen_names:
            seen_names.add(name)
            unique_unmatched.append(u)

    from core.standards import StandardsManager as _SM, SubjectMatcher as _SMatcher
    alias_mgr = _SM(STANDARDS_DIR)
    alias_matcher = _SMatcher(alias_mgr, std_id=selected_std)

    for i, u in enumerate(unique_unmatched):
        suggested = u.get('建议', [])
        with st.container():
            cols = st.columns([3, 2, 3])
            with cols[0]:
                st.text(f"🔤 {u.get('原始名称', '?')}")
                st.caption(f"来源: {u.get('company','?')} · {u.get('报表','?')}")
            with cols[1]:
                if suggested:
                    options = ["(忽略)"] + [f"{s.get('名称', s.get('name','?'))} ({s.get('编码', s.get('code',''))})" for s in suggested]
                    choice = st.selectbox(f"映射到", options=options, index=0, key=f"alias_{i}")
                    if choice != "(忽略)":
                        std_name = choice.split(" (")[0]
                        u['_target'] = std_name
            with cols[2]:
                if suggested:
                    st.caption("推荐:")
                    for s in suggested[:3]:
                        conf = s.get('置信度', s.get('score', s.get('confidence', 0)))
                        st.caption(f"  • {s.get('名称', s.get('name', '?'))} ({conf:.0%})")
                st.write("")
        if (i + 1) % 5 == 0 or i == len(unique_unmatched) - 1:
            if st.button(f"💾 保存已选别名 ({i+1}/{len(unique_unmatched)})",
                       key=f"save_alias_{i}", type="primary"):
                saved_count = 0
                cas_path = os.path.join(STANDARDS_DIR, f"{selected_std}.yaml")
                if os.path.exists(cas_path):
                    with open(cas_path, encoding='utf-8') as f:
                        cas_data = yaml.safe_load(f) or {}
                else:
                    cas_data = {}
                alias_map = cas_data.setdefault('别名映射', {})
                for j in range(i - (i % 5), min(i + 1, len(unique_unmatched))):
                    u = unique_unmatched[j]
                    if u.get('_target'):
                        alias_map[u.get('原始名称', '?')] = u['_target']
                        saved_count += 1
                if saved_count > 0:
                    with open(cas_path, 'w', encoding='utf-8') as f:
                        yaml.dump(cas_data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
                    st.success(f"✅ 已保存 {saved_count} 个别名到 `{selected_std}.yaml`")
                    remaining = [u for j, u in enumerate(unique_unmatched) if j > i or not u.get('_target')]
                    set_state('unmatched_subjects', remaining)
                else:
                    st.info("请先选择要映射的目标科目")
            st.divider()
else:
    # 检查是否已经导入过数据
    if all_records:
        st.markdown("### 🧠 未能识别匹配科目映射管理")
        st.success("✅ 所有科目均已成功匹配到标准科目，无需手动映射")
    else:
        st.markdown("### 🧠 未能识别匹配科目映射管理")
        st.caption("导入数据后，未匹配科目将在此处展示并管理")

st.divider()

# ===================================================================
# Section 5: 报表范式管理（底部固定）
# ===================================================================
st.markdown("### 📂 报表范式管理")
st.caption("管理已注册的报表格式映射，或上传样本自动生成新格式")

# 格式配置向导
with st.expander("🧙 上传样本 Excel 自动生成格式配置", expanded=False):
    col_wiz1, col_wiz2 = st.columns([3, 1])
    with col_wiz1:
        wizard_file = st.file_uploader(
            "选择样本 Excel", type=['xlsx'], key="wizard_upload",
            help="上传一份该格式的样本报表",
        )
    with col_wiz2:
        st.markdown("### &nbsp;")
        save_name = st.text_input("格式名称（可选）", placeholder="如: 某某公司月报格式")

    if wizard_file:
        import uuid
        tmp_path = os.path.join(OUTPUT_DIR, f"_wizard_{uuid.uuid4().hex}.xlsx")
        with open(tmp_path, 'wb') as f:
            f.write(wizard_file.getbuffer())
        from core.format_wizard import analyze_excel, save_format_config
        with st.spinner("🔍 正在分析 Excel 格式..."):
            draft_config = analyze_excel(tmp_path)
        fmt = draft_config['format']
        st.success(f"✅ 分析完成！识别为 **{fmt['type']}** 格式")
        st.markdown("##### 📋 分析结果摘要")
        st.markdown(f"- **文件匹配**: `{list(fmt.get('detection', {}).get('file_patterns', {}).values())}`")
        st.markdown(f"- **公司名位置**: 第 `{fmt.get('company_name_row')}` 行")
        st.markdown("##### 📑 Sheet 识别结果")
        from core.format_wizard import FormatWizard
        inner_wiz = FormatWizard(tmp_path)
        inner_wiz.analyze()
        sheet_rows = []
        for sn, analysis in inner_wiz.sheet_analyses.items():
            stype = analysis.get('type') or '❓ 未识别'
            struct = analysis.get('structure', '?')
            cols = analysis.get('columns', {})
            ncols = len(cols)
            sheet_rows.append({
                "Sheet名": sn, "识别类型": stype,
                "布局": "左右对照" if struct == 'dual_column_side_by_side' else "单列",
                "表头行": analysis.get('header_row', '?'), "识别列数": ncols,
            })
        inner_wiz.close()
        if sheet_rows:
            st.dataframe(pd.DataFrame(sheet_rows), use_container_width=True, hide_index=True)
        with st.expander("📝 预览生成的 YAML 配置", expanded=True):
            import yaml as yml
            st.code(yml.dump(draft_config, allow_unicode=True, default_flow_style=False, sort_keys=False),
                    language="yaml")
        col_save1, col_save2 = st.columns([1, 3])
        with col_save1:
            final_name = save_name.strip() or fmt.get('id', f"format_{uuid.uuid4().hex[:8]}")
            if st.button(f"💾 保存为 {final_name}.yaml", type="primary", use_container_width=True):
                yaml_path = os.path.join(MAPPINGS_DIR, f"{final_name}.yaml")
                if os.path.exists(yaml_path):
                    st.error(f"❌ 格式 `{final_name}` 已存在，请换一个名称")
                else:
                    save_format_config(draft_config, yaml_path)
                    st.success(f"✅ 格式映射已保存为 `{final_name}.yaml`！刷新后可在导入时使用")
                    st.rerun()
        with col_save2:
            st.caption("💡 保存后，下次导入同格式报表时系统会自动识别")
        os.unlink(tmp_path)

# 已注册格式列表
with st.expander("📋 已注册的格式映射", expanded=False):
    from core.loader import FormatDetector
    detector = FormatDetector(MAPPINGS_DIR)
    formats = detector.list_formats()
    if formats:
        for fmt in formats:
            with st.expander(f"[{fmt['id']}] {fmt['name']} — {fmt['type']}"):
                yaml_path = os.path.join(MAPPINGS_DIR, f"{fmt['id']}.yaml")
                if os.path.exists(yaml_path):
                    with open(yaml_path, encoding='utf-8') as f:
                        data = yaml.safe_load(f)
                    格式 = data.get('format', {})
                    st.json({
                        "格式ID": fmt['id'], "名称": 格式.get('name'),
                        "类型": 格式.get('type'),
                        "报表": [k for k in ['balance_sheet', 'income_statement', 'cash_flow_statement'] if k in 格式],
                        "文件匹配规则": 格式.get('detection', {}).get('file_patterns', {}),
                    })
                    show_full = st.checkbox(f"显示完整 YAML", key=f"yaml_{fmt['id']}")
                    if show_full:
                        st.code(yaml.dump(data, allow_unicode=True), language="yaml")
    else:
        st.info("暂无已注册的格式映射")
