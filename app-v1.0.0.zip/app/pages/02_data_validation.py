"""
✅ 单体报表勾稽检验 — Step 3

CAS准则 24条规则:
- 一、资产负债表内部勾稽 (1-6)
- 二、利润表内部勾稽 (7-9)
- 三、现金流量表内部勾稽 (10-14)
- 四、表间勾稽 (15-18)
- 五、期初期末勾稽 (19-20)
- 六、合理性检查 (21-24)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import streamlit as st
import pandas as pd
import json

st.set_page_config(page_title="单体勾稽检验", page_icon="✅", layout="wide")

from app.components.common import header, metric_card, render_sidebar
from app.utils.session import get_state, set_state

PROJECT_DIR = os.path.join(os.path.dirname(__file__), '..', '..')
CONFIG_DIR = os.path.join(PROJECT_DIR, 'config')
OUTPUT_DIR = os.path.join(PROJECT_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

header("✅ 单体报表勾稽检验", "Step 3: 24条规则逐一校验，校验无误方可进入后续步骤")
render_sidebar()

# ========== 加载数据 ==========
all_records = get_state('all_records')
imported_files = get_state('imported_files')

if not all_records:
    st.warning("⚠️ 请先完成 Step 1: 导入报表数据")
    st.page_link("pages/01_import_data.py", label="→ 去导入数据", use_container_width=True)
    st.stop()

# 按公司分组
df = pd.DataFrame(all_records)
companies = sorted(df['company'].unique().tolist()) if not df.empty else []
company_data = {c: df[df['company'] == c].to_dict('records') for c in companies}

st.info(f"🏢 共 {len(companies)} 家公司 | 📄 {len(all_records)} 条科目记录 | 📁 {len(imported_files)} 个导入文件")

# ========== 加载检验引擎 ==========
from core.standards import StandardsManager
from core.validator import ValidatorEngine
STANDARDS_DIR = os.path.join(CONFIG_DIR, 'standards')
std_mgr = StandardsManager(STANDARDS_DIR)
engine = ValidatorEngine(std_mgr)

# ========== 批量检验 / 单家公司 ==========
tab1, tab2 = st.tabs(["📋 批量检验", "🏢 单家公司明细"])

# 存储检验结果
if 'validation_results' not in st.session_state:
    st.session_state.validation_results = {}
if 'user_inputs_16' not in st.session_state:
    st.session_state.user_inputs_16 = {}


# === Tab 1: 批量检验 ===
with tab1:
    st.markdown("### 全部公司批量勾稽检验")

    # 自动执行校验（被动触发）
    if 'validation_auto_run' not in st.session_state:
        st.session_state.validation_auto_run = False

    if not st.session_state.validation_auto_run and all_records:
        progress = st.progress(0)
        status = st.empty()

        results = {}
        total = len(companies)
        for idx, company in enumerate(companies):
            status.text(f"检验中: {company} ({idx+1}/{total})")
            records = company_data.get(company, [])
            result = engine.validate(records, st.session_state.user_inputs_16)
            results[company] = result
            progress.progress((idx + 1) / total)

        st.session_state.validation_results = results
        st.session_state.validation_auto_run = True
        status.text("✅ 自动检验完成！")
        from app.utils.session import auto_save
        auto_save()
        st.rerun()

    # 如果数据有更新（重新导入后），重新自动校验
    current_record_hash = str(len(all_records)) + '_' + str(len(companies))
    if all_records and st.session_state.validation_auto_run:
        stored_hash = st.session_state.get('validation_data_hash', '')
        if stored_hash != current_record_hash:
            st.session_state.validation_auto_run = False
            st.session_state.validation_data_hash = current_record_hash
            st.rerun()
    if all_records:
        st.session_state.validation_data_hash = current_record_hash

    # 显示批量结果
    if st.session_state.validation_results:
        results = st.session_state.validation_results
        st.divider()
        st.markdown("### 📊 检验结果汇总")

        summary_rows = []
        for company, result in results.items():
            s = result.summary()
            summary_rows.append(s)

        summary_df = pd.DataFrame(summary_rows)
        st.dataframe(
            summary_df[['公司', '规则总数', '通过', '未通过', '需手动填写', '通过率']],
            use_container_width=True, hide_index=True,
            column_config={
                '通过': st.column_config.NumberColumn("✅ 通过"),
                '未通过': st.column_config.NumberColumn("❌ 未通过"),
                '需手动填写': st.column_config.NumberColumn("⚠️ 需确认"),
                '通过率': st.column_config.TextColumn("通过率"),
            }
        )

        # 整体统计
        total_rules = sum(s['规则总数'] for s in summary_rows)
        total_passed = sum(s['通过'] for s in summary_rows)
        total_failed = sum(s['未通过'] for s in summary_rows)
        need_input = sum(s['需手动填写'] for s in summary_rows)

        col1, col2, col3, col4 = st.columns(4)
        with col1: metric_card("全量规则", total_rules)
        with col2: metric_card("✅ 通过", total_passed, delta=f"{total_passed/total_rules*100:.0f}%" if total_rules else "")
        with col3: metric_card("❌ 未通过", total_failed)
        with col4: metric_card("⚠️ 需确认", need_input)

        # 有未通过 → 不可进入下一步
        if total_failed > 0:
            st.error("🚫 存在未通过的勾稽规则，请先在「单家公司明细」中检查并修正，确认无误后方可进入下一步")
        elif need_input > 0:
            st.warning("⚠️ 部分规则需手动确认（Rule #16），请切换到「单家公司明细」填写提取盈余公积和分配股利")
        else:
            st.success("✅ 全部公司通过勾稽检验！可以进入下一步")

        # ──────────────────────────────────────────────
        # 差异明细汇总：所有未通过的规则 + 合理性质疑
        # ──────────────────────────────────────────────
        failed_rows = []
        for company, result in results.items():
            for r in result.rules:
                if not r['passed']:
                    failed_rows.append({
                        '公司': company,
                        '规则': f"R{r['id']}",
                        '名称': r['name'],
                        '期望值': r.get('expected', '—'),
                        '实际值': r.get('actual', '—'),
                        '差异': r.get('diff', '—'),
                        '说明': r.get('detail', '')[:200],
                    })

        if failed_rows:
            st.divider()
            st.markdown("### 🔍 差异明细汇总")
            st.caption(f"共 {len(failed_rows)} 条未通过规则，涉及 {len(set(r['公司'] for r in failed_rows))} 家公司")

            failed_df = pd.DataFrame(failed_rows)
            st.dataframe(
                failed_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    '公司': st.column_config.TextColumn("🏢 公司", width="medium"),
                    '规则': st.column_config.TextColumn("规则", width="small"),
                    '名称': st.column_config.TextColumn("检验名称", width="medium"),
                    '期望值': st.column_config.TextColumn("期望值", width="medium"),
                    '实际值': st.column_config.TextColumn("实际值", width="medium"),
                    '差异': st.column_config.TextColumn("差异", width="medium"),
                    '说明': st.column_config.TextColumn("说明", width="large"),
                },
            )

            # 按公司分组展示可折叠详情
            with st.expander("📋 按公司逐条展开", expanded=False):
                for company in sorted(set(r['公司'] for r in failed_rows)):
                    company_fails = [r for r in failed_rows if r['公司'] == company]
                    with st.container(border=True):
                        st.markdown(f"**🏢 {company}** — {len(company_fails)} 条未通过")
                        for fr in company_fails:
                            st.markdown(
                                f"- **{fr['规则']}** {fr['名称']}  "
                                f"| 期望: `{fr['期望值']}`  "
                                f"| 实际: `{fr['实际值']}`  "
                                f"| 差异: `{fr['差异']}`"
                            )
                            if fr['说明']:
                                st.caption(f"  {fr['说明']}")

        # 批量导出结果
        col1, col2 = st.columns(2)
        with col1:
            output_path = os.path.join(OUTPUT_DIR, 'validation_summary.json')
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(summary_rows, f, ensure_ascii=False, indent=2)
            st.caption(f"📁 已保存: {output_path}")
        with col2:
            csv_path = os.path.join(OUTPUT_DIR, 'validation_summary.csv')
            summary_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
            with open(csv_path, 'rb') as f:
                st.download_button("📥 下载 CSV", data=f, file_name="勾稽检验汇总.csv", use_container_width=True)


# === Tab 2: 单家公司明细 ===
with tab2:
    if not companies:
        st.info("暂无公司数据")
        st.stop()

    selected_company = st.selectbox("选择公司", companies)

    if selected_company:
        records = company_data.get(selected_company, [])

        # 自动执行校验（切换公司时自动触发）
        if selected_company not in st.session_state.validation_results:
            result = engine.validate(records, st.session_state.user_inputs_16)
            st.session_state.validation_results[selected_company] = result

        # 显示结果
        if selected_company in st.session_state.validation_results:
            result = st.session_state.validation_results[selected_company]
            s = result.summary()

            col1, col2, col3, col4 = st.columns(4)
            with col1: metric_card("规则总数", s['规则总数'])
            with col2: metric_card("✅ 通过", s['通过'])
            with col3: metric_card("❌ 未通过", s['未通过'])
            with col4: metric_card("⚠️ 需确认", s['需手动填写'])

            # 按类别显示规则
            categories = {}
            for r in result.rules:
                cat = r['category']
                if cat not in categories:
                    categories[cat] = []
                categories[cat].append(r)

            # Rule #16 特殊处理 (需手动填写)
            rule16 = None
            for r in result.rules:
                if r['id'] == 16:
                    rule16 = r
                    break

            for cat_name, rules in categories.items():
                with st.expander(f"{cat_name} ({sum(1 for r in rules if r['passed'])}/{len(rules)} 通过)", expanded=True):
                    for r in rules:
                        if r['id'] == 16:
                            # Rule #16: 仅提示，不阻断 — 显示公式和说明
                            inputs = r.get('user_inputs', {})
                            detail = r.get('detail', '')
                            if '✅' in detail:
                                col_status, col_detail = st.columns([1, 4])
                                with col_status:
                                    st.markdown("✅")
                                with col_detail:
                                    st.markdown(f"**Rule 16: {r['name']}**")
                                    st.caption(detail)
                            else:
                                col_status, col_detail = st.columns([1, 4])
                                with col_status:
                                    st.markdown("ℹ️")
                                with col_detail:
                                    st.markdown(f"**Rule 16: {r['name']}** — 仅提示，不阻断")
                                    # 自动取数
                                    st.caption(
                                        f"自动取数: 盈余公积变动={inputs.get('自动提取盈余公积', 0):,.2f}, "
                                        f"应付股利变动={inputs.get('自动分配股利', 0):,.2f}"
                                    )
                                    # 公式展示
                                    st.info(
                                        f"`期初未分配利润({inputs.get('期初未分配利润', 0):,.2f})` + "
                                        f"`净利润({inputs.get('净利润', 0):,.2f})` - "
                                        f"`提取盈余公积({inputs.get('提取盈余公积', 0):,.2f})` - "
                                        f"`分配股利({inputs.get('分配股利', 0):,.2f})` = "
                                        f"`{inputs.get('期末未分配利润(计算)', 0):,.2f}`  vs "
                                        f"`报表期末({inputs.get('期末未分配利润(报表)', 0):,.2f})`"
                                    )
                                    st.caption(
                                        "💡 差异常见原因：利润分配、盈余公积提取、"
                                        "以前年度损益调整、会计政策变更等，属正常现象"
                                    )

                        else:
                            # 普通规则
                            status = "✅" if r['passed'] else "❌"
                            col_status, col_detail = st.columns([1, 4])
                            with col_status:
                                st.markdown(f"**{status}**")
                            with col_detail:
                                st.markdown(f"**Rule {r['id']}: {r['name']}**")
                                st.caption(r.get('detail', '')[:120])
