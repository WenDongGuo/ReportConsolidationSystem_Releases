"""
🔗 股权架构 — 控制关系配置表

根据 Step 1 导入的公司列表，配置集团控制关系:
- 公司 | 其母公司 | 持股比例 | 表决权比例 | 并表触发方式 | 关键判断点 | 并表起点
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import streamlit as st
from streamlit.components.v1 import html as st_html
import pandas as pd
import json
from datetime import date

st.set_page_config(page_title="股权架构", page_icon="🔗", layout="wide")

from app.components.common import header, metric_card, render_sidebar
from app.utils.session import get_state, set_state

PROJECT_DIR = os.path.join(os.path.dirname(__file__), '..', '..')
OUTPUT_DIR = os.path.join(PROJECT_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

header("🔗 股权架构", "配置集团控制关系 — 控制三要素判定")
render_sidebar()

# ========== 加载数据 ==========
all_records = get_state('all_records')
imported_files = get_state('imported_files')

if not all_records:
    st.warning("⚠️ 请先完成 Step 1：导入报表数据")
    st.page_link("pages/01_import_data.py", label="→ 去导入数据", use_container_width=True)
    st.stop()

# 从导入数据中提取公司列表
df = pd.DataFrame(all_records)
companies = sorted(df['company'].unique().tolist()) if not df.empty else []
period_label = get_state('period_label') or '未设置'
report_ccy = get_state('report_currency') or 'CNY'

st.info(f"📅 {period_label}  |  💰 {report_ccy}  |  🏢 已导入 {len(imported_files)} 个文件，{len(companies)} 家公司")

if len(companies) == 0:
    st.error("❌ 导入数据中未找到公司名称，请检查导入步骤")
    st.stop()

# ========== 并表触发方式选项 ==========
CONSOLIDATION_METHODS = [
    "直接投资设立",
    "收购股权（一次性买断）",
    "分步取得控制（跨越控制门槛）",
    "协议/章程/VIE结构",
    "事实控制/实质重于形式",
    "未形成控制（不并表）",
    "其他",
]

# ========== 初始化/加载已有股权配置 ==========
existing_config = get_state('equity_config')

# 兼容旧数据：过滤掉内部 ID 列（公司ID、其母公司ID）
if existing_config and isinstance(existing_config, list) and existing_config:
    _filtered = []
    for row in existing_config:
        if isinstance(row, dict):
            _filtered.append({k: v for k, v in row.items()
                             if k not in ('公司ID', '其母公司ID')})
        else:
            _filtered.append(row)
    existing_config = _filtered
    set_state('equity_config', existing_config)

if existing_config and isinstance(existing_config, list):
    # 已有配置 -> 按公司名构建初始数据
    config_df = pd.DataFrame(existing_config)
    # 确保所有公司都在表里
    configured_companies = set(config_df['公司'].tolist()) if '公司' in config_df else set()
else:
    config_df = pd.DataFrame()
    configured_companies = set()

# 构建编辑器数据: 所有公司都应有行
editor_data = []
for c in companies:
    if not config_df.empty and c in config_df['公司'].values:
        row = config_df[config_df['公司'] == c].iloc[0].to_dict()
    else:
        row = {
            '公司': c,
            '其母公司': '',
            '持股比例(%)': 100.0 if len(companies) == 1 else 0.0,
            '表决权比例(%)': 100.0 if len(companies) == 1 else 0.0,
            '并表触发方式': '直接投资设立' if len(companies) == 1 else '未形成控制（不并表）',
            '关键判断点': '',
            '并表起点': get_state('period_start') or str(date.today()),
        }
    editor_data.append(row)

editable_df = pd.DataFrame(editor_data)

# ========== 主编辑器 ==========
st.markdown("### 📋 集团控制关系表")
st.caption("根据 CAS 33 控制三要素（权力、可变回报、运用权力影响回报）判断并表关系")

# 使用 st.data_editor 实现可编辑表格
edited_df = st.data_editor(
    editable_df,
    use_container_width=True,
    hide_index=True,
    column_config={
        '公司': st.column_config.TextColumn(
            "公司",
            disabled=True,
            width="medium",
            help="从导入数据自动获取的公司名称",
        ),
        '其母公司': st.column_config.SelectboxColumn(
            "其母公司",
            width="medium",
            options=[None] + companies,
            required=False,
            help="该公司的直接控股母公司，空值表示集团顶层公司。选了同公司名仅提示不阻断",
        ),
        '持股比例(%)': st.column_config.NumberColumn(
            "持股比例(%)",
            min_value=0.0,
            max_value=100.0,
            step=0.01,
            format="%.2f%%",
            width="small",
            help="母公司持有该公司的股权比例（0-100%）",
        ),
        '表决权比例(%)': st.column_config.NumberColumn(
            "表决权比例(%)",
            min_value=0.0,
            max_value=100.0,
            step=0.01,
            format="%.2f%%",
            width="small",
            help="母公司实际拥有的表决权比例，可能不同于持股比例（如一致行动协议）",
        ),
        '并表触发方式': st.column_config.SelectboxColumn(
            "并表触发方式",
            options=CONSOLIDATION_METHODS,
            width="medium",
            help="形成控制的业务场景",
        ),
        '关键判断点': st.column_config.TextColumn(
            "关键判断点",
            width="medium",
            help="如: 董事会多数席位、一致行动协议、VIE协议、代持安排等",
        ),
        '并表起点': st.column_config.TextColumn(
            "并表起点",
            width="small",
            help="开始纳入合并报表的日期（格式: YYYY-MM-DD）",
        ),
    },
    num_rows="fixed",
    height=min(50 * (len(companies) + 1), 400),
)

# ========== 导入/导出 ==========
st.divider()
col_export, col_import, col_save, col_status = st.columns([1, 1, 1, 2])

with col_export:
    # CSV 下载导出
    csv_path = os.path.join(OUTPUT_DIR, 'equity_config.csv')
    edited_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    with open(csv_path, 'rb') as f:
        st.download_button("📥 下载 CSV", data=f, file_name="股权架构.csv",
                          mime="text/csv", use_container_width=True)

with col_import:
    with st.expander("📤 导入股权架构", expanded=False):
        imported_file = st.file_uploader(
            "选择 CSV 或 JSON 文件",
            type=['csv', 'json'],
            key="equity_import",
            help="导入之前导出的股权架构文件（CSV 或 JSON 格式）",
        )
        if imported_file:
            try:
                if imported_file.name.endswith('.csv'):
                    import_df = pd.read_csv(imported_file)
                else:
                    import_df = pd.read_json(imported_file)

                # 强制文本列转为字符串（CSV 空值会被 pandas 读成 float NaN）
                text_cols = ['公司', '其母公司', '并表触发方式', '关键判断点', '并表起点']
                for col in text_cols:
                    if col in import_df.columns:
                        import_df[col] = import_df[col].fillna('').astype(str)
                # 数值列
                num_cols = ['持股比例(%)', '表决权比例(%)']
                for col in num_cols:
                    if col in import_df.columns:
                        import_df[col] = pd.to_numeric(import_df[col], errors='coerce').fillna(0.0)

                # 校验必要列
                required_cols = ['公司', '其母公司', '持股比例(%)', '表决权比例(%)', '并表触发方式']
                missing = [c for c in required_cols if c not in import_df.columns]
                if missing:
                    st.error(f"缺少必要列：{'、'.join(missing)}")
                else:
                    # 重新设置索引以保证公司顺序匹配当前项目
                    import_dict = {r['公司']: r for r in import_df.to_dict('records')}
                    # 用导入数据替换现有行
                    merged = []
                    for c in companies:
                        if c in import_dict:
                            merged.append(import_dict[c])
                        else:
                            merged.append({
                                '公司': c,
                                '其母公司': '',
                                '持股比例(%)': 0.0,
                                '表决权比例(%)': 0.0,
                                '并表触发方式': '未形成控制（不并表）',
                                '关键判断点': '',
                                '并表起点': get_state('period_start') or str(date.today()),
                            })
                    # 【关键】保存到 session state，rerun 后才不会丢失
                    set_state('equity_config', merged)
                    # 同步保存到 SQLite
                    from app.utils.session import auto_save
                    auto_save()
                    st.success(f"✅ 已导入 {len(merged)} 条股权架构")
                    st.rerun()
            except Exception as e:
                st.error(f"❌ 导入失败：{e}")

with col_save:
    if st.button("💾 保存股权架构", type="primary", use_container_width=True):
        records = edited_df.to_dict('records')

        # 校验：公司不能选择自己作为母公司
        self_refs = []
        for r in records:
            company = r.get('公司', '')
            parent = r.get('其母公司', '')
            if parent and parent == company:
                self_refs.append(company)

        if self_refs:
            st.warning(f"⚠️ 以下公司选择了自己作为母公司：{'、'.join(self_refs)}，已保存但请注意检查")

        set_state('equity_config', records)

        # 持久化到 JSON
        output_path = os.path.join(OUTPUT_DIR, 'equity_config.json')
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(records, f, ensure_ascii=False, indent=2, default=str)

        st.success(f"✅ 已保存 {len(records)} 条控制关系")
        from app.utils.session import auto_save
        auto_save()
        set_state('current_step', 2)

with col_status:
    if existing_config and isinstance(existing_config, list):
        st.info(f"📌 当前 {len(existing_config)} 条已保存配置")

# ========== 组织架构预览（可视化树形卡片） ==========
st.divider()
st.markdown("### 🏢 集团组织架构图")

records = edited_df.to_dict('records')
top_companies = [r for r in records if not r.get('其母公司')]

if top_companies:
    # ── 构建树 ──
    def build_tree(parent_name, records):
        children = []
        for r in records:
            if r.get('其母公司') == parent_name:
                sub = build_tree(r['公司'], records)
                children.append({'data': r, 'children': sub})
        return children

    forest = []
    for tc in top_companies:
        forest.append({'data': tc, 'children': build_tree(tc['公司'], records)})

    # ── 计算子树叶子数（用于确定宽度） ──
    CARD_W = 200
    GAP = 24

    def count_leaves(node):
        if not node['children']:
            return 1
        return sum(count_leaves(c) for c in node['children'])

    def assign_width(node):
        leaves = count_leaves(node)
        node['_w'] = leaves * CARD_W + (leaves - 1) * GAP
        for c in node['children']:
            assign_width(c)

    for tree in forest:
        assign_width(tree)

    # ── 渲染卡片 ──
    def render_card(r):
        method = r.get('并表触发方式', '')
        is_control = '未形成控制' not in method
        ratio = r.get('持股比例(%)', 0)
        vote = r.get('表决权比例(%)', 0)
        note = r.get('关键判断点', '')

        bc = "#22c55e" if is_control else "#ef4444"
        bg = "#f0fdf4" if is_control else "#fef2f2"
        badge = "✅ 并表" if is_control else "⛔ 不并表"
        vs = f" | 表决权 {vote:.1f}%" if vote else ""
        ratio_str = f"{ratio:.1f}%" if ratio else "—"
        note_html = f'<div style="font-size:0.75em;color:#888;margin-top:4px;">📝 {note}</div>' if note else ''

        return f'''
<div style="border:2px solid {bc};border-radius:10px;background:{bg};
            padding:10px 12px;width:{CARD_W-24}px;text-align:center;
            box-shadow:0 2px 6px rgba(0,0,0,0.1);">
    <div style="font-weight:bold;font-size:0.9em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{r['公司']}</div>
    <div style="font-size:0.78em;color:#666;margin-top:4px;">
        {ratio_str}{vs}
    </div>
    <div style="font-size:0.72em;color:#999;margin-top:2px;">{badge} {method}</div>
    {note_html}
</div>'''

    # ── 渲染连接线（父 → 子） ──
    def render_connector(child_nodes):
        n = len(child_nodes)
        if n == 0:
            return ''
        if n == 1:
            return '<div style="display:flex;justify-content:center;"><div style="width:2px;height:28px;background:#ccc;"></div></div>'

        # 竖线从父底部
        html = '<div style="display:flex;flex-direction:column;align-items:center;width:100%;">'
        html += '<div style="width:2px;height:14px;background:#ccc;"></div>'

        # 横向连接条：精确覆盖所有子节点宽度
        total_w = sum(child_nodes[i]['_w'] for i in range(n)) + (n - 1) * GAP
        child_centers = []
        offset = 0
        for i in range(n):
            child_centers.append(offset + child_nodes[i]['_w'] / 2)
            offset += child_nodes[i]['_w'] + GAP

        bar_left = min(child_centers)
        bar_right = max(child_centers)
        bar_w = bar_right - bar_left

        html += f'<div style="position:relative;width:{total_w}px;height:14px;">'
        # 水平横线
        html += f'<div style="position:absolute;top:0;left:{bar_left}px;width:{bar_w}px;height:0;border-top:2px solid #ccc;"></div>'
        # 各子节点的竖线
        for i in range(n):
            cx = child_centers[i]
            html += f'<div style="position:absolute;top:0;left:{cx}px;width:2px;height:14px;background:#ccc;transform:translateX(-1px);"></div>'
        html += '</div>'
        html += '</div>'
        return html

    # ── 递归渲染节点 ──
    def render_node(node):
        card = render_card(node['data'])
        children = node['children']
        w = node['_w']

        if not children:
            return card

        children_html = ''.join(
            f'<div style="display:flex;flex-direction:column;align-items:center;">{render_node(c)}</div>'
            for c in children
        )
        connector = render_connector(children)

        return f'''
<div style="display:flex;flex-direction:column;align-items:center;width:{w}px;">
    {card}
    {connector}
    <div style="display:flex;flex-direction:row;gap:{GAP}px;justify-content:center;">
        {children_html}
    </div>
</div>'''

    # ── 组装森林 ──
    forest_html = ''.join(
        f'<div style="display:flex;flex-direction:column;align-items:center;">{render_node(tree)}</div>'
        for tree in forest
    )
    tree_html = f'<div style="display:flex;flex-wrap:wrap;gap:50px;justify-content:center;padding:20px 0;">{forest_html}</div>'

    st_html(tree_html, height=max(400, len(records) * 140), scrolling=True)

    # 统计摘要
    orphans = [r for r in records if not r.get('其母公司') and r['公司'] != top_companies[0]['公司']]
    total = len(records)
    control = sum(1 for r in records if '未形成控制' not in r.get('并表触发方式', '') and r.get('其母公司'))
    no_control = sum(1 for r in records if '未形成控制' in r.get('并表触发方式', '') and r.get('其母公司'))

    col1, col2, col3, col4 = st.columns(4)
    with col1: metric_card("📊 公司总数", total)
    with col2: metric_card("✅ 纳入合并", control)
    with col3: metric_card("⛔ 不并表", no_control)
    with col4: metric_card("🏢 集团数", len(top_companies))

    if len(top_companies) > 1:
        orphan_names = '、'.join(t['公司'] for t in top_companies[1:])
        st.info(f"⚠️ 有 {len(top_companies)} 个顶层公司，请确认 {orphan_names} 的母子公司关系")

    # 并表方式分布
    method_counts = {}
    for r in records:
        m = r.get('并表触发方式', '未设置')
        if r.get('其母公司'):
            method_counts[m] = method_counts.get(m, 0) + 1
    if method_counts:
        st.markdown("**并表方式分布:**")
        for m, c in sorted(method_counts.items(), key=lambda x: -x[1]):
            bar = "█" * c
            st.markdown(f"&nbsp;&nbsp;{m}: {bar} {c}家")

else:
    st.info("💡 请在表格中为每个公司指定「其母公司」，系统将自动生成组织架构图")
