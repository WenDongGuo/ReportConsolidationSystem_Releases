"""
📊 合并报表导出 — 已合并到调整页

导出功能已整合到「报表调整」页面（Step 6）：
  📥 点击 Excel / JSON 按钮即可下载

保留此页面仅作跳转指引，不删除以避免侧边栏链接断裂。
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import streamlit as st

st.set_page_config(page_title="合并报表导出", page_icon="📊", layout="wide")

from app.components.common import header, render_sidebar

render_sidebar()
header("📊 合并报表导出", "导出功能已迁移")

st.info(
    "### ✅ 导出功能已整合到「报表调整」页面\n\n"
    "请前往 **Step 6 → 报表调整**，在右侧预览区上方点击 "
    "**📥 Excel** 或 **📄 JSON** 按钮直接下载。\n\n"
    "导出的 Excel 格式与页面预览一致：\n"
    "- 资产负债表（期末/期初）\n"
    "- 利润表\n"
    "- 现金流量表\n\n"
    "每张表包含：合并列（调整后/调整额/调整前）和各单体公司明细。"
)

st.page_link("pages/02z_report_adjustment.py",
             label="→ 前往报表调整页导出", use_container_width=True)
