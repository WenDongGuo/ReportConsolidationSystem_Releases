"""
报表模板行构建工具函数
从 05_consolidation_offset.py 提取，供 07_report_export.py 共用
"""

from core.journal_entry import get_normal_balance, classify_account
from core.consolidation_report import ReportGenerator as RG


def _fmt_amt(v) -> str:
    """千分位保留两位，无货币符号"""
    if v is None or abs(v) < 0.005:
        return "—"
    return f"{v:,.2f}"


def _sticky_left_style(left_px: int, z_index: int = 3) -> str:
    """生成 sticky left 内联样式"""
    if left_px < 0:
        return ''
    return f'position:sticky;left:{left_px}px;z-index:{z_index};'


_BS_COL_WIDTHS = [80, 180, 120, 120, 120, 120, 120, 120]
_IS_COL_WIDTHS = [80, 180, 120, 120, 120]


def _frozen_lefts(widths: list) -> list:
    """根据列宽列表，计算每列的累计 left 偏移值"""
    result = []
    acc = 0
    for w in widths:
        result.append(acc)
        acc += w
    return result


def _get_periods(report_type: str) -> list:
    return ['期末余额', '年初余额'] if report_type == '资产负债表' else ['本年累计']


def _get_template_amt(codes, company_data, cons_adjustments, co, period, report_type):
    """获取单个主体的科目金额（支持编码字符串或元组）"""
    if codes is None:
        return 0.0
    if isinstance(codes, str):
        base = company_data[co].get((codes, period, report_type), 0.0)
        return base + cons_adjustments.get((codes, period, report_type), 0.0)
    if isinstance(codes, tuple):
        total = 0.0
        for c in codes:
            base = company_data[co].get((c, period, report_type), 0.0)
            total += base + cons_adjustments.get((c, period, report_type), 0.0)
        return total
    return 0.0


def _sum_val_dicts(dicts_list):
    """多个 {(co,period): amt} 按 key 相加"""
    if not dicts_list:
        return {}
    result = {}
    for d in dicts_list:
        for k, v in d.items():
            result[k] = round(result.get(k, 0) + v, 2)
    return result


def _build_report_rows(template, company_data, companies_sorted, cons_adjustments, report_type):
    """按会计模板（BS_ITEMS/IS_ITEMS/CF_ITEMS）生成结构化的报表行列表

    每行 dict: {type, name, code, _vals: {(co,period): amt}}
    type 取值: section / detail / total / grand_total
    """
    periods = _get_periods(report_type)

    rows = []
    detail_stack = []
    flat_details = []    # 无 section 模板的 flat 明细列表
    flat_signs = []      # 每行在合计中的符号（贷余=+1加，借余=-1减）
    profit_sum_vals = None  # 净利润合计值（供综合收益总额用）
    oci_section_sums = []   # OCI 各节汇总（供综合收益总额加总）
    section_sign_stack = [] # CF section 符号（流入=+1，流出=-1）
    cf_net_vals = []        # CF 各活动净额（经营/投资/筹资）

    for item in template:
        name = item[0]
        codes = item[1]
        row_type = item[2]

        if row_type == 'section':
            rows.append({'type': 'section', 'name': name, 'code': ''})
            detail_stack.append([])
            # CF section sign: 流出 -1, 其他 +1
            section_sign_stack.append(-1 if '流出' in name else 1)
            continue

        if row_type == 'detail':
            code_list = []
            if isinstance(codes, str):
                code_list = [codes]
            elif isinstance(codes, tuple):
                code_list = list(codes)
            # 合计符号：贷余=+1(加项)，借余=-1(减项)
            row_sign = 1
            for c in code_list:
                if c and get_normal_balance(c) == 'debit':
                    row_sign = -1
                    break
            per_co = {}
            for co in companies_sorted:
                for p in periods:
                    per_co[(co, p)] = round(_get_template_amt(
                        codes, company_data, cons_adjustments, co, p, report_type), 2)
            code_str = codes if isinstance(codes, str) else (codes[0] if isinstance(codes, tuple) else '')
            rows.append({'type': 'detail', 'name': name, 'code': code_str, '_vals': per_co})
            if detail_stack:
                detail_stack[-1].append(per_co)
            # flat tracking for section-less template parts (P&L before OCI)
            if not detail_stack:
                flat_details.append(per_co)
                flat_signs.append(row_sign)
            continue

        if row_type in ('total', 'grand_total'):
            if detail_stack:
                section_items = detail_stack.pop()
                # 弹出对应的 section 符号
                section_sign = section_sign_stack.pop() if section_sign_stack else 1

                if row_type == 'grand_total' and not detail_stack:
                    # ── 最外层 grand_total：带符号加权求和（CF 净额）──
                    total = {}
                    if section_items and isinstance(section_items[0], dict) and 'value' in section_items[0]:
                        # 子节有符号：加权求和
                        for item in section_items:
                            sv = item['value']
                            sg = item.get('sign', 1)
                            for k, v in sv.items():
                                total[k] = total.get(k, 0) + v * sg
                    else:
                        # 纯明细：直接相加
                        total = _sum_val_dicts(section_items)
                    # 保存到 oci_section_sums 供现金流量净额用
                    oci_section_sums.append(total)
                    # 保存 CF 活动净额
                    if '现金流量净额' in name:
                        cf_net_vals.append(total)
                    rows.append({'type': row_type, 'name': name, 'code': '',
                                 '_vals': total})
                    # 不往上推（已是根层级）
                else:
                    # ── 内层 total/grand_total：普通相加 ──
                    section_sum = _sum_val_dicts(section_items)
                    # OCI section total → save for 综合收益总额
                    oci_section_sums.append(section_sum)
                    rows.append({'type': row_type, 'name': name, 'code': '',
                                 '_vals': section_sum})
                    if detail_stack:
                        # 带 section 符号推入父栈，供外层 grand_total 加权求和
                        detail_stack[-1].append({'value': section_sum, 'sign': section_sign})
            elif flat_details:
                # P&L flat 合计（营业利润/利润总额/净利润）
                section_items = list(flat_details)
                signs = list(flat_signs)
                total = {}
                for (co, p), amt in section_items[0].items():
                    s = sum((it[(co, p)] if (co, p) in it else 0) * sg
                            for it, sg in zip(section_items, signs))
                    total[(co, p)] = round(s, 2)
                # 保存净利润合计，用于综合收益总额
                if '净利润' in name and row_type == 'grand_total':
                    profit_sum_vals = total
                # 综合收益总额 = 净利润 + OCI 合计（取最后弹出的 OCI 节汇总）
                if '综合收益总额' in name and profit_sum_vals is not None and oci_section_sums:
                    oci_total = oci_section_sums[-1]
                    for (co, p) in total:
                        total[(co, p)] = round(profit_sum_vals.get((co, p), 0) + oci_total.get((co, p), 0), 2)
                # 现金及现金等价物净增加额 = Σ(活动净额) + 汇率影响
                if '现金及现金等价物净增加额' in name and cf_net_vals:
                    for net in cf_net_vals:
                        for (co, p) in total:
                            total[(co, p)] = round(total.get((co, p), 0) + net.get((co, p), 0), 2)
                rows.append({'type': row_type, 'name': name, 'code': '',
                             '_vals': total})
            continue

    return rows


def _row_to_vals(r, company_data, companies_sorted, cons_adjustments, report_type):
    """将会计模板行展平成完整列值列表

    返回长度 = frozen + len(companies) * len(periods)
    BS: [code, name, 期末调整后,期末调整额,期末调整前, 期初调整后,期初调整额,期初调整前,
         各公司期末余额,期初余额...]
    IS/CF: [code, name, 调整后,调整额,调整前, 各公司期间累计...]
    """
    periods = _get_periods(report_type)
    frozen = 8 if report_type == '资产负债表' else 5

    if r['type'] == 'section':
        cell_count = frozen + len(companies_sorted) * len(periods)
        vals = ['', f'  {r["name"]}']
        vals += [None] * (cell_count - 2)
        return vals

    per_co = r.get('_vals', {})
    code = r.get('code', '')

    if report_type == '资产负债表':
        bc = []
        for p in ['期末余额', '年初余额']:
            total = sum(per_co.get((co, p), 0) for co in companies_sorted)
            raw_total = sum(company_data[co].get((code, p, report_type), 0) for co in companies_sorted) if code else 0
            adj = total - raw_total
            bc += [round(total, 2), round(adj, 2), round(raw_total, 2)]
    else:
        total = sum(per_co.get((co, '本年累计'), 0) for co in companies_sorted)
        raw_total = sum(company_data[co].get((code, '本年累计', report_type), 0) for co in companies_sorted) if code else 0
        adj = total - raw_total
        bc = [round(total, 2), round(adj, 2), round(raw_total, 2)]

    vals = [code, r['name']] + bc
    for co in companies_sorted:
        for p in periods:
            vals.append(per_co.get((co, p), 0))
    return vals


def export_preview_to_excel(preview, companies, periods_map, path,
                             mono_entries=None, cons_entries=None):
    """将预览数据（data_rows）导出为格式化的 Excel 文件

    Args:
        preview: dict of {report_type: (data_rows, period_labels, n_cols)}
        companies: 公司列表
        periods_map: {report_type: [period_labels]} 如 {'资产负债表': ['期末余额','年初余额']}
        path: 输出文件路径
        offset_entries: 可选，抵消分录列表，每笔含 description/category/lines
    """
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        return

    header_font = Font(bold=True, size=10)
    data_font = Font(size=10)
    thin_border = Border(
        left=Side(style='thin', color='cccccc'),
        right=Side(style='thin', color='cccccc'),
        top=Side(style='thin', color='cccccc'),
        bottom=Side(style='thin', color='cccccc'),
    )
    fill_adj = PatternFill(start_color='E8F4FD', end_color='E8F4FD', fill_type='solid')
    fill_section = PatternFill(start_color='E8F0FE', end_color='E8F0FE', fill_type='solid')
    fill_total = PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid')
    fill_company_even = PatternFill(start_color='F5F5F5', end_color='F5F5F5', fill_type='solid')
    fill_company_odd = PatternFill(start_color='FAFAFA', end_color='FAFAFA', fill_type='solid')
    center_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
    right_align = Alignment(horizontal='right', vertical='center')
    left_align = Alignment(horizontal='left', vertical='center')
    num_fmt = '#,##0.00'

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    def _period_label(period):
        if period == '期末余额': return '期末'
        if period == '年初余额': return '期初'
        return period

    def _write_sheet(ws, rt, data_rows, period_labels, col_spec=None):
        """写入一张报表 sheet"""
        periods = period_labels or ['本年累计']
        n_periods = len(periods)
        if n_periods == 0:
            return
        # 列宽规格：{a: A列宽, b: B列宽, rest: 其余列宽}
        if col_spec is None:
            col_spec = {'a': 10, 'b': 22, 'rest': 13}
        frozen = 2 + 3 * n_periods  # code + name + period*3
        co_stride = 3

        # 冻结
        ws.freeze_panes = 'F3'

        # ── 表头第1行：分组头 ──
        row = 1; col = 1
        for _ in range(2):
            c = ws.cell(row=row, column=col, value='')
            c.font = header_font; c.alignment = center_align; c.border = thin_border
            col += 1
        for pi in range(n_periods):
            pl = _period_label(periods[pi])
            for ci in range(3):
                c = ws.cell(row=row, column=col, value=f'{pl}合并抵消' if ci == 0 else '')
                c.font = header_font; c.alignment = center_align; c.border = thin_border
                c.fill = fill_adj; col += 1
            ws.merge_cells(start_row=1, start_column=col-3, end_row=1, end_column=col-1)
        for idx, co in enumerate(companies):
            c = ws.cell(row=row, column=col, value=co)
            c.font = header_font; c.alignment = center_align; c.border = thin_border
            c.fill = fill_company_even if idx % 2 == 0 else fill_company_odd
            ws.merge_cells(start_row=1, start_column=col, end_row=1, end_column=col+2)
            col += 3

        # ── 表头第2行：列名 ──
        row = 2; col = 1
        for h in ['科目编码', '报表科目']:
            c = ws.cell(row=row, column=col, value=h)
            c.font = header_font; c.alignment = center_align; c.border = thin_border
            col += 1
        for pi in range(n_periods):
            pl = _period_label(periods[pi])
            for h in [f'{pl}调整后', f'{pl}调整额', f'{pl}调整前']:
                c = ws.cell(row=row, column=col, value=h)
                c.font = header_font; c.alignment = center_align; c.border = thin_border
                c.fill = fill_adj; col += 1
        for _ in companies:
            for h in ['调整后', '调整额', '调整前']:
                c = ws.cell(row=row, column=col, value=h)
                c.font = header_font; c.alignment = center_align; c.border = thin_border
                col += 1

        # ── 数据行 ──
        r = 3
        for dr in data_rows:
            vals = dr['vals']
            rtype = dr['type']
            is_section = rtype == 'section'
            is_total = rtype in ('total', 'grand_total')
            for ci, v in enumerate(vals):
                cell = ws.cell(row=r, column=ci+1)
                if ci < 2:
                    cell.alignment = left_align if ci == 1 else center_align
                else:
                    cell.alignment = right_align
                    if isinstance(v, (int, float)):
                        cell.number_format = num_fmt
                cell.border = thin_border
                if is_section:
                    cell.fill = fill_section
                elif is_total:
                    cell.fill = fill_total
                elif ci >= frozen:
                    co_idx = (ci - frozen) // co_stride
                    cell.fill = fill_company_even if co_idx % 2 == 0 else fill_company_odd
                elif ci >= 2:
                    cell.fill = fill_adj
                if is_section:
                    cell.value = vals[1] if ci == 1 else ''
                else:
                    cell.value = (v if isinstance(v, (int, float)) and abs(v) >= 0.005
                                  else ('' if isinstance(v, (int, float)) else v))
                cell.font = Font(bold=True, size=10) if is_total else (
                    Font(bold=True, size=10) if is_section else data_font)
            r += 1

        # 列宽 + 格式
        ws.row_dimensions[1].height = 30
        ws.column_dimensions['A'].width = col_spec['a']
        ws.column_dimensions['B'].width = col_spec['b']
        n_co = len(companies)
        max_col = 2 + 3 * n_periods + n_co * 3
        for ci in range(3, max_col + 1):
            ws.column_dimensions[get_column_letter(ci)].width = col_spec['rest']
        # C3 到最右下角：缩小字体填充
        shrink = Alignment(vertical='center', shrinkToFit=True)
        shrink_left = Alignment(vertical='center', wrap_text=True, shrinkToFit=True)
        for row_idx in range(3, r):
            for col_idx in range(3, max_col + 1):
                cell = ws.cell(row=row_idx, column=col_idx)
                if cell.alignment:
                    old_align = cell.alignment
                    cell.alignment = Alignment(
                        horizontal=old_align.horizontal,
                        vertical='center',
                        shrinkToFit=True
                    )

    # ═══════════════════════════════════════════════
    # 写各报表 sheet
    # ═══════════════════════════════════════════════
    for rt, (data_rows, period_labels, n_cols) in preview.items():
        if not data_rows:
            continue

        if rt == '资产负债表':
            # 拆分为期末/期初两个独立的 sheet
            periods = periods_map.get(rt, period_labels or [])
            n_periods_total = len(periods)
            for pi, period in enumerate(periods):
                pl = _period_label(period)
                # 从 data_rows 中提取仅当前期间的数据列
                filtered_rows = []
                for rr in data_rows:
                    if rr['type'] == 'section':
                        section_name = rr['vals'][1] if len(rr['vals']) > 1 else ''
                        filtered_rows.append({'type': 'section',
                            'vals': ['', section_name] + [''] * (3 + len(companies) * 3)})
                        continue
                    vals = rr['vals']
                    # vals = [code, name, 期1后,期1调整,期1前, 期2后,期2调整,期2前, co1_期1..., co1_期2..., ...]
                    code, name = vals[0], vals[1]
                    # 本期合并列 (3 values)
                    cons_start = 2 + pi * 3
                    cons_cols = vals[cons_start:cons_start + 3]
                    # 本期各公司列 (每公司3值)
                    frozen_total = 2 + 3 * n_periods_total
                    co_cols = []
                    for jidx in range(len(companies)):
                        s = frozen_total + jidx * 3 * n_periods_total + pi * 3
                        co_cols.extend(vals[s:s + 3])
                    filtered_rows.append({'type': rr['type'], 'vals': [code, name] + cons_cols + co_cols})
                ws = wb.create_sheet(f'资产负债表（{pl}）')
                _write_sheet(ws, rt, filtered_rows, [period],
                             col_spec={'a': 8, 'b': 20, 'rest': 10})
        else:
            sheet_name = '利润表' if rt == '利润表' else '现金流量表'
            ws = wb.create_sheet(sheet_name)
            col_spec = {'a': 8, 'b': 38, 'rest': 10} if rt == '利润表' else {'a': 8, 'b': 31, 'rest': 10}
            _write_sheet(ws, rt, data_rows, period_labels, col_spec=col_spec)

    # ═══════════════════════════════════════════════
    # 单体调整分录 sheet
    # ═══════════════════════════════════════════════
    def _write_entries_sheet(ws, entries, sheet_label):
        headers = ['标识', '调整主体', '调整期间', '序号', '摘要', '方向',
                   '科目编码', '科目名称', '类别', '涉现', '金额']
        for ci, h in enumerate(headers, 1):
            c = ws.cell(row=1, column=ci, value=h)
            c.font = header_font; c.alignment = center_align; c.border = thin_border
        r = 2
        for entry in entries:
            raw_lines = entry.get('lines', [])
            if isinstance(raw_lines, str):
                import json
                raw_lines = json.loads(raw_lines) if raw_lines else []
            if not raw_lines:
                continue
            lines = raw_lines
            desc = entry.get('description', '')
            company = entry.get('company', entry.get('company_name', ''))
            adj_period = '期初' if entry.get('adjust_type') == '期初' else '期末'
            eid = entry.get('id', '')
            for li, line in enumerate(lines):
                side = '借' if line.get('side') == 'debit' else '贷'
                amt = abs(line.get('amount', 0))
                code = line.get('code', '')
                cat = classify_account(code)
                cf_cat = line.get('cf_category', '')
                cf_display = cf_cat if cf_cat else ('现金流' if code.startswith('C') else '')
                ws.cell(row=r, column=1, value=sheet_label if li == 0 else '').border = thin_border
                ws.cell(row=r, column=2, value=company if li == 0 else '').border = thin_border
                ws.cell(row=r, column=3, value=adj_period if li == 0 else '').border = thin_border
                ws.cell(row=r, column=4, value=f'#{eid}' if li == 0 else '').border = thin_border
                ws.cell(row=r, column=5, value=desc if li == 0 else '').border = thin_border
                ws.cell(row=r, column=6, value=side).border = thin_border
                ws.cell(row=r, column=7, value=code).border = thin_border
                ws.cell(row=r, column=8, value=line.get('name', '')).border = thin_border
                ws.cell(row=r, column=9, value=cat).border = thin_border
                ws.cell(row=r, column=10, value=cf_display).border = thin_border
                c = ws.cell(row=r, column=11, value=round(amt, 2) if amt > 0.005 else 0)
                c.border = thin_border; c.number_format = num_fmt; c.alignment = right_align
                r += 1
        # 冻结前5列 + 第1行 (F2)
        ws.freeze_panes = 'F2'
        # 第1行行高
        ws.row_dimensions[1].height = 30
        # 所有列 auto-fit
        for ci in range(1, 12):
            max_len = len(str(headers[ci - 1]))
            for row_idx in range(2, r):
                cell_val = ws.cell(row=row_idx, column=ci).value
                if cell_val:
                    max_len = max(max_len, len(str(cell_val)))
            ws.column_dimensions[get_column_letter(ci)].width = min(max_len + 3, 40)

    if mono_entries:
        ws = wb.create_sheet('单体调整分录')
        _write_entries_sheet(ws, mono_entries, '单体调整')
    if cons_entries:
        ws = wb.create_sheet('合并抵消分录')
        _write_entries_sheet(ws, cons_entries, '合并抵消')

    wb.save(path)


def export_preview_to_json(preview, companies, path):
    """将预览数据导出为 JSON"""
    import json
    output = {}
    for rt, (data_rows, period_labels, n_cols) in preview.items():
        rows_out = []
        for dr in data_rows:
            rows_out.append({
                'type': dr['type'],
                'vals': dr['vals'],
            })
        output[rt] = {
            'periods': period_labels,
            'rows': rows_out,
        }
    output['companies'] = companies
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    return path
