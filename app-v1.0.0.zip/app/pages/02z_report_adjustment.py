"""
📋 报表调整 — 统一的分录录入 + 动态合并预览

布局:
  左侧: 新增调整分录 + 已录入凭证分录表
  右侧: 4标签全合一预览表（期末/期初资产负债表、利润表、现金流量表）
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from datetime import datetime
import streamlit as st
import pandas as pd
from collections import defaultdict

st.set_page_config(page_title="报表调整", page_icon="📋", layout="wide")

from app.components.common import header, metric_card, render_sidebar
from app.utils.session import get_state, set_state, auto_save
from app.components.journal_ui import JournalEntryUI
from core.journal_entry import JournalManager, classify_account, is_cash_account, get_normal_balance, CF_CATEGORY_NAMES, CF_CATEGORIES
from core.standards import StandardsManager
from core.adjuster import Adjuster
from core.store import load_journal_entries, save_journal_entries, upsert_journal_entry, delete_journal_entry

PROJECT_DIR = os.path.join(os.path.dirname(__file__), '..', '..')
CONFIG_DIR = os.path.join(PROJECT_DIR, 'config')
STANDARDS_DIR = os.path.join(CONFIG_DIR, 'standards')
std_mgr = StandardsManager(STANDARDS_DIR)
adjuster = Adjuster(std_mgr)

from core.consolidation_report import ReportGenerator as _RG

# 单体调整和合并抵消各自的会计科目分组（用于表单下拉）
_MONO_ACCOUNT_GROUPS = {
    '资产类': ['1001','1101','1121','1122','1123','1131','1221','1231',
              '1401','1403','1406','1471','1511','1512','1521',
              '1601','1602','1604','1701','1702','1711','1801','1811','1901','1291'],
    '负债类': ['2001','2201','2202','2203','2211','2221','2231','2241',
              '2501','2502','2701','2801','2901','2903'],
    '权益类': ['4001','4002','4101','4103','4104','4105','4201'],
    '损益类': ['6001','6051','6061','6101','6111','6112','6301',
              '6401','6402','6403','6601','6602','6603',
              '6701','6702','6711','6801','6901','6902','5301'],
    '现金流': ['C001','C002','C003','C004','C005','C006','C007',
              'C008','C009','C010','C011','C012','C013','C014'],
}
_CONS_ACCOUNT_GROUPS = {k: v for k, v in _MONO_ACCOUNT_GROUPS.items()
                         if k not in ('现金流',)}

# ── 辅助函数 ──

def _get_companies():
    """从 all_records 获取公司列表"""
    records = get_state('all_records', [])
    return sorted(set(r.get('company','') for r in records if r.get('company')))

def _periods_for(report_type):
    return ['期末余额','年初余额'] if report_type == '资产负债表' else ['本年累计']

def _frozen_lefts(widths):
    acc, result = 0, []
    for w in widths:
        result.append(acc); acc += w
    return result

_STICKY_COL_WIDTHS = [80, 200]

def _sticky_style(ci):
    if ci < 0: return ''
    lefts = _frozen_lefts(_STICKY_COL_WIDTHS)
    if ci >= len(lefts): return ''
    return f'position:sticky;left:{lefts[ci]}px;z-index:{3 if ci==0 else 4};'

def _fmt(v):
    if v is None: return ''
    if not isinstance(v, (int, float)): return str(v)
    return f"{v:,.2f}"

def _load_journal_entries_from_db():
    """加载已保存的分录（兼容新旧格式）"""
    # 尝试从 session state 加载合并后的分录列表
    entries = get_state('adj_entries', None)
    if entries is not None:
        return entries
    # 从 DB 加载
    mono = load_journal_entries(get_state('project_id', 0), context='单体调整')
    cons = load_journal_entries(get_state('project_id', 0), context='合并抵消')
    result = []
    for e in mono:
        e['entry_type'] = '单体'
        result.append(e)
    for e in cons:
        e['entry_type'] = '合并'
        result.append(e)
    return result

def _save_entries(entries):
    """保存分录到 session state 和 DB"""
    set_state('adj_entries', entries)
    # 同时保存到 DB 保持兼容
    mono = [e for e in entries if e.get('entry_type') == '单体']
    cons = [e for e in entries if e.get('entry_type') == '合并']
    pid = get_state('project_id', 0)
    if pid:
        save_journal_entries(pid, mono, context='单体调整')
        save_journal_entries(pid, cons, context='合并抵消')
    auto_save()

def _upsert_last_entry(mgr, context):
    """保存 manager 中最新一条分录到 DB（用于 on_save_callback）"""
    entries = [e for e in mgr.entries if not e.is_deleted]
    if entries:
        pid = get_state('project_id', 0)
        if pid:
            upsert_journal_entry(pid, entries[-1].to_dict(), context)

def _resolve_cf_code(cf_category: str) -> str:
    """将 cf_category（显示名/C代码/类别名）解析为 Cxxx 代码"""
    if not cf_category:
        return ''
    # 1. 直接匹配 Cxxx 代码
    c = cf_category.strip()
    if c.startswith('C') and len(c) == 4 and c[1:].isdigit():
        return c
    # 2. 反向查找显示名 → Cxxx 代码
    for code, name in CF_CATEGORY_NAMES.items():
        if name == c:
            return code
    # 3. 匹配类别名（如 '经营流入'）→ 取第一个 Cxxx
    if c in CF_CATEGORIES:
        return CF_CATEGORIES[c][0]
    return ''


_CASH_CODES = {'1001', '1002'}


# 现金流流出科目（联动时取反：流出=正数）
_OUTFLOW_CF = set()
for cat, codes in CF_CATEGORIES.items():
    if '流出' in cat:
        _OUTFLOW_CF.update(codes)


def _is_credit_balance(code: str) -> bool:
    """判断科目是否是贷方余额类：贷方=增加"""
    return get_normal_balance(code) == 'credit'


def _compute_preview(entries):
    """计算预览数据

    Returns:
        dict: {report_type: [(code, name, cons_后, cons_调整, cons_前, [per_company...])]}
        其中 per_company 每个公司3列: [调整后, 调整额, 调整前]
    """
    all_records = get_state('all_records', [])
    companies = _get_companies()
    if not all_records or not companies:
        return {}

    # 构建原始金额
    raw_map = defaultdict(float)  # (co, code, period, rt) → amt
    for r in all_records:
        key = (r.get('company',''), r.get('科目编码',''), r.get('期间类型',''), r.get('报表',''))
        raw_map[key] += r.get('金额',0)

    # 构建单体调整金额
    mono_map = defaultdict(float)  # (co, code, period, rt) → adjustment
    for e in entries:
        if e.get('entry_type') != '单体':
            continue
        co = e.get('company','')
        adjust_type = e.get('adjust_type', '')
        # adjust_type 决定影响哪些期间：'期末'→期末余额/本年累计, '期初'→年初余额, 空→全部
        bs_periods = []
        if adjust_type == '期末':
            bs_periods = ['期末余额']
        elif adjust_type == '期初':
            bs_periods = ['年初余额']
        else:
            bs_periods = ['期末余额', '年初余额']
        for line in e.get('lines', []):
            code = line.get('code','')
            side = line.get('side','debit')
            amt = line.get('amount',0)
            # 按会计准则计算净额：借方余额科目 Dr=+ Cr=-；贷方余额科目 Dr=- Cr=+
            if _is_credit_balance(code):
                net = -amt if side == 'debit' else amt   # 贷方余额：贷=增加
            else:
                net = amt if side == 'debit' else -amt   # 借方余额：借=增加
            if code.startswith(('1','2','5')) or code in ('4001','4002','4101','4104','4105','4201'):
                for pk in bs_periods:
                    mono_map[(co, code, pk, '资产负债表')] += net
            elif code.startswith('6'):
                mono_map[(co, code, '本年累计', '利润表')] += net
            elif code.startswith('C'):
                mono_map[(co, code, '本年累计', '现金流量表')] += net
            # 涉现科目（1001/1002）若有 cf_category → 联动现金流量表
            if code in _CASH_CODES:
                cf_code = _resolve_cf_code(line.get('cf_category', ''))
                if cf_code:
                    # 流出科目取反：Cr 1001(付钱)=流出增加→正数
                    cf_net = -net if cf_code in _OUTFLOW_CF else net
                    mono_map[(co, cf_code, '本年累计', '现金流量表')] += cf_net

    # 构建合并抵消金额
    cons_map = defaultdict(float)  # (code, period, rt) → adjustment
    for e in entries:
        if e.get('entry_type') != '合并':
            continue
        adjust_type = e.get('adjust_type', '')
        bs_periods = []
        if adjust_type == '期末':
            bs_periods = ['期末余额']
        elif adjust_type == '期初':
            bs_periods = ['年初余额']
        else:
            bs_periods = ['期末余额', '年初余额']
        for line in e.get('lines', []):
            code = line.get('code','')
            side = line.get('side','debit')
            amt = line.get('amount',0)
            # 按会计准则计算净额：借方余额科目 Dr=+ Cr=-；贷方余额科目 Dr=- Cr=+
            if _is_credit_balance(code):
                net = -amt if side == 'debit' else amt   # 贷方余额：贷=增加
            else:
                net = amt if side == 'debit' else -amt   # 借方余额：借=增加
            if code.startswith(('1','2','5')) or code in ('4001','4002','4101','4104','4105','4201'):
                for pk in bs_periods:
                    cons_map[(code, pk, '资产负债表')] += net
            elif code.startswith('6'):
                cons_map[(code, '本年累计', '利润表')] += net
            elif code.startswith('C'):
                cons_map[(code, '本年累计', '现金流量表')] += net
            # 涉现科目（1001/1002）若有 cf_category → 联动现金流量表
            if code in _CASH_CODES:
                cf_code = _resolve_cf_code(line.get('cf_category', ''))
                if cf_code:
                    cf_net = -net if cf_code in _OUTFLOW_CF else net
                    cons_map[(cf_code, '本年累计', '现金流量表')] += cf_net

    # ── 后处理：将不在 BS 模板中的科目调整映射到父科目 ──
    # 备抵科目 Cr → 减少对应资产；隐藏科目 Dr → 增加对应资产
    _CONTRA_MAP = {
        '1231': '1122',   # 坏账准备 ↗ → 应收账款 ↘
        '1602': '1601',   # 累计折旧 ↗ → 固定资产 ↘
        '1702': '1701',   # 累计摊销 ↗ → 无形资产 ↘
        '1471': '1401',   # 存货跌价准备 ↗ → 存货 ↘
    }
    _HIDDEN_ASSET_MAP = {
        '1132': '1221',   # 应收利息 ↗ → 其他应收款 ↗
    }
    for (co, code, period, stmt), val in list(mono_map.items()):
        if stmt != '资产负债表':
            continue
        if code in _CONTRA_MAP:
            # 备抵科目：其调整需反向反映在父科目（Cr 坏账准备 → 减少应收账款）
            mono_map[(co, _CONTRA_MAP[code], period, stmt)] -= val
        elif code in _HIDDEN_ASSET_MAP:
            # 隐藏资产科目：调整同向反映在父科目
            mono_map[(co, _HIDDEN_ASSET_MAP[code], period, stmt)] += val

    # ── 后处理：P&L 损益影响联动到未分配利润（4104）──
    # 计算每家公司P&L净影响（本年累计），补充到期末未分配利润
    for co in companies:
        pl_revenue = 0.0  # 收入类（贷余）
        pl_expense = 0.0  # 费用类（借余）
        for (comp, code, pk, stmt), val in mono_map.items():
            if comp != co or stmt != '利润表' or pk != '本年累计':
                continue
            if _is_credit_balance(code):
                pl_revenue += val
            else:
                pl_expense += val
        pl_net = pl_revenue - pl_expense  # 正=利润增加
        if abs(pl_net) > 0.01:
            mono_map[(co, '4104', '期末余额', '资产负债表')] += pl_net

    # ── 后处理：合并调整P&L联动到4104 ──
    cons_pl_revenue = sum(v for (code, pk, stmt), v in cons_map.items()
                          if stmt == '利润表' and pk == '本年累计' and _is_credit_balance(code))
    cons_pl_expense = sum(v for (code, pk, stmt), v in cons_map.items()
                          if stmt == '利润表' and pk == '本年累计' and not _is_credit_balance(code))
    cons_pl_net = cons_pl_revenue - cons_pl_expense
    if abs(cons_pl_net) > 0.01:
        cons_map[('4104', '期末余额', '资产负债表')] += cons_pl_net

    # 构建模板行
    result = {}
    for rt, template_name in [('资产负债表', None), ('利润表', None), ('现金流量表', None)]:
        if rt == '资产负债表':
            template = _RG.BS_ITEMS
            periods = ['期末余额', '年初余额']
        elif rt == '利润表':
            template = _RG.IS_ITEMS
            periods = ['本年累计']
        else:
            template = _RG.CF_ITEMS
            periods = ['本年累计']

        report_rows = []
        stack = []
        stack_codes = []  # 并行追踪各 section 的所有科目编码（已展开）
        stack_signs = []  # 跟踪各 section 的CF符号（流出=-1）
        # 对于无 section 标记的模板（利润表），用 running_details 兜底合计行
        running_details = []
        running_codes = []  # 所有 detail 行的所有科目编码（已展开）
        running_signs = []  # 跟踪每个 detail 在合计中的符号（贷余=+1加，借余=-1减）
        # OCI（其他综合收益）独立于 P&L 明细，不混入净利润合计
        has_sections = False
        oci_details = []    # 净利润后的 OCI 明细（不进入 running_details）
        oci_signs = []      # OCI 行的符号
        oci_codes = []      # OCI 行的科目编码
        profit_frozen = False  # 是否已到净利润（此后 detail 走 OCI 通道）
        profit_grand = None    # 净利润的合计值（供综合收益总额用）
        section_totals = []  # 有 section 的模板：保存各节汇总 sum_pc，供 grand_total 累加
        section_cons_adjs = []  # 并行保存各节的合并调整额（按期间）
        section_signs = []  # 并行保存各节的符号
        section_gt_start = 0  # 当前 grand_total 对应的节起始索引（防止累积污染）
        bs_liab_group_start = 0  # BS 负债组起始索引（负债合计/负债和所有者权益合计用）

        def _all_codes(codes):
            """展开模板科目列为唯一编码列表"""
            if codes is None:
                return []
            if isinstance(codes, str):
                return [codes]
            if isinstance(codes, tuple):
                return list(codes)
            return []

        def _sec_sign(name):
            """CF流出section取-1让净额正确相减，其余取+1"""
            return -1 if rt == '现金流量表' and '流出' in name else 1

        for item in template:
            name, codes, rtype = item
            code_list = _all_codes(codes)  # 展开后的所有科目编码
            if rtype == 'section':
                report_rows.append({'type':'section','name':name})
                has_sections = True
                stack.append([])
                stack_codes.append([])
                stack_signs.append(_sec_sign(name))
                # BS负债组起始索引：在"流动负债："时记录当前 section_totals 长度
                if rt == '资产负债表' and '流动负债' in name and '非' not in name:
                    bs_liab_group_start = len(section_totals)
            elif rtype == 'detail':
                per_co = {}
                # 确定该行在合计中的符号：贷余(+1)=加项(收入)，借余(-1)=减项(费用)
                from core.journal_entry import get_normal_balance
                row_sign = 1  # 默认加
                for c in code_list:
                    if c and get_normal_balance(c) == 'debit':
                        row_sign = -1  # 借余科目在利润表中为抵减项
                        break
                for co in companies:
                    for p in periods:
                        raw = sum(raw_map.get((co, c, p, rt), 0.0) for c in code_list) if code_list else 0.0
                        adj = sum(mono_map.get((co, c, p, rt), 0.0) for c in code_list) if code_list else 0.0
                        after = raw + adj
                        per_co[(co, p)] = {'after': round(after,2), 'adj': round(adj,2), 'before': round(raw,2)}
                code_str = codes if isinstance(codes,str) else (codes[0] if isinstance(codes,tuple) else '')
                report_rows.append({'type':'detail','name':name,'code':code_str,'_all_codes':code_list,'_pc':per_co,'_sign':row_sign})
                if profit_frozen and rt == '利润表':
                    # 净利润后的 OCI 项目：走独立通道，不混入 P&L 合计
                    oci_details.append(per_co)
                    oci_signs.append(row_sign)
                    oci_codes.extend(code_list)
                else:
                    running_details.append(per_co)
                    running_signs.append(row_sign)
                    running_codes.extend(code_list)
                if stack:
                    stack[-1].append(per_co)
                    stack_codes[-1].extend(code_list)
            elif rtype in ('total','grand_total'):
                if stack:
                    section_data = stack.pop()
                    section_codes = stack_codes.pop()
                    sign = stack_signs.pop()  # 当前 section 的符号
                    # 提取 sum_pc 和各子项的符号
                    section_items = []
                    section_item_signs = []
                    for d in section_data:
                        if isinstance(d, dict) and 'sum_pc' in d:
                            section_items.append(d['sum_pc'])
                            section_item_signs.append(d.get('cf_sign', 1))
                        else:
                            section_items.append(d)
                            section_item_signs.append(1)
                    # 合并调整额
                    section_cons_adj = {}
                    for p in periods:
                        accumulated = 0.0
                        for d in section_data:
                            if isinstance(d, dict) and 'cons_adj' in d:
                                cs = d.get('cf_sign', 1)
                                accumulated += d['cons_adj'].get(p, 0.0) * cs
                        accumulated += sum(cons_map.get((c, p, rt), 0.0) for c in section_codes if c)
                        section_cons_adj[p] = round(accumulated, 2)
                elif has_sections and rtype == 'grand_total':
                    # 有 section 结构的 grand_total（CF/BS/OCI）
                    # 利润表 grand_total 因 OCI 节 has_sections=True，
                    # 但净利润/综合收益总额应走 flat P&L 路径而非 section_totals
                    if rt == '利润表':
                        # 使用 running_details（P&L 平坦路径）
                        section_items = list(running_details)
                        section_item_signs = list(running_signs)
                        sign = 1
                        section_cons_adj = {}
                        for p in periods:
                            # 用余额方向加权：贷余(收入)正贡献，借余(费用)负贡献
                            section_cons_adj[p] = sum(
                                cons_map.get((c, p, rt), 0.0) * (-1 if get_normal_balance(c) == 'debit' else 1)
                                for c in running_codes if c
                            )
                    else:
                        # CF/BS 正常 section 路径
                        if rt == '现金流量表' and '现金及现金等价物净增加额' in name:
                            s_start = 0  # 现金净增加额 = 经营+投资+筹资净额
                        elif rt == '资产负债表' and name in ('负债合计', '负债和所有者权益合计'):
                            s_start = bs_liab_group_start  # 从负债组开始
                        else:
                            s_start = section_gt_start
                        section_gt_start = len(section_totals)  # 标记下一组起点
                        s_slice = section_totals[s_start:]
                        s_sign_slice = section_signs[s_start:]
                        s_adj_slice = section_cons_adjs[s_start:]
                        sum_pc = {}
                        for co in companies:
                            for p in periods:
                                sum_pc[(co,p)] = {
                                    'after': round(sum(
                                        (st[(co,p)]['after'] if (co,p) in st else 0) * sg
                                        for st, sg in zip(s_slice, s_sign_slice)
                                    ), 2),
                                    'adj': round(sum(
                                        (st[(co,p)]['adj'] if (co,p) in st else 0) * sg
                                        for st, sg in zip(s_slice, s_sign_slice)
                                    ), 2),
                                    'before': round(sum(
                                        (st[(co,p)]['before'] if (co,p) in st else 0) * sg
                                        for st, sg in zip(s_slice, s_sign_slice)
                                    ), 2),
                                }
                        # 同时累加各节的合并调整额（乘以节符号）
                        grand_cons_adj = {}
                        for p in periods:
                            grand_cons_adj[p] = round(sum(
                                sca.get(p, 0.0) * sg
                                for sca, sg in zip(s_adj_slice, s_sign_slice)
                            ), 2)
                        # 如果是综合收益总额，还要加上利润表净利润
                        if profit_grand is not None and section_totals:
                            oci_total = section_totals[-1]
                            oci_sign = section_signs[-1] if section_signs else 1
                            for co in companies:
                                for p in periods:
                                    pg = profit_grand[(co,p)] if (co,p) in profit_grand else {}
                                    oc = oci_total[(co,p)] if (co,p) in oci_total else {}
                                    sum_pc[(co,p)] = {
                                        'after': round(sum_pc[(co,p)]['after'] + pg.get('after',0) + oc.get('after',0) * oci_sign, 2),
                                        'adj': round(sum_pc[(co,p)]['adj'] + pg.get('adj',0) + oc.get('adj',0) * oci_sign, 2),
                                        'before': round(sum_pc[(co,p)]['before'] + pg.get('before',0) + oc.get('before',0) * oci_sign, 2),
                                    }
                        report_rows.append({'type':rtype,'name':name,'code':'','_pc':sum_pc,'_cons_adj':grand_cons_adj})
                        continue  # 跳过下方的标准计算
                else:
                    # 无 section 标记的模板：累加全部明细到当前位置（带符号）
                    section_items = list(running_details)
                    section_item_signs = list(running_signs)
                    sign = 1
                    # 所有 detail 科目的合并调整额
                    section_cons_adj = {}
                    for p in periods:
                        section_cons_adj[p] = sum(cons_map.get((c, p, rt), 0.0) for c in running_codes if c)
                sum_pc = {}
                for co in companies:
                    for p in periods:
                        sum_pc[(co,p)] = {
                            'after': round(sum(
                                (it[(co,p)]['after'] if (co,p) in it else 0) * sgn
                                for it, sgn in zip(section_items, section_item_signs)
                            ), 2),
                            'adj': round(sum(
                                (it[(co,p)]['adj'] if (co,p) in it else 0) * sgn
                                for it, sgn in zip(section_items, section_item_signs)
                            ), 2),
                            'before': round(sum(
                                (it[(co,p)]['before'] if (co,p) in it else 0) * sgn
                                for it, sgn in zip(section_items, section_item_signs)
                            ), 2),
                        }
                report_rows.append({'type':rtype,'name':name,'code':'','_pc':sum_pc,'_cons_adj':section_cons_adj})
                # 冻结净利润，后续 OCI 走独立通道
                if rt == '利润表' and '净利润' in name and rtype == 'grand_total':
                    profit_frozen = True
                    profit_grand = sum_pc
                if rtype == 'total' and has_sections:
                    section_totals.append(sum_pc)  # 保存节汇总
                    section_cons_adjs.append(section_cons_adj)  # 保存节合并调整额
                    section_signs.append(sign)  # 保存节符号
                if stack:
                    stack[-1].append({'sum_pc': sum_pc, 'cons_adj': section_cons_adj, 'cf_sign': sign})

        # 展平成列值
        data_rows = []
        n_cols_total = 2 + 3 * len(periods) + len(companies) * 3 * len(periods)
        for rr in report_rows:
            if rr['type'] == 'section':
                data_rows.append({'type':'section','vals':['', f'  {rr["name"]}'] + [''] * (n_cols_total - 2)})
                continue
            per_co = rr.get('_pc', {})
            code = rr.get('code','')
            name = rr.get('name','')
            vals = [code, name]
            for p in periods:
                total_after = sum(per_co.get((co,p),{}).get('after',0) for co in companies)
                total_adj = sum(per_co.get((co,p),{}).get('adj',0) for co in companies)
                # 合计行用 _cons_adj（已累积的节合并调整额），明细行用 _all_codes 查 cons_map
                if rr['type'] in ('total','grand_total'):
                    cons_adj = rr.get('_cons_adj', {}).get(p, 0.0)
                else:
                    all_codes = rr.get('_all_codes', []) or []
                    if all_codes:
                        cons_adj = sum(cons_map.get((c, p, rt), 0.0) for c in all_codes if c)
                    else:
                        cons_adj = 0.0
                cons_after = total_after + cons_adj
                vals += [round(cons_after,2), round(cons_adj,2), round(total_after,2)]
            for co in companies:
                for p in periods:
                    pc = per_co.get((co,p), {'after':0,'adj':0,'before':0})
                    vals += [pc['after'], pc['adj'], pc['before']]
            data_rows.append({'type':rr['type'],'vals':vals})

        result[rt] = (data_rows, periods, n_cols_total)

    return result


def _compute_checks(preview, companies):
    """对预览数据做勾稽校验，返回异常列表
    每条: {'level':'error'|'warning', 'scope':'单体'|'合并', 'company':..., 'report':..., 'message':...}
    """
    checks = []

    for rt, (data_rows, periods, _) in preview.items():
        if not data_rows:
            continue

        # 建立名称→行的映射
        name_map = {}
        for dr in data_rows:
            vals = dr['vals']
            name = str(vals[1]).strip() if len(vals) > 1 else ''
            name_map[name] = dr

        # ── 资产负债表勾稽 ──
        if '资产负债表' in rt:
            grand_assets = name_map.get('资产总计')
            grand_liabilities = name_map.get('负债合计')
            grand_equity_total = name_map.get('负债和所有者权益合计')
            equity_total = name_map.get('所有者权益合计')

            if grand_assets and grand_liabilities and equity_total:
                av = grand_assets['vals']
                lv = grand_liabilities['vals']
                ev = equity_total['vals']

                # 检查合并列（vals[2] = 抵消后）
                cons_assets = av[2] if len(av) > 2 else 0
                cons_liab = lv[2] if len(lv) > 2 else 0
                cons_eq = ev[2] if len(ev) > 2 else 0
                if cons_assets and abs(cons_assets - cons_liab - cons_eq) > 0.01:
                    checks.append({
                        'level': 'error',
                        'scope': '合并',
                        'company': '合并报表',
                        'report': '资产负债表',
                        'message': f'合并列不平：资产总计{_fmt(cons_assets)} ≠ 负债{_fmt(cons_liab)}+权益{_fmt(cons_eq)}（差额{_fmt(cons_assets-cons_liab-cons_eq)}）',
                    })

                # 检查每家公司
                n_co = len(companies)
                n_periods = len(periods)
                for ci, co in enumerate(companies):
                    # vals 布局: code(0), name(1), 各期间合并列(2..2+3*n_periods-1), 各公司*各期间(从2+3*n_periods开始)
                    base = 2 + 3 * n_periods + ci * 3 * n_periods
                    if base + 2 >= len(av):
                        continue
                    co_assets = av[base] if len(av) > base else 0
                    co_liab = lv[base] if len(lv) > base else 0
                    co_eq = ev[base] if len(ev) > base else 0
                    if co_assets and abs(co_assets - co_liab - co_eq) > 0.01:
                        checks.append({
                            'level': 'error',
                            'scope': '单体',
                            'company': co,
                            'report': '资产负债表',
                            'message': f'{co}调整后不平：资产总计{_fmt(co_assets)} ≠ 负债{_fmt(co_liab)}+权益{_fmt(co_eq)}（差额{_fmt(co_assets-co_liab-co_eq)}）',
                        })

            # BS中间层勾稽：资产总计 = 流动资产+非流动资产
            current_assets = name_map.get('流动资产合计')
            noncurrent_assets = name_map.get('非流动资产合计')
            total_assets = name_map.get('资产总计')
            if current_assets and noncurrent_assets and total_assets:
                ca = current_assets['vals'][2] if len(current_assets['vals']) > 2 else 0
                na = noncurrent_assets['vals'][2] if len(noncurrent_assets['vals']) > 2 else 0
                ta = total_assets['vals'][2] if len(total_assets['vals']) > 2 else 0
                if ta and abs(ta - (ca + na)) > 0.01:
                    checks.append({
                        'level': 'error', 'scope': '合并', 'company': '合并报表',
                        'report': '资产负债表',
                        'message': f'资产总计{_fmt(ta)} ≠ 流动资产{_fmt(ca)}+非流动资产{_fmt(na)}（差额{_fmt(ta-ca-na)}）',
                    })

            # BS中间层勾稽：负债合计 = 流动负债+非流动负债
            current_liab = name_map.get('流动负债合计')
            noncurrent_liab = name_map.get('非流动负债合计')
            total_liab = name_map.get('负债合计')
            if current_liab and noncurrent_liab and total_liab:
                cl = current_liab['vals'][2] if len(current_liab['vals']) > 2 else 0
                nl = noncurrent_liab['vals'][2] if len(noncurrent_liab['vals']) > 2 else 0
                tl = total_liab['vals'][2] if len(total_liab['vals']) > 2 else 0
                if tl and abs(tl - (cl + nl)) > 0.01:
                    checks.append({
                        'level': 'error', 'scope': '合并', 'company': '合并报表',
                        'report': '资产负债表',
                        'message': f'负债合计{_fmt(tl)} ≠ 流动负债{_fmt(cl)}+非流动负债{_fmt(nl)}（差额{_fmt(tl-cl-nl)}）',
                    })

            # BS勾稽：负债和所有者权益合计 = 负债合计 + 所有者权益合计
            liab_total = name_map.get('负债合计')
            equity_total_row = name_map.get('所有者权益合计')
            liab_equity_total = name_map.get('负债和所有者权益合计')
            if liab_total and equity_total_row and liab_equity_total:
                lt = liab_total['vals'][2] if len(liab_total['vals']) > 2 else 0
                et = equity_total_row['vals'][2] if len(equity_total_row['vals']) > 2 else 0
                let = liab_equity_total['vals'][2] if len(liab_equity_total['vals']) > 2 else 0
                if let and abs(let - (lt + et)) > 0.01:
                    checks.append({
                        'level': 'error', 'scope': '合并', 'company': '合并报表',
                        'report': '资产负债表',
                        'message': f'负债和所有者权益合计{_fmt(let)} ≠ 负债合计{_fmt(lt)}+所有者权益{_fmt(et)}（差额{_fmt(let-lt-et)}）',
                    })

        # ── 利润表勾稽 ──
        if '利润表' in rt:
            revenues = name_map.get('一、营业收入')
            op_cost = name_map.get('减：营业成本')
            tax_surcharge = name_map.get('税金及附加')
            sell_exp = name_map.get('销售费用')
            admin_exp = name_map.get('管理费用')
            fin_exp = name_map.get('财务费用')
            op_profit = name_map.get('二、营业利润')
            total_profit = name_map.get('三、利润总额')
            net_profit = name_map.get('四、净利润')
            income_tax = name_map.get('减：所得税费用')

            if op_profit and revenues and op_cost:
                ov = op_profit['vals']
                rv = revenues['vals']

                # 营业利润完整公式（调整前列，vals[4]）
                def _adj_before(m):
                    return m['vals'][4] if len(m['vals']) > 4 else 0

                rev = _adj_before(revenues)
                items = [
                    ('减：营业成本', op_cost, -1),
                    ('税金及附加', tax_surcharge, -1),
                    ('销售费用', sell_exp, -1),
                    ('管理费用', admin_exp, -1),
                    ('研发费用', name_map.get('研发费用'), -1),
                    ('财务费用', fin_exp, -1),
                    ('加：其他收益', name_map.get('加：其他收益'), 1),
                    ('投资收益', name_map.get('投资收益'), 1),
                    ('公允价值变动收益', name_map.get('公允价值变动收益'), 1),
                    ('信用减值损失', name_map.get('信用减值损失'), -1),
                    ('资产减值损失', name_map.get('资产减值损失'), -1),
                    ('资产处置收益', name_map.get('资产处置收益'), 1),
                ]
                detail_sum = 0
                detail_parts = []
                for label, m, sign in items:
                    if m:
                        v = _adj_before(m)
                        detail_sum += v * sign
                        detail_parts.append(f"{label}={_fmt(v)}")
                computed = rev + detail_sum
                op_before = _adj_before(op_profit)
                if abs(op_before) > 0.01 and abs(op_before - computed) > 0.01:
                    checks.append({
                        'level': 'error',
                        'scope': '合并',
                        'company': '合并报表',
                        'report': '利润表',
                        'message': f'调整前营业利润{_fmt(op_before)} ≠ 计算值{_fmt(computed)}（差额{_fmt(op_before-computed)}；收入={_fmt(rev)}，明细: {"; ".join(detail_parts)}）',
                    })

            if net_profit and total_profit and income_tax:
                nv = net_profit['vals']
                tv = total_profit['vals']
                itv = income_tax['vals']
                # 使用调整前(before, vals[4])校验公式：净利润=利润总额-所得税
                net_before = nv[4] if len(nv) > 4 else 0
                tp_before = tv[4] if len(tv) > 4 else 0
                tax_before = itv[4] if len(itv) > 4 else 0
                if net_before and abs(net_before - (tp_before - tax_before)) > 0.01:
                    checks.append({
                        'level': 'error',
                        'scope': '合并',
                        'company': '合并报表',
                        'report': '利润表',
                        'message': f'调整前净利润{_fmt(net_before)} ≠ 利润总额{_fmt(tp_before)}-所得税{_fmt(tax_before)}（差额{_fmt(net_before-(tp_before-tax_before))}）',
                    })

        # ── 现金流量表勾稽 ──
        if '现金流量表' in rt:
            # 经营：净额 = 流入 - 流出
            for activity, flow_in_name, flow_out_name, net_name in [
                ('经营', '经营活动现金流入小计', '经营活动现金流出小计', '经营活动产生的现金流量净额'),
                ('投资', '投资活动现金流入小计', '投资活动现金流出小计', '投资活动产生的现金流量净额'),
                ('筹资', '筹资活动现金流入小计', '筹资活动现金流出小计', '筹资活动产生的现金流量净额'),
            ]:
                inflow = name_map.get(flow_in_name)
                outflow = name_map.get(flow_out_name)
                net = name_map.get(net_name)
                if net and inflow and outflow:
                    nv = net['vals']
                    iv = inflow['vals']
                    ov = outflow['vals']
                    net_v = nv[2] if len(nv) > 2 else 0
                    in_v = iv[2] if len(iv) > 2 else 0
                    out_v = ov[2] if len(ov) > 2 else 0
                    if net_v and abs(net_v - (in_v - out_v)) > 0.01:
                        checks.append({
                            'level': 'error',
                            'scope': '合并',
                            'company': '合并报表',
                            'report': '现金流量表',
                            'message': f'{activity}净流量{_fmt(net_v)} ≠ 流入{_fmt(in_v)}-流出{_fmt(out_v)}（差额{_fmt(net_v-(in_v-out_v))}）',
                        })
            # 现金净增加额 = 经营净额 + 投资净额 + 筹资净额
            total_net = name_map.get('五、现金及现金等价物净增加额')
            op_net = name_map.get('经营活动产生的现金流量净额')
            inv_net = name_map.get('投资活动产生的现金流量净额')
            fin_net = name_map.get('筹资活动产生的现金流量净额')
            if total_net and op_net and inv_net and fin_net:
                tv = total_net['vals']
                ov = op_net['vals']
                iv = inv_net['vals']
                fv = fin_net['vals']
                t_v = tv[2] if len(tv) > 2 else 0
                o_v = ov[2] if len(ov) > 2 else 0
                i_v = iv[2] if len(iv) > 2 else 0
                f_v = fv[2] if len(fv) > 2 else 0
                if t_v and abs(t_v - (o_v + i_v + f_v)) > 0.01:
                    checks.append({
                        'level': 'error',
                        'scope': '合并',
                        'company': '合并报表',
                        'report': '现金流量表',
                        'message': f'现金净增加额{_fmt(t_v)} ≠ 经营{_fmt(o_v)}+投资{_fmt(i_v)}+筹资{_fmt(f_v)}（差额{_fmt(t_v-(o_v+i_v+f_v))}）',
                    })

    return checks


# ═══════════════════════════════════════════════════════════
# 页面主体
# ═══════════════════════════════════════════════════════════

render_sidebar()
header("📋 报表调整", "统一分录录入 + 动态合并预览")

companies = _get_companies()
adj_entries = _load_journal_entries_from_db()

# ── JournalEntryUI 实例 ──
je_mono = JournalEntryUI(
    key_prefix="adj_mono",
    context_name="单体调整",
    storage_key="单体调整",
    standards_mgr=std_mgr,
    account_groups=_MONO_ACCOUNT_GROUPS,
)
je_cons = JournalEntryUI(
    key_prefix="adj_cons",
    context_name="合并抵消",
    storage_key="合并抵消分录",
    standards_mgr=std_mgr,
    account_groups=_CONS_ACCOUNT_GROUPS,
)

# ── 左右分栏 ──
left_col, right_col = st.columns([0.42, 0.58])

# ═══════════════════════════════════════════════════════════
# 左侧面板
# ═══════════════════════════════════════════════════════════
with left_col:
    st.subheader("➕ 新增调整分录")

    # ── 分录类型 + 调整主体（标签行 + 控件行分离，水平对齐）──
    lbl_type, lbl_co = st.columns([0.30, 0.70])
    with lbl_type:
        st.markdown("<p style='margin:0 0 2px 0;font-size:14px;font-weight:500;'>分录类型</p>",
                    unsafe_allow_html=True)
    with lbl_co:
        st.markdown("<p style='margin:0 0 2px 0;font-size:14px;font-weight:500;'>调整主体</p>",
                    unsafe_allow_html=True)

    ctrl_type, ctrl_co = st.columns([0.30, 0.70])
    with ctrl_type:
        entry_type = st.segmented_control(
            "分录类型", ['单体', '合并'],
            default='单体',
            key='new_entry_type_seg',
            label_visibility='hidden',
        )
    with ctrl_co:
        if entry_type == '单体':
            co = st.selectbox(
                "调整主体", options=companies,
                key='new_entry_company_select',
                label_visibility='hidden',
            )
        else:
            st.markdown("""
            <div style="min-height:38px;display:flex;align-items:center;color:#999;font-size:14px;">
                — 合并调整，无需选择公司 —
            </div>
            """, unsafe_allow_html=True)
            co = None

    # 调用 JournalEntryUI 的 render_add_form
    if entry_type == '单体':
        je_mono.render_add_form(
            company=co or (companies[0] if companies else ''),
            show_company_selector=False,
            show_cf=True,
            linking_rules=['retained_earnings', 'cash_flow'],
            period_start=get_state('period_start') or '',
            period_end=get_state('period_end') or '',
            on_save_callback=lambda: _upsert_last_entry(je_mono.manager, '单体调整'),
        )
    else:
        je_cons.render_add_form(
            company='',
            show_company_selector=False,
            show_cf=False,
            linking_rules=['retained_earnings'],
            period_start=get_state('period_start') or '',
            period_end=get_state('period_end') or '',
            on_save_callback=lambda: _upsert_last_entry(je_cons.manager, '合并抵消'),
        )

    st.divider()

    # ── 已录入凭证分录表（从 CRUD 数据库读取，单一数据源）──
    st.subheader("📝 已录入凭证分录")

    pid = get_state('project_id', 0)
    mono_entries = load_journal_entries(pid, context='单体调整') if pid else []
    cons_entries = load_journal_entries(pid, context='合并抵消') if pid else []
    all_entries_raw = [(e, '单体') for e in mono_entries] + [(e, '合并') for e in cons_entries]

    # ── 搜索框 ──
    search_q = st.text_input("🔍 搜索凭证", placeholder="输入任意关键词模糊搜索，匹配整笔分录（例：科目编码、摘要、金额等）",
                             key='journal_search').strip()

    # 模糊搜索：匹配整笔分录（任何一个字段命中即显示整笔）
    def _entry_matches(entry, query):
        """检查一笔分录的任意字段是否包含查询关键词"""
        q = query.lower()
        # 分录级字段
        entry_fields = [
            str(entry.get('id', '')),
            entry.get('description', ''),
            entry.get('company', ''),
            entry.get('adjust_type', ''),
        ]
        for f in entry_fields:
            if q in f.lower():
                return True
        # 行级字段
        for line in entry.get('lines', []):
            line_fields = [
                line.get('side', ''),
                str(line.get('amount', 0)),
                line.get('code', ''),
                line.get('name', ''),
                line.get('cf_category', ''),
                line.get('aux1', ''),
                line.get('aux2', ''),
                line.get('aux3', ''),
            ]
            for f in line_fields:
                if q in f.lower():
                    return True
        return False

    if search_q:
        all_entries_raw = [(e, t) for e, t in all_entries_raw if _entry_matches(e, search_q)]
        if not all_entries_raw:
            st.info(f"未找到匹配「{search_q}」的分录")
        else:
            st.caption(f"找到 {len(all_entries_raw)} 笔分录")

    # 始终显示表格框架（即使无分录）
    display_rows = []
    def _add_rows(entries):
        for ei, (entry, etype) in enumerate(entries):
            if ei > 0:
                display_rows.append({
                    '标识': '───', '调整主体': '', '调整期间': '', '序号': '', '摘要': '',
                    '方向': '', '类别': '', '科目编码': '',
                    '科目名称': '', '涉现': '', '金额': 0,
                    '辅助段1': '', '辅助段2': '', '辅助段3': '',
                })
            for li, line in enumerate(entry.get('lines', [])):
                side = '借' if line.get('side') == 'debit' else '贷'
                amt = line.get('amount', 0)
                code = line.get('code', '')
                cat = classify_account(code)
                cf_cat = line.get('cf_category', '')
                # 涉现列：有 cf_category 时显示实际类别名称，C 开头科目显示"现金流"，否则留空
                if cf_cat:
                    cf_display = cf_cat
                elif code.startswith('C'):
                    cf_display = '现金流'
                else:
                    cf_display = ''
                display_rows.append({
                    '标识': etype,
                    '调整主体': entry.get('company', '') or '—',
                    '调整期间': '期初' if entry.get('adjust_type') == '期初' else '期末',
                    '序号': f"#{entry.get('id')}",
                    '摘要': entry.get('description', ''),
                    '方向': side,
                    '类别': cat,
                    '科目编码': code,
                    '科目名称': line.get('name', ''),
                    '涉现': cf_display,
                    '金额': amt,
                    '辅助段1': line.get('aux1', ''),
                    '辅助段2': line.get('aux2', ''),
                    '辅助段3': line.get('aux3', ''),
                })

    _add_rows(all_entries_raw)

    df = pd.DataFrame(display_rows)

    st.dataframe(
        df,
        column_config={
            '标识': st.column_config.TextColumn('类型', width='small'),
            '调整主体': st.column_config.TextColumn('调整主体', width='medium'),
            '调整期间': st.column_config.TextColumn('期间', width='small'),
            '序号': st.column_config.TextColumn('序号', width='small'),
            '摘要': st.column_config.TextColumn('摘要', width='medium'),
            '方向': st.column_config.TextColumn('方向', width='small'),
            '类别': st.column_config.TextColumn('科目类别', width='small'),
            '科目编码': st.column_config.TextColumn('科目', width='small'),
            '科目名称': st.column_config.TextColumn('科目名称', width='medium'),
            '涉现': st.column_config.TextColumn('涉现', width='small'),
            '金额': st.column_config.NumberColumn('金额', format="¥%.2f"),
            '辅助段1': st.column_config.TextColumn('辅助1', width='small'),
            '辅助段2': st.column_config.TextColumn('辅助2', width='small'),
            '辅助段3': st.column_config.TextColumn('辅助3', width='small'),
        },
        hide_index=True,
        width='stretch',
        height=350,
    )

    # 删除分录（从 CRUD 数据库删除）
    if df.empty and not search_q:
        st.caption("暂无分录")
    else:
        st.markdown("**批量删除**")
        all_with_id = [(e['id'], f"#{e['id']} {e['description'][:30]}", '单体')
                       for e in mono_entries]
        all_with_id += [(e['id'], f"#{e['id']} {e['description'][:30]}", '合并')
                        for e in cons_entries]
        id_opts = [f"{t}|{eid}|{desc}" for eid, desc, t in all_with_id]
        to_del = st.multiselect("选择要删除的分录", options=id_opts, key='del_ids')
        if to_del and st.button("🗑 删除选中", type="secondary"):
            pid = get_state('project_id', 0)
            for item in to_del:
                parts = item.split('|', 2)
                t, eid = parts[0], int(parts[1])
                ctx = '单体调整' if t == '单体' else '合并抵消'
                if pid:
                    delete_journal_entry(pid, eid, ctx)
            st.rerun()

# ═══════════════════════════════════════════════════════════
# 右侧面板 — 动态预览 + 勾稽校验
# ═══════════════════════════════════════════════════════════
with right_col:
    # 计算预览数据 — 从 DB 统一加载（和表格同源）
    all_entries = _load_journal_entries_from_db()
    preview = _compute_preview(all_entries)

    if not preview:
        st.info("请先导入数据并录入分录")
    else:
        # 上方 4/5 ≈ 动态预览（表格自带 max-height 限制）
        st.subheader("👁 动态预览（实时计算）")

        # ── 导出按钮 ──
        export_col1, export_col2 = st.columns([1, 5])
        with export_col1:
            import tempfile, os
            from app.pages._report_helpers import export_preview_to_excel
            from core.store import load_journal_entries
            now_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            periods_map = {}
            for rt, (_, pl, _) in preview.items():
                periods_map[rt] = pl
            # 加载所有调整分录
            pid = get_state('project_id', 0)
            mono_entries = load_journal_entries(pid, context='单体调整') if pid else []
            cons_entries = load_journal_entries(pid, context='合并抵消') if pid else []
            tmp_xlsx = os.path.join(tempfile.gettempdir(), f'合并报表_{now_str}.xlsx')
            export_preview_to_excel(preview, companies, periods_map, tmp_xlsx,
                                     mono_entries=mono_entries, cons_entries=cons_entries)
            with open(tmp_xlsx, 'rb') as f:
                st.download_button("📥 下载 Excel", data=f, file_name=f'合并报表_{now_str}.xlsx',
                                   mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                   use_container_width=True, key='dl_xlsx')
        tab_names = {
            '资产负债表_end': '📊 期末资产负债表',
            '资产负债表_start': '📊 期初资产负债表',
            '利润表': '📈 利润表',
            '现金流量表': '💵 现金流量表',
        }
        tabs = st.tabs(list(tab_names.values()))

        for tab_idx, (tab_key, tab_label) in enumerate(tab_names.items()):
            with tabs[tab_idx]:
                if tab_key == '资产负债表_end':
                    rt = '资产负债表'
                elif tab_key == '资产负债表_start':
                    rt = '资产负债表'
                else:
                    rt = tab_key

                data_rows, periods, _ = preview.get(rt, ([], [], 0))
                if not data_rows:
                    st.info(f"无{rt}数据")
                    continue

                # ── 单表 + 两列 Sticky 冻结（编码 + 报表科目）──
                html = [f'''
<div class="fz-wrap" style="overflow:auto;max-height:75vh;border:1px solid #ddd;border-radius:4px;font-size:12px;">
<style>
.fz-table {{ border-collapse:separate; border-spacing:0; white-space:nowrap; }}
.fz-table th,.fz-table td {{ padding:2px 6px; border:1px solid #e0e0e0; text-align:right;
               font-weight:400; }}
.fz-table td.fz-c0,.fz-table td.fz-c1 {{ position:sticky; z-index:3; background:#fff; }}
.fz-table td.fz-c0 {{ left:0; border-left-color:#fff; border-right-color:#fff; }}
.fz-table td.fz-c1 {{ left:80px; border-left-color:#fff; border-right:2px solid #bbb; }}
.fz-table tr.bg-section td.fz-c0,
.fz-table tr.bg-section td.fz-c1 {{ background:#E8F0FE; border-left-color:#E8F0FE; border-right-color:#E8F0FE; }}
.fz-table tr.bg-section td.fz-c0 {{ border-right-color:#E8F0FE; }}
.fz-table tr.bg-section td.fz-c1 {{ border-left-color:#E8F0FE; }}
.fz-table tr.bg-total td.fz-c0,
.fz-table tr.bg-total td.fz-c1 {{ background:#E2EFDA; }}
.fz-table tr.bg-total td.fz-c0 {{ border-left-color:#E2EFDA; border-right-color:#E2EFDA; }}
.fz-table tr.bg-total td.fz-c1 {{ border-left-color:#E2EFDA; border-right:2px solid #bbb; }}
.fz-table thead {{ position:sticky; top:0; z-index:10; }}
.fz-table thead th {{ position:sticky; top:0; z-index:10; padding:3px 6px; border-color:#ccc;
               font-weight:600; background:#fff; text-align:center; }}
.fz-table thead th.fz-c0 {{ left:0; z-index:11; border-left-color:#fff; border-right-color:#fff; }}
.fz-table thead th.fz-c1 {{ left:80px; z-index:11; border-left-color:#fff; border-right:2px solid #bbb; }}
.fz-table .bg-blue {{ background:#E8F4FD; }}
.fz-table .bg-section {{ background:#E8F0FE; }}
.fz-table .bg-total {{ background:#E2EFDA; font-weight:600; }}
.fz-table .al-left {{ text-align:left; }}
.fz-table .al-center {{ text-align:center; }}
.fz-table .w-80 {{ width:80px; min-width:80px; }}
.fz-table .w-200 {{ width:200px; min-width:200px; }}
.fz-table .w-120 {{ width:120px; min-width:120px; }}
</style>
<table class="fz-table"><thead>
<tr><th colspan="2" class="fz-c0 al-center w-200">科目</th>''']
                # 确定当前 tab 对应的期间
                if tab_key == '资产负债表_end':
                    period_idx = 0  # 期末
                elif tab_key == '资产负债表_start':
                    period_idx = 1 if len(periods) > 1 else 0  # 期初
                else:
                    period_idx = 0  # 利润表/现金流量表只有本年累计

                n_periods = len(periods)
                p_label = '期末' if period_idx == 0 and n_periods > 1 else ('期初' if period_idx > 0 else '本年累计')
                # 表头第1行：科目 + 当前期间合并抵消(3列) + 各公司(3列/公司)
                html.append(f'  <th colspan="3" class="bg-blue w-120">{p_label}合并抵消</th>')
                for idx, co in enumerate(companies):
                    html.append(f'<th colspan="3" class="w-120">{co}</th>')
                html.append('</tr><tr>')
                html.append(f'<th class="fz-c0 al-center w-80">编码</th>')
                html.append(f'<th class="fz-c1 al-center w-200">报表科目</th>')
                for lbl in [f'{p_label}抵消后', f'{p_label}抵消调整', f'{p_label}抵消前']:
                    html.append(f'<th class="bg-blue w-120">{lbl}</th>')
                for _ in companies:
                    for lbl in ['调整后', '调整额', '调整前']:
                        html.append(f'<th class="w-120">{lbl}</th>')
                html.append('</tr></thead><tbody>')

                # 数据行：仅提取当前期间对应的列
                # vals 结构：[code, name, 期末*3, 期初*3, co1_期末*3, co1_期初*3, co2_期末*3, ...]
                merged_base = 2 + period_idx * 3  # 合并列起始
                co_stride = n_periods * 3  # 每公司列的跨度（含所有期间）
                co_base = 2 + n_periods * 3  # 第一个公司的列起始
                for ri, dr in enumerate(data_rows):
                    vals = dr['vals']
                    rtype = dr['type']
                    is_total = rtype in ('total', 'grand_total')
                    cls = ''
                    if rtype == 'section':
                        cls = 'bg-section'
                    elif is_total:
                        cls = 'bg-total'
                    html.append(f'<tr class="{cls}">')
                    # Col 0: 编码 (sticky)
                    v0 = vals[0] if len(vals) > 0 else ''
                    align0 = 'al-center'
                    html.append(f'<td class="fz-c0 {align0}">{v0}</td>')
                    # Col 1: 报表科目 (sticky)
                    v1 = vals[1] if len(vals) > 1 else ''
                    txt1 = str(v1)
                    if rtype == 'section':
                        txt1 = f'<strong>{v1}</strong>'
                    html.append(f'<td class="fz-c1 al-left">{txt1}</td>')
                    # 当前期间的合并抵消列（3列）
                    for ci in range(merged_base, merged_base + 3):
                        v = vals[ci] if ci < len(vals) else None
                        txt = _fmt(v) if v is not None else '&nbsp;'
                        html.append(f'<td>{txt}</td>')
                    # 各公司当前期间列（每公司3列）
                    for i in range(len(companies)):
                        col_start = co_base + i * co_stride + period_idx * 3
                        for ci in range(col_start, col_start + 3):
                            v = vals[ci] if ci < len(vals) else None
                            txt = _fmt(v) if v is not None else '&nbsp;'
                            html.append(f'<td>{txt}</td>')
                    html.append('</tr>')

                html.append('</tbody></table></div>')

                st.markdown(''.join(html), unsafe_allow_html=True)
                st.caption(f'{tab_label} — {sum(1 for d in data_rows if d["type"]=="detail")}项明细')

        st.divider()
        st.subheader("🔍 勾稽校验", help="检查科目间勾稽关系是否平衡")
        checks = _compute_checks(preview, companies)
        if not checks:
            st.success("✅ 所有勾稽关系正常")
        else:
            st.markdown(f"**发现 {len(checks)} 项异常**")
            for ck in checks:
                icon = '❌' if ck['level'] == 'error' else '⚠️'
                scope_tag = f"[{ck['scope']}]" if ck['scope'] == '单体' else '[合并]'
                with st.container():
                    st.markdown(f"""
<div style="font-size:12px;padding:6px 8px;margin:4px 0;border-radius:4px;
background:{'#FFF0F0' if ck['level']=='error' else '#FFF8E1'};
border-left:3px solid {'#D32F2F' if ck['level']=='error' else '#F9A825'};">
<div style="font-weight:600;color:#333;">{icon} {scope_tag} {ck['report']}</div>
<div style="color:#555;margin-top:2px;">{ck['message']}</div>
<div style="color:#888;font-size:11px;margin-top:2px;">{ck.get('company','')}</div>
</div>
""", unsafe_allow_html=True)
