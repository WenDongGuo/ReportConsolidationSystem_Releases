"""
💱 外币折算 — Step 7 CAS 19 / IAS 21

功能:
  1. 配置各公司的功能性货币 vs 报告币种
  2. 从 Frankfurter API 获取期间汇率
  3. 按现行汇率法自动折算
  4. 生成折算差额 → 其他综合收益分录
  5. 折算后数据供 Step 6 合并使用
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import streamlit as st
import pandas as pd
from datetime import date, datetime
import json

st.set_page_config(page_title="外币折算", page_icon="💱", layout="wide")

from app.components.common import header, metric_card, render_sidebar
from app.utils.session import get_state, set_state, auto_save
from core.translator import TranslationEngine, CompanyCurrencyConfig
from core.forex import (
    get_period_rates, get_rates, format_rate_table,
    MAJOR_CURRENCIES, get_available_currencies,
)
from core.standards import StandardsManager

PROJECT_DIR = os.path.join(os.path.dirname(__file__), '..', '..')
OUTPUT_DIR = os.path.join(PROJECT_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)
CONFIG_DIR = os.path.join(PROJECT_DIR, 'config')
STANDARDS_DIR = os.path.join(CONFIG_DIR, 'standards')

std_mgr = StandardsManager(STANDARDS_DIR)

header("💱 外币折算", "Step 7: CAS 19 / IAS 21 — 现行汇率法 · 差额计入其他综合收益")
render_sidebar()

# ========== 加载基础数据 ==========
all_records = get_state('all_records')
report_currency = get_state('report_currency') or 'CNY'
period_start = get_state('period_start')
period_end = get_state('period_end')

if not all_records:
    st.warning("⚠️ 请先完成 Step 1: 导入报表数据")
    st.page_link("pages/01_import_data.py", label="→ 去导入数据", use_container_width=True)
    st.stop()

if not period_start or not period_end:
    st.warning("⚠️ 请先在 Step 1 设置报告期间")
    st.page_link("pages/01_import_data.py", label="→ 去设置期间", use_container_width=True)
    st.stop()

# 解析期间日期
start_date = None
end_date = None
try:
    start_date = date.fromisoformat(period_start) if isinstance(period_start, str) else period_start
    end_date = date.fromisoformat(period_end) if isinstance(period_end, str) else period_end
except (ValueError, TypeError):
    st.error("❌ 期间日期格式无效")
    st.stop()

if not start_date or not end_date:
    st.error("❌ 无法解析期间日期")
    st.stop()

df = pd.DataFrame(all_records)
companies = sorted(df['company'].unique().tolist()) if not df.empty else []

# ========== 初始化状态 ==========
if 'company_currencies' not in st.session_state or st.session_state['company_currencies'] is None:
    # 默认所有公司都是报告币种
    st.session_state['company_currencies'] = {
        c: CompanyCurrencyConfig(c, report_currency, report_currency)
        for c in companies
    }
# 防御性修复：从 DB 恢复后 value 可能不是 CompanyCurrencyConfig 对象
ccy_configs = st.session_state['company_currencies']
if ccy_configs:
    first_val = next(iter(ccy_configs.values()))
    if isinstance(first_val, str):
        # 旧格式：字符串（json default=str 序列化）
        st.session_state['company_currencies'] = {
            c: CompanyCurrencyConfig(c, report_currency, report_currency)
            if v == report_currency
            else CompanyCurrencyConfig(c, v, report_currency)
            for c, v in ccy_configs.items()
        }
    elif isinstance(first_val, dict):
        # 新格式：dict（json to_dict() 序列化）
        st.session_state['company_currencies'] = {
            c: CompanyCurrencyConfig(
                company=v.get('company', c),
                functional_currency=v.get('functional_currency', report_currency),
                reporting_currency=v.get('reporting_currency', report_currency),
                method=v.get('method', 'current_rate'),
                historical_rates=v.get('historical_rates', {}),
            )
            for c, v in ccy_configs.items()
        }
if 'period_rates_cache' not in st.session_state or st.session_state['period_rates_cache'] is None:
    st.session_state['period_rates_cache'] = {}
if 'translation_results' not in st.session_state or st.session_state['translation_results'] is None:
    st.session_state['translation_results'] = {}

# ========== 概览卡片 ==========
st.markdown("### 📊 概览")
col1, col2, col3, col4 = st.columns(4)
with col1: metric_card("🏢 公司数", len(companies))
with col2: metric_card("💰 报告币种", MAJOR_CURRENCIES.get(report_currency, report_currency))
with col3: metric_card("📅 期间", f"{period_start} ~ {period_end}")
with col4:
    fx_companies = sum(1 for c in companies
                       if st.session_state['company_currencies'].get(c,
                           CompanyCurrencyConfig(c, report_currency, report_currency)).needs_translation)
    metric_card("🔄 需折算", fx_companies, "外币公司")

# ========== Tab 布局 ==========
tab_config, tab_rates, tab_exec, tab_result = st.tabs([
    "⚙️ 币种配置", "💱 汇率查询", "🚀 执行折算", "📊 结果预览"
])

# ---- Tab 1: 币种配置 ----
with tab_config:
    st.markdown("#### 设置各公司的功能性货币")
    st.caption(f"报告币种: **{MAJOR_CURRENCIES.get(report_currency, report_currency)}**")

    currencies_list = sorted(MAJOR_CURRENCIES.keys())
    currency_configs = st.session_state['company_currencies']

    updated = False
    for company in companies:
        cfg = currency_configs.get(company, CompanyCurrencyConfig(company, report_currency, report_currency))
        col1, col2 = st.columns([1, 2])
        with col1:
            st.markdown(f"**{company}**")
        with col2:
            new_ccy = st.selectbox(
                "功能性货币",
                currencies_list,
                index=currencies_list.index(cfg.functional_currency)
                    if cfg.functional_currency in currencies_list else 0,
                key=f"fx_ccy_{company}",
                format_func=lambda x: MAJOR_CURRENCIES.get(x, x),
                label_visibility="collapsed",
            )
            if new_ccy != cfg.functional_currency:
                currency_configs[company] = CompanyCurrencyConfig(company, new_ccy, report_currency)
                updated = True

    if updated:
        st.session_state['company_currencies'] = currency_configs
        # 清空旧的折算结果
        st.session_state['translation_results'] = {}
        from app.utils.session import auto_save
        auto_save()
        st.success("✅ 币种配置已更新")

    # 批量操作
    st.markdown("---")
    st.markdown("**批量设置**")
    col_b1, col_b2 = st.columns(2)
    with col_b1:
        batch_ccy = st.selectbox(
            "设为某种货币",
            currencies_list,
            format_func=lambda x: MAJOR_CURRENCIES.get(x, x),
            key="fx_batch_ccy",
        )
        if st.button("🔄 全部设为该货币", use_container_width=True):
            for c in companies:
                currency_configs[c] = CompanyCurrencyConfig(c, batch_ccy, report_currency)
            st.session_state['company_currencies'] = currency_configs
            st.session_state['translation_results'] = {}
            from app.utils.session import auto_save
            auto_save()
            st.success(f"✅ 全部公司已设为 {MAJOR_CURRENCIES.get(batch_ccy, batch_ccy)}")
            st.rerun()
    with col_b2:
        if st.button("🔄 全部设为人民币(无需折算)", use_container_width=True):
            for c in companies:
                currency_configs[c] = CompanyCurrencyConfig(c, report_currency, report_currency)
            st.session_state['company_currencies'] = currency_configs
            st.session_state['translation_results'] = {}
            from app.utils.session import auto_save
            auto_save()
            st.success("✅ 全部公司已设为人民币")
            st.rerun()

    # 状态一览
    st.markdown("---")
    st.markdown("**当前配置**")
    config_rows = []
    for c in companies:
        cfg = currency_configs.get(c, CompanyCurrencyConfig(c, report_currency, report_currency))
        status = "🔄 需折算" if cfg.needs_translation else "✅ 无需折算"
        config_rows.append({
            '公司': c,
            '功能性货币': MAJOR_CURRENCIES.get(cfg.functional_currency, cfg.functional_currency),
            '报告币种': MAJOR_CURRENCIES.get(cfg.reporting_currency, cfg.reporting_currency),
            '状态': status,
        })
    st.dataframe(pd.DataFrame(config_rows), use_container_width=True, hide_index=True)

# ---- Tab 2: 汇率查询 ----
with tab_rates:
    st.markdown("#### 获取期间汇率")
    st.caption(f"数据源: Frankfurter API · 期间: {period_start} ~ {period_end}")

    # 获取需要折算的币种列表
    needed_currencies = set()
    for c in companies:
        cfg = currency_configs.get(c, CompanyCurrencyConfig(c, report_currency, report_currency))
        if cfg.needs_translation and cfg.functional_currency != 'CNY':
            needed_currencies.add(cfg.functional_currency)

    if not needed_currencies:
        st.info("📌 全部公司均为人民币，无需查询汇率")
    else:
        st.info(f"需要查询的币种: {', '.join(sorted(needed_currencies))}")

        if st.button("📡 从 Frankfurter API 获取汇率", type="primary", use_container_width=True):
            with st.spinner("正在查询汇率..."):
                try:
                    period_rates = get_period_rates(start_date, end_date)
                    st.session_state['period_rates_cache'] = period_rates
                    from app.utils.session import auto_save
                    auto_save()
                    st.success(f"✅ 已获取 {len(period_rates.get('可用币种', []))} 个币种的汇率")
                except Exception as e:
                    st.error(f"❌ 汇率查询失败: {e}")

        # 显示汇率表
        period_rates = st.session_state.get('period_rates_cache') or {}
        if period_rates:
            rate_rows = format_rate_table(period_rates)

            if rate_rows:
                # 只显示需要的币种
                if needed_currencies:
                    rate_rows = [r for r in rate_rows if r['币种'] in needed_currencies]

                st.dataframe(
                    pd.DataFrame(rate_rows),
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "币种": st.column_config.TextColumn("币种", width="small"),
                        "币种名称": st.column_config.TextColumn("名称", width="medium"),
                        "期初汇率": st.column_config.TextColumn("期初汇率", width="medium"),
                        "期末汇率": st.column_config.TextColumn("期末汇率", width="medium"),
                        "平均汇率": st.column_config.TextColumn("平均汇率", width="medium"),
                        "变动": st.column_config.TextColumn("变动", width="small"),
                    }
                )
            else:
                st.warning("⚠️ 未能获取汇率数据，请检查网络连接")

    # 手动输入汇率
    with st.expander("✏️ 手动输入/修改汇率"):
        st.caption("如果 API 无法获取或不准确，可以手动输入")
        manual_start = st.number_input("期初汇率 (1外币=?人民币)", min_value=0.0, format="%.6f", key="fx_manual_start")
        manual_end = st.number_input("期末汇率", min_value=0.0, format="%.6f", key="fx_manual_end")
        manual_avg = st.number_input("平均汇率", min_value=0.0, format="%.6f", key="fx_manual_avg")
        manual_ccy = st.selectbox("币种", sorted(needed_currencies) if needed_currencies else ['USD'], key="fx_manual_ccy")
        
        if st.button("应用手动汇率", use_container_width=True):
            if manual_end > 0:
                if 'period_rates_cache' not in st.session_state:
                    st.session_state['period_rates_cache'] = {}
                st.session_state['period_rates_cache'].setdefault('期初汇率', {})[manual_ccy] = manual_start
                st.session_state['period_rates_cache'].setdefault('期末汇率', {})[manual_ccy] = manual_end
                st.session_state['period_rates_cache'].setdefault('平均汇率', {})[manual_ccy] = manual_avg
                from app.utils.session import auto_save
                auto_save()
                st.success(f"✅ {manual_ccy} 汇率已手动设置")
                st.rerun()
            else:
                st.warning("期末汇率必填")

# ---- Tab 3: 执行折算 ----
with tab_exec:
    st.markdown("#### 执行外币折算")
    st.caption("按现行汇率法: 资产/负债→期末汇率 · 损益→平均汇率 · 权益→历史汇率")

    period_rates = st.session_state.get('period_rates_cache') or {}
    currency_configs = st.session_state['company_currencies']

    # 检查前置条件
    needs_fx = False
    missing_rates = []
    for c in companies:
        cfg = currency_configs.get(c, CompanyCurrencyConfig(c, report_currency, report_currency))
        if cfg.needs_translation:
            needs_fx = True
            ccy = cfg.functional_currency
            if ccy != 'CNY':
                end_rate = period_rates.get('期末汇率', {}).get(ccy, 0)
                if end_rate == 0:
                    missing_rates.append(f"{c} ({ccy})")

    if not needs_fx:
        st.info("📌 全部公司均为人民币，无需折算")
    elif missing_rates:
        st.warning(f"⚠️ 以下公司缺少汇率，请先在「汇率查询」Tab 获取: **{', '.join(missing_rates)}**")
    else:
        fx_summary = []
        for c in companies:
            cfg = currency_configs.get(c, CompanyCurrencyConfig(c, report_currency, report_currency))
            fx_summary.append({
                '公司': c,
                '功能性货币': cfg.functional_currency,
                '需折算': '🔄' if cfg.needs_translation else '✅',
            })

        col1, col2 = st.columns([2, 1])
        with col1:
            st.dataframe(pd.DataFrame(fx_summary), use_container_width=True, hide_index=True)
        with col2:
            st.info(f"📡 汇率已就绪: {len(period_rates.get('可用币种', []))} 个币种")
            if st.button("🚀 执行全部折算", type="primary", use_container_width=True):
                progress = st.progress(0)
                status = st.empty()

                engine = TranslationEngine(std_mgr)
                configs_list = [currency_configs[c] for c in companies if c in currency_configs]

                results = {}
                total = len(companies)
                for idx, c in enumerate(companies):
                    status.text(f"正在折算: {c}...")
                    company_records = df[df['company'] == c].to_dict('records') if not df.empty else []
                    cfg = currency_configs.get(c, CompanyCurrencyConfig(c, report_currency, report_currency))
                    result = engine.translate_company(company_records, cfg, period_rates)
                    results[c] = result
                    progress.progress((idx + 1) / total)

                st.session_state['translation_results'] = results
                from app.utils.session import auto_save
                auto_save()
                status.text("✅ 折算完成")
                progress.progress(1.0)

                # 统计
                total_diff = sum(r.translation_diff for r in results.values() if r.needs_translation)
                fx_count = sum(1 for r in results.values() if r.needs_translation)
                st.success(f"✅ 已折算 {fx_count} 家外币公司，总折算差额 ¥{total_diff:,.2f}")
                st.rerun()

# ---- Tab 4: 结果预览 ----
with tab_result:
    results = st.session_state.get('translation_results') or {}
    if not results:
        st.info("📌 请先在「执行折算」Tab 执行折算")
    else:
        st.markdown("#### 折算结果")

        # 汇总
        total_original = 0
        total_translated = 0
        total_diff = 0
        fx_companies_result = 0

        summary_rows = []
        for c in companies:
            r = results.get(c)
            if not r:
                summary_rows.append({'公司': c, '状态': '❌ 未折算', '折算差额': ''})
                continue
            if not r.needs_translation:
                summary_rows.append({'公司': c, '状态': '✅ 无需折算', '折算差额': '—'})
            else:
                fx_companies_result += 1
                total_diff += r.translation_diff
                records_count = len(r.translated_records)
                summary_rows.append({
                    '公司': c,
                    '状态': f"🔄 已折算 ({r.config.functional_currency}→{r.config.reporting_currency})",
                    '科目数': records_count,
                    '折算差额': f"¥{r.translation_diff:+,.2f}",
                })

        col1, col2, col3 = st.columns(3)
        with col1: metric_card("🔄 已折算公司", fx_companies_result)
        with col2: metric_card("💰 总折算差额", f"¥{total_diff:+,.2f}")
        with col3: metric_card("📄 总科目数", sum(len(r.translated_records) for r in results.values()))

        st.dataframe(pd.DataFrame(summary_rows), use_container_width=True, hide_index=True)

        # 详情展开
        for c in companies:
            r = results.get(c)
            if not r or not r.needs_translation:
                continue

            with st.expander(f"📊 {c} — 折算差额 ¥{r.translation_diff:+,.2f}", expanded=False):
                st.markdown(f"**折算配置**: {r.config.functional_currency} → {r.config.reporting_currency}")
                
                # 汇率信息
                details = r.details
                fx_info = details.get('汇率', {})
                if fx_info:
                    st.markdown(f"**适用汇率**: 期初={fx_info.get('期初', 0):.6f} · 期末={fx_info.get('期末', 0):.6f} · 平均={fx_info.get('平均', 0):.6f}")

                # 科目明细
                st.markdown("**折算后科目明细**")
                records_df = pd.DataFrame(r.translated_records)
                if not records_df.empty:
                    display = records_df[['科目编码', '科目名称', '金额', '报表']].copy()
                    st.dataframe(display, use_container_width=True, hide_index=True)

                # 自动生成的分录
                from core.translator import TranslationEngine
                engine = TranslationEngine(std_mgr)
                journal = engine.generate_fx_journal(r)
                if journal:
                    st.markdown("**自动生成的分录: 外币折算差额**")
                    for l in journal['lines']:
                        side_cn = "借" if l['side'] == 'debit' else "贷"
                        st.markdown(f"&nbsp;&nbsp;{side_cn} {l['code']} {l['name']}  **¥{l['amount']:,.2f}**")
                    st.caption("该分录将折算差额计入其他综合收益—外币折算差额")

        # 导出折算后数据
        st.markdown("---")
        col_e1, col_e2 = st.columns(2)
        with col_e1:
            if st.button("💾 保存折算结果到会话", use_container_width=True):
                # 将所有折算后数据合并
                translated_all = []
                for c in companies:
                    r = results.get(c)
                    if r:
                        translated_all.extend(r.translated_records)
                set_state('translated_records', translated_all)
                auto_save()
                set_state('current_step', 6)
                st.success("✅ 折算结果已保存，可在 Step 6 中使用")
        with col_e2:
            # 导出 CSV
            all_records_export = []
            for c in companies:
                r = results.get(c)
                if r:
                    all_records_export.extend(r.translated_records)
            if all_records_export:
                csv_path = os.path.join(OUTPUT_DIR, '外币折算结果.csv')
                pd.DataFrame(all_records_export).to_csv(csv_path, index=False, encoding='utf-8-sig')
                with open(csv_path, 'rb') as f:
                    st.download_button("📥 下载折算结果 CSV", data=f,
                                       use_container_width=True,
                                       file_name="外币折算结果.csv")
